from pandas import read_csv
from os.path import join
import matplotlib.pyplot as plt
import wfdb
import os
import numpy as np
from matplotlib.colors import to_rgba


def load_data(filepath):
    dic = dict()
    with open(filepath) as f:
        text = list(f)
    for line in text:
        line = line.replace(' ','').replace('\n','').replace(',,','')
        if line[-1] == ',': line = line[:-1]
        head = line.split(',')[0]
        tail = line.split(',')[1:]
        if tail == ['']:
            tail = np.asarray([])
        else:
            tail = np.asarray(tail).astype(int)

        dic[head] = tail
    return dic



def plot_at(fname,a):
    # a:  1-> LOBACHEVSKY  2-> QT
    #fname='sele0166_0'
    ################ LOBACHEVSKY ################
    if a == 1:
        nombres = ['i', 'ii', 'iii', 'avr', 'avl', 'avf', 'v1', 'v2', 'v3', 'v4', 'v5', 'v6']
        #dataDir="lobachevsky-university-electrocardiography-database-1.0.1/data/ToCSV/"
        dataDir="lobachevsky-university-electrocardiography-database-1.0.1/data/ToCSV/"
        marcaDir="lobachevsky-university-electrocardiography-database-1.0.1/data/"
        dataset             = read_csv(join(dataDir, 'Dataset2.csv'), index_col=0)
        fname_s = fname.split('.')[0]
        m = fname.split('.')[1]
        print(m)
        posicion = nombres.index(m)
        print(posicion)

        manual = wfdb.rdann(marcaDir + fname_s, m, return_label_elements=['label_store', 'symbol'], summarize_labels=None)
    

        # Seleccionar la columna de interés
        columna_de_interes = fname_s # Reemplaza con el nombre de tu columna
        señal_seleccionada = dataset[columna_de_interes + f'_{posicion}']
        print(columna_de_interes + f'_{posicion}')
        print('lala')
        print(señal_seleccionada)
        print('lalala')
        # Obtener información sobre las dimensiones del dataset
        num_muestras = len(señal_seleccionada)
        frecuencia_muestreo = 500  # Frecuencia de muestreo en muestras por segundo
        tiempo_total = num_muestras / frecuencia_muestreo  # Tiempo total en segundos

        # Crear la figura y el gráfico
        fig, ax = plt.subplots(figsize=(10, 5))
        fig, am = plt.subplots(figsize=(10, 5))
        # Configurar el eje de tiempos
        tiempos = [i / frecuencia_muestreo for i in range(num_muestras)]

        # Vector de marcas (supongamos que las marcas están en segundos)
        marcas = manual.sample
        
        limite_inferior = min(marcas)-100
        limite_superior = max(marcas)+100
        # Representar las marcas como rayas verticales
        for marca in marcas:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])
        # Trazar la señal de la columna de interés
        ax.plot(tiempos, señal_seleccionada, label='ECG', linewidth=0.75)
        ax.set_ylabel(f'Señal {columna_de_interes}')
        ax.set_title(f'Archivo {columna_de_interes}')
        ax.set_xlabel('Tiempo (segundos)')

        am.plot(señal_seleccionada,linewidth=0.9)
        am.set_ylabel(f'Señal {columna_de_interes}')
        am.set_title(f'Archivo {columna_de_interes} en muestras')
        am.set_xlabel('Muestras')

        # Mostrar la figura
        ax.grid(True)
        ax.set_xlim(0, 10)
        am.set_xlim(0, 5000)
        ax.legend()
        plt.show()
    # if a == 2:
    #     ################ QT ################
    #     dataDir = "qt-database-1.0.0/qt-database-1.0.0/manual0/"
    #     marcaDir = "qt-database-1.0.0/qt-database-1.0.0/"
    #     dataset             = read_csv(join(dataDir, 'Dataset.csv'), index_col=0)
        
    #     fname_s = fname.split('_')[0]
    #     m = fname.split('_')[1]
    #     print(fname_s)
    #     print(m)
    #     manual = wfdb.rdann(marcaDir + fname_s, 'q1c', return_label_elements=['label_store', 'symbol'], summarize_labels=None)

        
    #     # Seleccionar la columna de interés
    #     columna_de_interes = fname # Reemplaza con el nombre de tu columna
    #     señal_seleccionada = dataset[columna_de_interes]
    #     marcas = manual.sample*2-1
    #     print(marcas)

    #     # Obtener información sobre las dimensiones del dataset
    #     num_muestras = len(señal_seleccionada)

    #     frecuencia_muestreo = 250  # Frecuencia de muestreo en muestras por segundo
    #     tiempo_total = num_muestras / frecuencia_muestreo  # Tiempo total en segundos

    #     # Crear la figura y el gráfico
    #     # fig, ax = plt.subplots(figsize=(10, 5))
    #     fig, am = plt.subplots(figsize=(10, 5))
    #     # Configurar el eje de tiempos
    #     tiempos = [i / frecuencia_muestreo for i in range(num_muestras)]

    #     # Vector de marcas (supongamos que las marcas están en segundos)
        
    #     limite_inferior = 0
    #     limite_superior = 225000*2
    #     ymax=max(señal_seleccionada)
        
    #     # Representar las marcas como rayas verticales
    #     for marca in marcas:
    #         # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
    #         am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
    #     am.legend(labels= ['Marca_Cardiólogos'])
        

    #     # Trazar la señal de la columna de interés
    #     # ax.plot(tiempos, señal_seleccionada, label='ECG', linewidth=0.75)
    #     # ax.set_ylabel(f'Señal {columna_de_interes}')
    #     # ax.set_title(f'Archivo {columna_de_interes}')
    #     # ax.set_xlabel('Tiempo (segundos)')

    #     am.plot(señal_seleccionada,linewidth=0.9)
    #     am.set_ylabel(f'Señal {columna_de_interes}')
    #     am.set_title(f'Archivo {columna_de_interes} en muestras')
    #     am.set_xlabel('Muestras')

    #     # Mostrar la figura
    #     # ax.grid(True)
    #     # ax.set_xlim(0, 900)
    #     am.set_xlim(limite_inferior, limite_superior)
    #     # ax.legend()
    #     plt.show()









    if a == 2:
        ################ QT ################
        dataDir = "qt-database-1.0.0/qt-database-1.0.0/manual0/"
        marcaDir = "qt-database-1.0.0/qt-database-1.0.0/manual0/"
        dataset             = read_csv(join(dataDir, 'Dataset.csv'), index_col=0)
        
        fname_s = fname.split('_')[0]
        m = fname.split('_')[1]


        Pon = load_data(join(marcaDir, 'Pon.csv')),
        Ppeak = load_data(join(marcaDir, 'Ppeak.csv')),
        Poff = load_data(join(marcaDir, 'Poff.csv'))
    
        QRSon = load_data(join(marcaDir, 'QRSon.csv')),
        QRSpeak = load_data(join(marcaDir, 'QRSpeak.csv')),
        QRSoff = load_data(join(marcaDir, 'QRSoff.csv'))
    

    
        Ton = load_data(join(marcaDir, 'Ton.csv')),
        Tpeak = load_data(join(marcaDir, 'Tpeak.csv')),
        Toff = load_data(join(marcaDir, 'Toff.csv'))

        
        # Seleccionar la columna de interés
        columna_de_interes = fname # Reemplaza con el nombre de tu columna
        señal_seleccionada = dataset[columna_de_interes]
        
        marca_Pon = Pon[0][columna_de_interes]
        marca_Ppeak = Ppeak[0][columna_de_interes]
        marca_Poff = Poff[columna_de_interes]

        marca_QRSon = QRSon[0][columna_de_interes]
        marca_QRSpeak = QRSpeak[0][columna_de_interes]
        marca_QRSoff = QRSoff[columna_de_interes]

        marca_Ton = Ton[0][columna_de_interes]
        marca_Tpeak = Tpeak[0][columna_de_interes]
        marca_Toff = Toff[columna_de_interes]

        # Obtener información sobre las dimensiones del dataset
        num_muestras = len(señal_seleccionada)

        frecuencia_muestreo = 250  # Frecuencia de muestreo en muestras por segundo
        tiempo_total = num_muestras / frecuencia_muestreo  # Tiempo total en segundos

        # Crear la figura y el gráfico
        # fig, ax = plt.subplots(figsize=(10, 5))
        fig, am = plt.subplots(figsize=(10, 5))
        # Configurar el eje de tiempos
        tiempos = [i / frecuencia_muestreo for i in range(num_muestras)]

        # Vector de marcas (supongamos que las marcas están en segundos)
        
        limite_inferior = 0
        limite_superior = 225000*2
        ymax=max(señal_seleccionada)
        
        # Representar las marcas como rayas verticales
        for marca in marca_Pon:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])
        for marca in marca_Ppeak:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])
        for marca in marca_Poff:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])

        for marca in marca_QRSon:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])
        for marca in marca_QRSpeak:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])
        for marca in marca_QRSoff:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])

        for marca in marca_Ton:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])
        for marca in marca_Tpeak:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])
        for marca in marca_Toff:
            # ax.vlines(marca, ymin=min(señal_seleccionada), ymax=max(señal_seleccionada), color='red', linestyle='--', label='Marca')
            am.vlines(marca, ymin = np.nanmin(señal_seleccionada), ymax = np.nanmax(señal_seleccionada), color='red', linestyle='-', linewidth=0.5, label='Marca_cardiólogo')
        am.legend(labels= ['Marca_Cardiólogos'])

        # Trazar la señal de la columna de interés
        # ax.plot(tiempos, señal_seleccionada, label='ECG', linewidth=0.75)
        # ax.set_ylabel(f'Señal {columna_de_interes}')
        # ax.set_title(f'Archivo {columna_de_interes}')
        # ax.set_xlabel('Tiempo (segundos)')

        am.plot(señal_seleccionada,linewidth=0.9)
        am.set_ylabel(f'Señal {columna_de_interes}')
        am.set_title(f'Archivo {columna_de_interes} en muestras')
        am.set_xlabel('Muestras')

        # Mostrar la figura
        # ax.grid(True)
        # ax.set_xlim(0, 900)
        am.set_xlim(limite_inferior, limite_superior)
        # ax.legend()
        plt.show()


def plot_batch(X,mask_p,mask_qrs,mask_t,key,onset,window,b):
    # Crear la figura y el gráfico
    fig, ax = plt.subplots(figsize=(10, 5))
    # Configurar el eje de tiempos
    muestras =  np.arange(onset, onset + window)
  
    # Representar las marcas como rayas verticales
    posiciones_lineas = np.where(mask_p == 1)[0]
    for marcas in posiciones_lineas:
        ax.vlines(onset + marcas, ymin=min(X), ymax=max(X), color=to_rgba('red', alpha=0.1), linestyle='-')
        
    posiciones_lineas = np.where(mask_qrs == 1)[0]
    for marcas in posiciones_lineas:
        ax.vlines(onset + marcas, ymin=min(X), ymax=max(X), color=to_rgba('green', alpha=0.1), linestyle='-')
        
    posiciones_lineas = np.where(mask_t == 1)[0]
    for marcas in posiciones_lineas:
        ax.vlines(onset + marcas, ymin=min(X), ymax=max(X), color=to_rgba('yellow', alpha=0.1), linestyle='-')
    
    ax.plot([], label='P', color='red', linestyle='-')
    ax.plot([], label='QRS', color='green', linestyle='-')
    ax.plot([], label='T', color='yellow', linestyle='-')

    # Trazar la señal de la columna de interés
    ax.plot(muestras,X,linewidth=0.9)
    ax.set_ylabel('Señal')
    ax.set_xlabel('Muestras')

    ax.set_title(f'Archivo {key}')

    # Mostrar la figura
    ax.set_xlim(onset, onset + window)
    ax.legend()
    plt.show(block=b)
    plt.pause(2)
    # plt.close()



# fname = '1.i'
# plot_batch(fname,2)
    