function posicion = buscar_ind(rind,onda)
    posicion = 0;
    for i=1:length(onda)
        str_ind = cell2mat(rind);
        str_ond = cell2mat(onda(i));
        if strcmp(str_ind, str_ond)
            posicion = i;
            break
        end
    end
end