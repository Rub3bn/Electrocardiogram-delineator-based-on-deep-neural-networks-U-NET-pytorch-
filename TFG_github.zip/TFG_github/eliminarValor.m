function miArraySinValor = eliminarValor(miArray, valorAEliminar)
    % Encontrar la posición del valor a eliminar
    posicionAEliminar = find(miArray == valorAEliminar);

    % Verificar si el valor está presente en el array
    if ~isempty(posicionAEliminar)
        % Crear un nuevo array sin el valor a eliminar
        miArraySinValor = [miArray(1:posicionAEliminar-1), miArray(posicionAEliminar+1:end)];
    else
        % Si el valor no está presente, devolver el array original
        miArraySinValor = miArray;
        disp('El valor no está presente en el array.');
    end
end