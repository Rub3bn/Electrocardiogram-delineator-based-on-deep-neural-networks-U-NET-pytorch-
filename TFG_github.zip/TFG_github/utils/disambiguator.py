import torch
import torch.nn as nn
import torch.optim as optimizer
from utils.losses import *
import torch.nn.init as init

def select_loss(loss):
    switcher = {
        'dice'              : DiceLoss,
        'jaccard'           : JaccardLoss
    }
    return switcher.get(loss.lower())    


def select_optimizer(model, optim, lr):
    switcher = {
        'adadelta'          : optimizer.Adadelta(model.parameters(), lr),
        'adagrad'           : optimizer.Adagrad(model.parameters(), lr),
        'adam'              : optimizer.Adam(model.parameters(), lr),
        'adamax'            : optimizer.Adamax(model.parameters(), lr),
        'rmsprop'           : optimizer.RMSprop(model.parameters(), lr),
        'sgd'               : optimizer.SGD(model.parameters(), lr)
    }
    return switcher.get(optim.lower())    


def select_kernel_initializer(kernel_init):
    switcher = {
        'zeros'             : lambda shape: init.constant_(torch.empty(*shape), 0),
        'ones'              : lambda shape: init.constant_(torch.empty(*shape), 1),
        'orthogonal'        : init.orthogonal_,
        'variance_scaling'  : init.variance_scaling_,
        'truncated_normal'  : lambda shape: init.trunc_normal_(torch.empty(*shape), mean=0, std=1),
        'random_uniform'    : init.uniform_,
        'random_normal'     : init.normal_,
        'identity'          : lambda shape: init.eye_(torch.empty(*shape)),
        'glorot_normal'     : init.xavier_normal_,
        'xavier_normal'     : init.xavier_normal_,
        'glorot_uniform'    : init.xavier_uniform_,
        'xavier_uniform'    : init.xavier_uniform_,
        'he_normal'         : init.kaiming_normal_,
        'he_uniform'        : init.kaiming_uniform_,
        'lecun_normal'      : init.kaiming_normal_,
        'lecun_uniform'     : init.kaiming_uniform_
    }
    return switcher.get(kernel_init.lower())

