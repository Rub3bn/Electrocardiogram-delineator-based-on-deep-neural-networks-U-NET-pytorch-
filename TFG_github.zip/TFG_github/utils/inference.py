import cv2
import math
import tqdm
import pandas
import torch
import numpy as np
import matplotlib.pyplot as plt
from utils.data_structures import series_to_supervised
from utils.data_structures import supervised_to_series
from data_plot import plot_batch


def predict(model, config, data, execinfo, results, results_CV2, retrain=False):
    # Load best model state
    # if (execinfo.state != None) and (model != None): backend.load_state(model, execinfo)
    state_dict = torch.load(execinfo.state, map_location=torch.device('cpu'))
    model.load_state_dict(state_dict)
    # Predict evaluation on test set
    for key in tqdm.tqdm(execinfo.test, ascii=True, desc="Test "):
        key = str(key)
        if key.startswith('sel'):
            keys = pandas.Index([f'{key}_{i}' for i in range(2)])
        else:
            keys = pandas.Index([f'{key}_{i}' for i in range(12)])
       
        # nombres = ['key_2', 'key_3', 'key_4', 'key_5', 'key_6', 'key_7', 'key_8', 'key_9', 'key_10', 'key_11']
        # #Si el nombre de los archivos solo contiene números será la database lobachecski, con 12 capas
        # tiene_letras = any(c.isalpha() for c in key)
        # key_n = {}
        # if not tiene_letras:
        #     for i,key in enumerate(nombres):
        #         key_n[i] = key

        if config.in_ch == 1: # Single lead
            predict_single(model, config, data, keys, results, results_CV2)

        # elif config.in_ch == 2: # Multi lead
        #     if retrain or (key_0 not in results.keys) or (key_0 not in results_CV2.keys) or (key_1 not in results.keys) or (key_1 not in results_CV2.keys):
        #         predict_multi(model, config, data, key_0, key_1, results, results_CV2)

        else:
            raise NotImplementedError("No batch generation strategy for " + str(config.in_ch) + " channels has been devised")

        # if not tiene_letras:
        #     for key in key_n:
        #         print('sisisi')
        #         predict_single(model, config, data, key, results, results_CV2)

def predict2(model, config, data, execinfo, results, results_CV2, retrain=False):
    # Load best model state
    # if (execinfo.state != None) and (model != None): backend.load_state(model, execinfo)
    state_dict = torch.load(execinfo.state, map_location=torch.device('cpu'))
    model.load_state_dict(state_dict)
    # Predict evaluation on test set
    for key in tqdm.tqdm(execinfo.valid, ascii=True, desc="valid "):
        key = str(key)
        if key.startswith('sel'):
            keys = pandas.Index([f'{key}_{i}' for i in range(2)])
        else:
            keys = pandas.Index([f'{key}_{i}' for i in range(12)])
       
        # nombres = ['key_2', 'key_3', 'key_4', 'key_5', 'key_6', 'key_7', 'key_8', 'key_9', 'key_10', 'key_11']
        # #Si el nombre de los archivos solo contiene números será la database lobachecski, con 12 capas
        # tiene_letras = any(c.isalpha() for c in key)
        # key_n = {}
        # if not tiene_letras:
        #     for i,key in enumerate(nombres):
        #         key_n[i] = key

        if config.in_ch == 1: # Single lead
            predict_single(model, config, data, keys, results, results_CV2)

        # elif config.in_ch == 2: # Multi lead
        #     if retrain or (key_0 not in results.keys) or (key_0 not in results_CV2.keys) or (key_1 not in results.keys) or (key_1 not in results_CV2.keys):
        #         predict_multi(model, config, data, key_0, key_1, results, results_CV2)

        else:
            raise NotImplementedError("No batch generation strategy for " + str(config.in_ch) + " channels has been devised")

        # if not tiene_letras:
        #     for key in key_n:
        #         print('sisisi')
        #         predict_single(model, config, data, key, results, results_CV2)

def predict_single(model, config, data, keys, results, results_CV2):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)  # Ensure the model is on the correct device
    for key in keys:
        
        # Step 1: Convert from series to supervised (with a finer stride for improved results in the window boundaries):
        series = series_to_supervised(data.dataset[key], config.window, config.window//8) #Crea la matriz con los datos por columnas (creo que cada fila es una ventana) de cada record del dataset

        # Step 2: Predict:
        seg = torch.tensor(np.zeros((series.shape[0],series.shape[1],config.out_ch)), dtype =torch.float32) #Contendra a las matrices de los tres canales
        seg2 = torch.tensor(np.zeros((series.shape[0],series.shape[1])), dtype =torch.float32)
        sub_batches = math.ceil(series.shape[0]/(config.batch_size)) #Ver el número de batches que nos hacen falta
        model.eval()
        with torch.no_grad():
            # Avoid GPU RAM management problems
            for b in range(sub_batches):
                batch = series[b*config.batch_size:(b+1)*config.batch_size,...] #Los tres puntos indican que se mantienen las dimensiones restantes de las series temporales
                batch = torch.tensor(batch[..., np.newaxis], dtype=torch.float32, device=device) #Añadir dimensionalidad (dimensión de los canales)
                batch = batch.permute(0, 2, 1)
            
                seg[b*config.batch_size:(b+1)*config.batch_size,...] = model(batch).permute(0, 2, 1) #Aquí se le pasa los datos de evaluación y se guardan los resultados batch a batch para evaluar la red
            
                seg[b*config.batch_size:(b+1)*config.batch_size,...] = seg[b*config.batch_size:(b+1)*config.batch_size,...]
            
                seg[b*config.batch_size:(b+1)*config.batch_size,...] = seg[b*config.batch_size:(b+1)*config.batch_size,...].softmax(dim=-1)
            
                seg2[b*config.batch_size:(b+1)*config.batch_size,...] = torch.argmax(seg[b*config.batch_size:(b+1)*config.batch_size,...], dim=-1)
            
                # for i in range(batch.shape[0]):
                #     plot_batch(batch[i,:],seg[i,:,0],seg[i,:,1],seg[i,:,2],key,i*config.window//8,config.window,False)
                #     plot_batch(batch[i,:],data.P.wave[key].values[i*config.window//8:i*config.window//8+config.window],data.QRS.wave[key].values[i*config.window//8:i*config.window//8+config.window],data.T.wave[key].values[i*config.window//8:i*config.window//8+config.window],key,i*config.window//8,config.window,True)
                # plot_batch(batch[1,:],seg[1,:,0],seg[1,:,1],seg[1,:,2],key,1*config.window//8+b*config.batch_size*config.window//8,config.window,False)
                # plot_batch(batch[1,:],data.P.wave[key].values[1*config.window//8:1*config.window//8+config.window],data.QRS.wave[key].values[1*config.window//8:1*config.window//8+config.window],data.T.wave[key].values[1*config.window//8:1*config.window//8+config.window],key,1*config.window//8+b*config.batch_size*config.window//8,config.window,True)
                    
                del batch #liberar la memoria de la variable batch ya que no se va a volver a usar


        #  Inicializar los tensores de salida llenos de ceros
        tensor_P = np.zeros_like(seg2)
        tensor_QRS = np.zeros_like(seg2)
        tensor_T = np.zeros_like(seg2)
        tensor_null = np.zeros_like(seg2)

        # Rellenar los tensores de salida con unos en las posiciones correspondientes
        tensor_P[seg2 == 0] = 1
        tensor_QRS[seg2 == 1] = 1
        tensor_T[seg2 == 2] = 1
        tensor_null[seg2 == 3] = 1
        # Step 3: Convert from supervised to series:
        
        lead_P   = supervised_to_series(tensor_P.squeeze(), config.window, config.window//8)[:config.max_size].round() #TOdos los elementos de las dimensiones anteriores y el primero de la ultima dimensión
        lead_QRS = supervised_to_series(tensor_QRS.squeeze(), config.window, config.window//8)[:config.max_size].round() #Si la última dimensión seleccionada con [..., 0] tiene tamaño 1, entonces squeeze() la eliminará
        lead_T   = supervised_to_series(tensor_T.squeeze(), config.window, config.window//8)[:config.max_size].round()
        lead_null   = supervised_to_series(tensor_null.squeeze(), config.window, config.window//8)[:config.max_size].round()
        
        # Step 4: Store in the output matrices:
        results.P.wave[key]   = lead_P
        results.QRS.wave[key] = lead_QRS
        results.T.wave[key]   = lead_T

        # Step 5.1: Apply morphological closing (QUE SIGNIFICA?)
        lead_P   = cv2.morphologyEx(lead_P,   cv2.MORPH_CLOSE, np.ones((config.element_size,))) # Close holes in segmentations 
        lead_QRS = cv2.morphologyEx(lead_QRS, cv2.MORPH_CLOSE, np.ones((config.element_size,))) # Close holes in segmentations
        lead_T   = cv2.morphologyEx(lead_T,   cv2.MORPH_CLOSE, np.ones((config.element_size,))) # Close holes in segmentations

        lead_P   = cv2.morphologyEx(lead_P,   cv2.MORPH_OPEN, np.ones((5,))).squeeze()  # Erosion + Dilation to get rid of noisy activations
        lead_QRS = cv2.morphologyEx(lead_QRS, cv2.MORPH_OPEN, np.ones((5,))).squeeze()  # Erosion + Dilation to get rid of noisy activations
        lead_T   = cv2.morphologyEx(lead_T,   cv2.MORPH_OPEN, np.ones((5,))).squeeze()  # Erosion + Dilation to get rid of noisy activations

        results_CV2.P.wave[key]   = lead_P
        results_CV2.QRS.wave[key] = lead_QRS
        results_CV2.T.wave[key]   = lead_T

        # Mark as computed
        results.keys.append(key)
        results_CV2.keys.append(key)

        # Step 6: Avoid GPU memory filled with old data
        del series, seg


def predict_multi(model, config, data, key_0, key_1, results, results_CV2):
    # Step 1: Convert from series to supervised (with a finer stride for improved results in the window boundaries):
    series_0 = series_to_supervised(data.dataset[key_0], config.window, config.window//8)
    series_1 = series_to_supervised(data.dataset[key_1], config.window, config.window//8)

    # Combine both series
    series = np.dstack((series_0, series_1)) # Stack on the channels

    # Step 2: Predict:
    seg = np.zeros((series.shape[0],series.shape[1],config.out_ch)) # Segmentation storage
    sub_batches = math.ceil(series.shape[0]/(config.batch_size))    # Number of batches

    # Avoid GPU RAM management problems
    model.eval()
    with torch.no_grad():
        for b in range(sub_batches):
            batch = series[b*config.batch_size:(b+1)*config.batch_size,...]
            batch = torch.tensor(batch[:,:,np.newaxis,:])
            seg[b*config.batch_size:(b+1)*config.batch_size,...] = model(batch)
          
            seg[b*config.batch_size:(b+1)*config.batch_size,...] = seg[b*config.batch_size:(b+1)*config.batch_size,...].softmax(dim=1)
            del batch

    # Step 3: Convert from supervised to series:
    lead_P   = supervised_to_series(seg[...,0].squeeze(), config.window, config.window//8)[:config.max_size].round()
    lead_QRS = supervised_to_series(seg[...,1].squeeze(), config.window, config.window//8)[:config.max_size].round()
    lead_T   = supervised_to_series(seg[...,2].squeeze(), config.window, config.window//8)[:config.max_size].round()
    
    # Step 4: Store in the output matrices:
    results.P.wave[key_0]   = lead_P
    results.QRS.wave[key_0] = lead_QRS
    results.T.wave[key_0]   = lead_T

    results.P.wave[key_1]   = lead_P
    results.QRS.wave[key_1] = lead_QRS
    results.T.wave[key_1]   = lead_T

    # Step 5.1: Apply morphological closing
    lead_P   = cv2.morphologyEx(lead_P,   cv2.MORPH_CLOSE, np.ones((config.element_size,))) # Close holes in segmentations
    lead_QRS = cv2.morphologyEx(lead_QRS, cv2.MORPH_CLOSE, np.ones((config.element_size,))) # Close holes in segmentations
    lead_T   = cv2.morphologyEx(lead_T,   cv2.MORPH_CLOSE, np.ones((config.element_size,))) # Close holes in segmentations

    lead_P   = cv2.morphologyEx(lead_P,   cv2.MORPH_OPEN, np.ones((5,))).squeeze()  # Erosion + Dilation to get rid of noisy activations
    lead_QRS = cv2.morphologyEx(lead_QRS, cv2.MORPH_OPEN, np.ones((5,))).squeeze()  # Erosion + Dilation to get rid of noisy activations
    lead_T   = cv2.morphologyEx(lead_T,   cv2.MORPH_OPEN, np.ones((5,))).squeeze()  # Erosion + Dilation to get rid of noisy activations

    results_CV2.P.wave[key_0]   = lead_P
    results_CV2.QRS.wave[key_0] = lead_QRS
    results_CV2.T.wave[key_0]   = lead_T

    results_CV2.P.wave[key_1]   = lead_P
    results_CV2.QRS.wave[key_1] = lead_QRS
    results_CV2.T.wave[key_1]   = lead_T

    # Mark as computed
    results.keys.append(key_0)
    results.keys.append(key_1)
    results_CV2.keys.append(key_0)
    results_CV2.keys.append(key_1)

    # Step 6: Avoid GPU memory filled with old data
    del series_0, series_1, series, seg


