import torch
import torch.nn as nn

class ResidualBlock(nn.Module):
    def __init__(self, in_chans, out_chans, padding="same"):
        super().__init__()
        self.conv1 = nn.Conv1d(in_chans, out_chans, 3, padding=padding)
        self.bn1 = nn.BatchNorm1d(out_chans)
        self.relu = nn.ReLU()
        self.conv2 = nn.Conv1d(out_chans, out_chans, 3, padding=padding)
        self.bn2 = nn.BatchNorm1d(out_chans)

        self.residual_connection = nn.Sequential()
        if in_chans != out_chans:
            self.residual_connection = nn.Sequential(
                nn.Conv1d(in_chans, out_chans, kernel_size=1),
                nn.BatchNorm1d(out_chans)
            )
            
    def forward(self, x):
        residual = self.residual_connection(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out += residual
        out = self.relu(out)
        return out

class EncoderBlock(nn.Module):
    def __init__(self, in_chans, out_chans, layers=3, sampling_factor=2, padding="same"):
        super().__init__()
        self.encoder = nn.ModuleList()
        self.encoder.append(ResidualBlock(in_chans, out_chans, padding))
        for _ in range(layers - 1):
            self.encoder.append(ResidualBlock(out_chans, out_chans, padding))
        self.mp = nn.MaxPool1d(sampling_factor)
        
    def forward(self, x):
        for enc in self.encoder:
            x = enc(x)
        mp_out = self.mp(x)
        return mp_out, x

class DecoderBlock(nn.Module):
    def __init__(self, in_chans, out_chans, layers=3, skip_connection=True, sampling_factor=2, padding="same"):
        super().__init__()
        self.skip_connection = skip_connection
        skip_factor = 2 if skip_connection else 1
        self.tconv = nn.ConvTranspose1d(in_chans, out_chans, sampling_factor, stride=sampling_factor)
        self.decoder = nn.ModuleList()
        self.decoder.append(ResidualBlock(in_chans, out_chans, padding))
        for _ in range(layers - 1):
            self.decoder.append(ResidualBlock(out_chans, out_chans, padding))

    def forward(self, x, enc_features):
        x = self.tconv(x)
        if self.skip_connection:
            x = torch.cat((x, enc_features), dim=1)
        for dec in self.decoder:
            x = dec(x)
        return x

class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, 1)

    def forward(self, x):
        return self.conv(x)

class UNet(nn.Module):
    def __init__(self, nclass=1, in_chans=1, depth=5, layers=3, sampling_factor=2, skip_connection=True, padding="same"):
        super().__init__()
        self.encoder = nn.ModuleList()
        self.decoder = nn.ModuleList()

        out_chans = 32
        for _ in range(depth):
            self.encoder.append(EncoderBlock(in_chans, out_chans, layers, sampling_factor, padding))
            in_chans, out_chans = out_chans, out_chans * 2

        out_chans = in_chans // 2
        for _ in range(depth - 1):
            self.decoder.append(DecoderBlock(in_chans, out_chans, layers, skip_connection, sampling_factor, padding))
            in_chans, out_chans = out_chans, out_chans // 2

        self.outc = OutConv(32, 4)

    def forward(self, x):
        encoded = []
        for enc in self.encoder:
            x, enc_output = enc(x)
            encoded.append(enc_output)

        x = encoded.pop()
        for dec in self.decoder:
            enc_output = encoded.pop()
            x = dec(x, enc_output)

        return self.outc(x)