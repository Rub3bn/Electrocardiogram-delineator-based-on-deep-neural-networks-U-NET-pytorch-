import numpy as np
import os
import pandas
from utils.data_structures import MetricsStorage
from utils.inference import predict
import cv2
import tqdm
from utils.data_structures import save_fiducials


def extract(model, config, data, execinfo, results, results_CV2, recompute):
    """Wave evaluation"""
    predict(model, config, data, execinfo, results, results_CV2, recompute)

    # IF IT'S NOT THE OVERALL EVALUATION
    leads = pandas.Index(execinfo.test).astype(str) + '_0'
    print('leads')
    print(leads)
    retrieve_fiducials(results,     leads, recompute)
    retrieve_fiducials(results_CV2, leads, recompute)

    rPWave = pandas.DataFrame()
    rPon = dict()
    rPoff = dict()
    for key in tqdm.tqdm(execinfo.test, ascii=True, desc="Test "):
        key_0 = str(key) + '_0'
        # key_1 = key + '_1'
        rPWave[key_0] = results_CV2.P.wave[key_0]
        rPon[key_0] = results_CV2.P.onset[key_0]
        rPoff[key_0] = results_CV2.P.offset[key_0]
        # rPWave[key_1] = results.P.wave[key_1]
    rPWave.to_csv(os.path.join("Results_net/",'rPwave.csv'))
    save_fiducials(rPon, os.path.join("Results_net/",'rPon.csv'))
    save_fiducials(rPoff, os.path.join("Results_net/",'rPoff.csv'))

    rQRSWave = pandas.DataFrame()
    rQRSon = dict()
    rQRSoff = dict()
    for key in tqdm.tqdm(execinfo.test, ascii=True, desc="Test "):
        key_0 = str(key) + '_0'
        rQRSWave[key_0] = results_CV2.QRS.wave[key_0]
        rQRSon[key_0] = results_CV2.QRS.onset[key_0]
        rQRSoff[key_0] = results_CV2.QRS.offset[key_0]
    rQRSWave.to_csv(os.path.join("Results_net/",'rQRSwave.csv'))
    save_fiducials(rQRSon, os.path.join("Results_net/",'rQRSon.csv'))
    save_fiducials(rQRSoff, os.path.join("Results_net/",'rQRSoff.csv'))

    rTWave = pandas.DataFrame()
    rTon = dict()
    rToff = dict()
    for key in tqdm.tqdm(execinfo.test, ascii=True, desc="Test "):
        key_0 = str(key) + '_0'
        rTWave[key_0] = results_CV2.T.wave[key_0]
        rTon[key_0] = results_CV2.T.onset[key_0]
        rToff[key_0] = results_CV2.T.offset[key_0]
    rTWave.to_csv(os.path.join("Results_net/",'rTwave.csv'))
    save_fiducials(rTon, os.path.join("Results_net/",'rTon.csv'))
    save_fiducials(rToff, os.path.join("Results_net/",'rToff.csv'))


def retrieve_fiducials(results, test, recompute=False):
    wave_fiducials(results.P,   test, recompute) #Extrae onset ofset y peak
    wave_fiducials(results.QRS, test, recompute)
    wave_fiducials(results.T,   test, recompute)


def wave_fiducials(wave, test, recompute=False):
    for k in test:
        if recompute or (k not in wave.onset.keys()):
            seg = np.diff(np.pad(wave.wave[k].values,((1,1),),'constant', constant_values=0),axis=-1)
            
            wave.onset[k]  = np.where(seg ==  1.)[0]
            wave.offset[k] = np.where(seg == -1.)[0] - 1
            wave.peak[k]   = (wave.onset[k] + wave.offset[k])//2
