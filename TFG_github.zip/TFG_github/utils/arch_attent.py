import torch
import torch.nn as nn
import torch.nn.functional as F

class AttentionBlock(nn.Module):
    def __init__(self, F_g, F_l, F_int):
        super(AttentionBlock, self).__init__()
        self.W_g = nn.Sequential(
            nn.Conv1d(F_g, F_int, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm1d(F_int)
        )

        self.W_x = nn.Sequential(
            nn.Conv1d(F_l, F_int, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm1d(F_int)
        )

        self.psi = nn.Sequential(
            nn.Conv1d(F_int, 1, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm1d(1),
            nn.Sigmoid()
        )
        self.relu = nn.ReLU(inplace=True)

    def forward(self, g, x):
        g1 = self.W_g(g)
        x1 = self.W_x(x)
        psi = self.relu(g1 + x1)
        psi = self.psi(psi)
        return x * psi

class EncoderBlock(nn.Module):
    def __init__(self, in_chans, out_chans, layers=3, sampling_factor=2):
        super(EncoderBlock, self).__init__()
        self.encoder = nn.ModuleList()
        self.encoder.append(nn.Conv1d(in_chans, out_chans, kernel_size=3, padding=1, stride=1))
        self.encoder.append(nn.BatchNorm1d(out_chans))
        self.encoder.append(nn.ReLU(inplace=True))
        for _ in range(layers - 1):
            self.encoder.append(nn.Conv1d(out_chans, out_chans, kernel_size=3, padding=1, stride=1))
            self.encoder.append(nn.BatchNorm1d(out_chans))
            self.encoder.append(nn.ReLU(inplace=True))
        self.mp = nn.MaxPool1d(sampling_factor)

    def forward(self, x):
        for layer in self.encoder:
            x = layer(x)
        mp_out = self.mp(x)
        return mp_out, x

class DecoderBlock(nn.Module):
    def __init__(self, in_chans, out_chans, layers=3, skip_connection=True, sampling_factor=2):
        super(DecoderBlock, self).__init__()
        self.skip_connection = skip_connection
        self.tconv = nn.ConvTranspose1d(in_chans, out_chans, kernel_size=sampling_factor, stride=sampling_factor)
        self.attention = AttentionBlock(F_g=out_chans, F_l=out_chans, F_int=out_chans // 2)
        self.decoder = nn.ModuleList()
        self.decoder.append(nn.Conv1d(in_chans, out_chans, kernel_size=3, padding=1, stride=1))
        self.decoder.append(nn.BatchNorm1d(out_chans))
        self.decoder.append(nn.ReLU(inplace=True))
        for _ in range(layers - 1):
            self.decoder.append(nn.Conv1d(out_chans, out_chans, kernel_size=3, padding=1, stride=1))
            self.decoder.append(nn.BatchNorm1d(out_chans))
            self.decoder.append(nn.ReLU(inplace=True))

    def forward(self, x, enc_features):
        x = self.tconv(x)
        if self.skip_connection:
            enc_features = self.attention(g=x, x=enc_features)
            x = torch.cat((x, enc_features), dim=1)
        for layer in self.decoder:
            x = layer(x)
        return x

class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        return self.conv(x)

class UNet(nn.Module):
    def __init__(self, nclass=1, in_chans=1, depth=5, layers=3, sampling_factor=2, skip_connection=True):
        super(UNet, self).__init__()
        self.encoder = nn.ModuleList()
        self.decoder = nn.ModuleList()

        out_chans = 32
        for _ in range(depth):
            self.encoder.append(EncoderBlock(in_chans, out_chans, layers, sampling_factor))
            in_chans, out_chans = out_chans, out_chans * 2

        out_chans = in_chans // 2
        for _ in range(depth - 1):
            self.decoder.append(DecoderBlock(in_chans, out_chans, layers, skip_connection, sampling_factor))
            in_chans, out_chans = out_chans, out_chans // 2

        self.outc = OutConv(32, 4)

    def forward(self, x):
        encoded = []
        for enc in self.encoder:
            x, enc_output = enc(x)
            encoded.append(enc_output)

        x = encoded.pop()
        for dec in self.decoder:
            enc_output = encoded.pop()
            x = dec(x, enc_output)

        return self.outc(x)