import torch
import torch.nn as nn

def DiceLoss(y_true, y_pred):
    smooth = torch.finfo(y_true.dtype).eps
    y_true_f = y_true.view(y_true.size(0), -1)
    y_pred_f = y_pred.view(y_pred.size(0), -1)
    intersection = torch.sum(y_true_f * y_pred_f, dim=-1, keepdim=True)
    union = torch.sum(y_true_f, dim=-1, keepdim=True) + torch.sum(y_pred_f, dim=-1, keepdim=True)
    dice = torch.mean((2. * intersection + 1. + smooth) / (union + 1. + smooth))
    return 1 - dice


def JaccardLoss(y_true, y_pred):
    smooth = torch.finfo(y_true.dtype).eps
    y_true_f = y_true.view(y_true.size(0), -1)
    y_pred_f = y_pred.view(y_pred.size(0), -1)
    intersection = torch.sum(y_true_f * y_pred_f, dim=-1, keepdim=True)
    union = torch.sum(y_true_f, dim=-1, keepdim=True) + torch.sum(y_pred_f, dim=-1, keepdim=True)
    jacc = torch.mean((intersection + smooth) / (union - intersection + smooth))
    return 1 - jacc
