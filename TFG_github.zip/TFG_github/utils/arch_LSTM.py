import torch
import torch.nn as nn

class EncoderBlock(nn.Module):        
    def __init__(self, in_chans, out_chans, layers, sampling_factor=2, padding="same"):
        super().__init__()
        self.encoder = nn.ModuleList()
        self.encoder.append(nn.Conv1d(in_chans, out_chans, 3, 1, padding=padding))
        self.encoder.append(nn.BatchNorm1d(out_chans))
        self.encoder.append(nn.ReLU())
        self.encoder.append(nn.Dropout(0.25))
        for _ in range(layers):
            self.encoder.append(nn.Conv1d(out_chans, out_chans, 3, 1, padding=padding))
            self.encoder.append(nn.BatchNorm1d(out_chans))
            self.encoder.append(nn.ReLU())
            self.encoder.append(nn.Dropout(0.25))
        self.mp = nn.MaxPool1d(sampling_factor)

    def forward(self, x):
        for enc in self.encoder:
            x = enc(x)
        mp_out = self.mp(x)
        return mp_out, x

class DecoderBlock(nn.Module):
    def __init__(self, in_chans, out_chans, layers, skip_connection=True, sampling_factor=2, padding="same"):
        super().__init__()
        skip_factor = 1 if skip_connection else 2
        self.decoder = nn.ModuleList()
        self.tconv = nn.ConvTranspose1d(in_chans, in_chans//2, sampling_factor, sampling_factor)

        self.decoder.append(nn.Conv1d(in_chans//skip_factor, out_chans, 3, 1, padding=padding))
        self.decoder.append(nn.BatchNorm1d(out_chans))
        self.decoder.append(nn.ReLU())
        self.decoder.append(nn.Dropout(0.25))

        for _ in range(layers):
            self.decoder.append(nn.Conv1d(out_chans, out_chans, 3, 1, padding=padding))
            self.decoder.append(nn.BatchNorm1d(out_chans))
            self.decoder.append(nn.ReLU())
            self.decoder.append(nn.Dropout(0.25))

        self.skip_connection = skip_connection
        self.padding = padding

    def forward(self, x, enc_features):
        x = self.tconv(x)
        if self.skip_connection:
            if self.padding != "same":
                w = x.size(-1)
                c = (enc_features.size(-1) - w) // 2
                enc_features = enc_features[:,:,c:c+w,c:c+w]
            x = torch.cat((enc_features, x), dim=1)
        for dec in self.decoder:
            x = dec(x)
        return x

class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, 1, 1)

    def forward(self, x):
        x = self.conv(x)
        return x

class LSTMBlock(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, batch_first=True):
        super(LSTMBlock, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=batch_first, bidirectional=True)
        self.linear = nn.Linear(hidden_size * 2, hidden_size)

    def forward(self, x):
        # Save the input for the residual connection
        residual = x
        # Transpose x to (batch_size, seq_len, input_size)
        x = x.permute(0, 2, 1)
        # Pass through LSTM
        x, _ = self.lstm(x)
        # Pass through Linear layer to reduce the dimensionality
        x = self.linear(x)
        # Transpose x back to (batch_size, hidden_size, seq_len)
        x = x.permute(0, 2, 1)
        # Add the residual connection
        x = x + residual
        return x

class UNet(nn.Module):
    def __init__(self, nclass=1, in_chans=1, depth=5, layers=3, sampling_factor=2, skip_connection=True, padding="same"):
        super().__init__()
        self.encoder = nn.ModuleList()
        self.decoder = nn.ModuleList()

        out_chans = 32
        for _ in range(depth):
            self.encoder.append(EncoderBlock(in_chans, out_chans, layers, sampling_factor, padding))
            in_chans, out_chans = out_chans, out_chans*2

        # Define LSTM block with 2 layers
        self.lstm = LSTMBlock(in_chans, in_chans, num_layers=2)

        out_chans = in_chans // 2
        for _ in range(depth-1):
            self.decoder.append(DecoderBlock(in_chans, out_chans, layers, skip_connection, sampling_factor, padding))
            in_chans, out_chans = out_chans, out_chans//2
        self.outc = OutConv(32, 4)

    def forward(self, x):
        encoded = []
        for enc in self.encoder:
            x, enc_output = enc(x)
            encoded.append(enc_output)
        x = encoded.pop()
        
        # Apply LSTM block
        x = self.lstm(x)

        for dec in self.decoder:
            enc_output = encoded.pop()
            x = dec(x, enc_output)

        # Return the logits
        return self.outc(x)