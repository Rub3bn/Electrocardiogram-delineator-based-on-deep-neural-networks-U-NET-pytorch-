import torch
import numpy as np
import torch.nn as nn

class EncoderBlock(nn.Module):        
    # Consists of Conv -> ReLU -> MaxPool
    def __init__(self, in_chans, out_chans, layers, sampling_factor=2, padding="same"):
        super().__init__()
        self.encoder = nn.ModuleList()
        self.encoder.append(nn.Conv1d(in_chans, out_chans, 3, 1, padding=padding))
        self.encoder.append(nn.BatchNorm1d(out_chans))
        self.encoder.append(nn.ReLU())
        self.encoder.append(nn.Dropout(0.25))
        for _ in range(layers):
            self.encoder.append(nn.Conv1d(out_chans, out_chans, 3, 1, padding=padding))
            self.encoder.append(nn.BatchNorm1d(out_chans))
            self.encoder.append(nn.ReLU())
            self.encoder.append(nn.Dropout(0.25))
        self.mp = nn.MaxPool1d(sampling_factor)
    def forward(self, x):
        for enc in self.encoder:
            x = enc(x)
        mp_out = self.mp(x)
        return mp_out, x

class DecoderBlock(nn.Module):
    def __init__(self, in_chans, out_chans, layers, skip_connection=True, sampling_factor=2, padding="same"):
        super().__init__()
        skip_factor = 1 if skip_connection else 2
        self.decoder = nn.ModuleList()
        self.tconv = nn.ConvTranspose1d(in_chans, in_chans//2, sampling_factor, sampling_factor)

        self.decoder.append(nn.Conv1d(in_chans//skip_factor, out_chans, 3, 1, padding=padding))
        self.decoder.append(nn.BatchNorm1d(out_chans))
        self.decoder.append(nn.ReLU())
        self.decoder.append(nn.Dropout(0.25))

        for _ in range(layers):
            self.decoder.append(nn.Conv1d(out_chans, out_chans, 3, 1, padding=padding))
            self.decoder.append(nn.BatchNorm1d(out_chans))
            self.decoder.append(nn.ReLU())
            self.decoder.append(nn.Dropout(0.25))

        self.skip_connection = skip_connection
        self.padding = padding
    def forward(self, x, enc_features):
        x = self.tconv(x)
        if self.skip_connection:
            if self.padding != "same":
                # Crop the enc_features to the same size as input
                w = x.size(-1)
                c = (enc_features.size(-1) - w) // 2
                enc_features = enc_features[:,:,c:c+w,c:c+w]
            x = torch.cat((enc_features, x), dim=1)
        for dec in self.decoder:
            x = dec(x)
        return x

class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv1d(in_channels, out_channels,1,1)
    def forward(self, x):
        x = self.conv(x)
        # x = x.softmax(dim=1)  # Aplicar softmax a lo largo de la dimensión de clases
        #La capa softmax la comento porque crossentropy acepta resultados de antes de esta capa
        #Acordarse de añadir softmax al hacer la inferencia (mirar correo antonio miguel)
        return x

class UNet(nn.Module):
    def __init__(self, nclass=1, in_chans=1, depth=5, layers=3, sampling_factor=2, skip_connection=True, padding="same"):
        super().__init__()
        self.encoder = nn.ModuleList()
        self.decoder = nn.ModuleList()

        out_chans = 32
        for _ in range(depth):
            self.encoder.append(EncoderBlock(in_chans, out_chans, layers, sampling_factor, padding))
            in_chans, out_chans = out_chans, out_chans*2

        out_chans = in_chans // 2
        for _ in range(depth-1):
            self.decoder.append(DecoderBlock(in_chans, out_chans, layers, skip_connection, sampling_factor, padding))
            in_chans, out_chans = out_chans, out_chans//2
        self.outc = (OutConv(32, 4))

    def forward(self, x):
        encoded = []
        for enc in self.encoder:
            x, enc_output = enc(x)
            encoded.append(enc_output)
        x = encoded.pop()
        for dec in self.decoder:
            enc_output = encoded.pop()
            x = dec(x, enc_output)

        # Return the logits
        return self.outc(x)

# class AtrousMiddleModule(nn.Module):
#     def __init__(self, in_channels, out_channels,dropout, mid_channels=None):
#         super().__init__()
#         self.pre = nn.Sequential(
#             nn.ReLU(inplace=True),
#             nn.BatchNorm1d(out_channels),
#             nn.Dropout(dropout),
#         )
#         self.atrous1 =nn.Conv1d(out_channels, out_channels, kernel_size=3, padding=1, bias=False, dilation=1)
#         self.atrous6 =nn.Conv1d(out_channels, out_channels, kernel_size=3, padding=1, bias=False, dilation=6)
#         self.atrous12 =nn.Conv1d(out_channels, out_channels, kernel_size=3, padding=1, bias=False, dilation=12)
#         self.atrous18 =nn.Conv1d(out_channels, out_channels, kernel_size=3, padding=1, bias=False, dilation=18)

        
#     def forward(self, x):
#         x = self.pre(x)
#         m1 = self.atrous1(x)
#         m6 = self.atrous6(x)
#         m12 = self.atrous12(x)
#         m18 = self.atrous18(x)

#         # Calcula la media global
#         mgap = nn.AdaptiveAvgPool1d(1)(m1) if (x.shape[1] != 1024) else nn.AdaptiveAvgPool1d(1)(x)
#         mgap = mgap.repeat(1, x.shape[1], 1)

#         # Concatenar tensores
#         m_concat = torch.cat((m1, m6, m12, m18, mgap), dim=2)