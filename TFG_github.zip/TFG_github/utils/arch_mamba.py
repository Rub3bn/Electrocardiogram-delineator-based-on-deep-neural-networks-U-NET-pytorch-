import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint
from mamba_ssm import Mamba

# Definición de FeedForward, BMambaLayer y MambaLayer
class FeedForward(torch.nn.Module):
    def __init__(self, d_model=512, d_ff=1024, dropout=0.1, **kwargs):
        super().__init__()
        self.ff = torch.nn.Sequential(
            torch.nn.LayerNorm(d_model),
            torch.nn.Linear(d_model, d_ff),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout),
            torch.nn.Linear(d_ff, d_model),
        )

    def forward(self, x):
        return self.ff(x)

class BMambaLayer(torch.nn.Module):
    def __init__(self, hidden_dim=512, d_state=16, d_conv=4, expand=2, **kwargs):
        super().__init__()
        self.norm = torch.nn.LayerNorm(hidden_dim)
        self.mamba1 = Mamba(d_model=hidden_dim, d_state=d_state, d_conv=d_conv, expand=expand)
        self.mamba2 = Mamba(d_model=hidden_dim, d_state=d_state, d_conv=d_conv, expand=expand)
        self.fc = torch.nn.Linear(2*hidden_dim, hidden_dim)
    
    def forward(self, x):
        x = self.norm(x)
        x1 = self.mamba1(x)
        x2 = self.mamba2(x.flip(1)).flip(1)
        x = torch.cat([x1, x2], dim=-1)
        x = self.fc(x)
        return x

class MambaLayer(torch.nn.Module):
    def __init__(self, hidden_dim=512, d_state=16, d_conv=4, expand=2, **kwargs):
        super().__init__()
        self.norm = torch.nn.LayerNorm(hidden_dim)
        self.mamba = Mamba(d_model=hidden_dim, d_state=d_state, d_conv=d_conv, expand=expand)

    def forward(self, x):
        x = self.norm(x)
        return self.mamba(x)

class Encoder(torch.nn.Module):
    def __init__(self, hidden_dim=512, nb_layers=6, seq_len=1000, **kwargs):
        super().__init__()
        self.seq = torch.nn.ModuleList([BMambaLayer(hidden_dim=hidden_dim,**kwargs) for _ in range(nb_layers)])
        self.ff = torch.nn.ModuleList([FeedForward(hidden_dim=hidden_dim,**kwargs) for _ in range(nb_layers)])
        
    def forward(self, x):
        b, t, d = x.shape
        for seq, ff in zip(self.seq, self.ff):
            x = x + seq(x)
            x = x + ff(x)
        return x

SeqModel = Encoder

# Definición de EncoderBlock, DecoderBlock, OutConv
class EncoderBlock(nn.Module):        
    def __init__(self, in_chans, out_chans, layers, sampling_factor=2, padding="same"):
        super().__init__()
        self.encoder = nn.ModuleList()
        self.encoder.append(nn.Conv1d(in_chans, out_chans, 3, 1, padding=padding))
        self.encoder.append(nn.BatchNorm1d(out_chans))
        self.encoder.append(nn.ReLU())
        self.encoder.append(nn.Dropout(0.25))
        for _ in range(layers):
            self.encoder.append(nn.Conv1d(out_chans, out_chans, 3, 1, padding=padding))
            self.encoder.append(nn.BatchNorm1d(out_chans))
            self.encoder.append(nn.ReLU())
            self.encoder.append(nn.Dropout(0.25))
        self.mp = nn.MaxPool1d(sampling_factor)

    def forward(self, x):
        for enc in self.encoder:
            x = enc(x)
        mp_out = self.mp(x)
        return mp_out, x

class DecoderBlock(nn.Module):
    def __init__(self, in_chans, out_chans, layers, skip_connection=True, sampling_factor=2, padding="same"):
        super().__init__()
        skip_factor = 1 if skip_connection else 2
        self.decoder = nn.ModuleList()
        self.tconv = nn.ConvTranspose1d(in_chans, in_chans//2, sampling_factor, sampling_factor)

        self.decoder.append(nn.Conv1d(in_chans//skip_factor, out_chans, 3, 1, padding=padding))
        self.decoder.append(nn.BatchNorm1d(out_chans))
        self.decoder.append(nn.ReLU())
        self.decoder.append(nn.Dropout(0.25))

        for _ in range(layers):
            self.decoder.append(nn.Conv1d(out_chans, out_chans, 3, 1, padding=padding))
            self.decoder.append(nn.BatchNorm1d(out_chans))
            self.decoder.append(nn.ReLU())
            self.decoder.append(nn.Dropout(0.25))

        self.skip_connection = skip_connection
        self.padding = padding

    def forward(self, x, enc_features):
        x = self.tconv(x)
        if self.skip_connection:
            if self.padding != "same":
                w = x.size(-1)
                c = (enc_features.size(-1) - w) // 2
                enc_features = enc_features[:,:,c:c+w,c:c+w]
            x = torch.cat((enc_features, x), dim=1)
        for dec in self.decoder:
            x = dec(x)
        return x

class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, 1, 1)

    def forward(self, x):
        x = self.conv(x)
        return x

# Definición de UNet con Encoder en lugar de LSTM
class UNet(nn.Module):
    def __init__(self, nclass=1, in_chans=1, depth=5, layers=3, sampling_factor=2, skip_connection=True, padding="same"):
        super().__init__()
        self.encoder = nn.ModuleList()
        self.decoder = nn.ModuleList()

        out_chans = 32
        for _ in range(depth):
            self.encoder.append(EncoderBlock(in_chans, out_chans, layers, sampling_factor, padding))
            in_chans, out_chans = out_chans, out_chans*2

        # Define Encoder block (Mamba) with appropriate parameters
        self.seq_model = Encoder(hidden_dim=in_chans, nb_layers=6, seq_len=1000)

        out_chans = in_chans // 2
        for _ in range(depth-1):
            self.decoder.append(DecoderBlock(in_chans, out_chans, layers, skip_connection, sampling_factor, padding))
            in_chans, out_chans = out_chans, out_chans//2
        self.outc = OutConv(32, 4)

    def forward(self, x):
        encoded = []
        for enc in self.encoder:
            x, enc_output = enc(x)
            encoded.append(enc_output)
        x = encoded.pop()

        # Apply Encoder (Mamba) block
        x = self.seq_model(x)

        for dec in self.decoder:
            enc_output = encoded.pop()
            x = dec(x, enc_output)

        # Return the logits
        return self.outc(x)