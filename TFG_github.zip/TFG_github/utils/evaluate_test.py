import numpy as np
import os
import pandas
from utils.data_structures import MetricsStorage
from utils.inference import predict2
import cv2
from utils.data_structures import save_fiducials
import tqdm

def evaluate(model, config, data, execinfo, metrics, metrics_CV2, results, results_CV2, recompute):
    """Wave evaluation"""
    predict2(model, config, data, execinfo, results, results_CV2, recompute)


    labels = pandas.Index(execinfo.valid).astype(str)
    if labels[0].startswith('sel'):
        print('comprobar')
        leads = pandas.Index([f'{label}_{i}' for label in labels for i in range(2)])
        print(leads)
    else:
        leads = pandas.Index([f'{label}_{i}' for label in labels for i in range(12)])

    print('leads')
    print(leads)
    retrieve_fiducials(results,     leads, recompute)
    retrieve_fiducials(results_CV2, leads, recompute)

    
    ### COMPUTE METRICS ###
    metrics     = metric_computation(config, data, metrics,     results,     execinfo.valid, recompute)
    metrics_CV2 = metric_computation(config, data, metrics_CV2, results_CV2, execinfo.valid, recompute)

    ### SAVE RESULTS ###
    path_CV2 = os.path.splitext(execinfo.results)[0] + '_CV2' + os.path.splitext(execinfo.results)[1]
    # precision_P, recall_P, precision_QRS, recall_QRS, precision_T, recall_T = save_results(metrics,     config, execinfo.test, execinfo.results)
    precision_P, recall_P, precision_QRS, recall_QRS, precision_T, recall_T, onset_P, offset_P, dice_P, onset_QRS, offset_QRS, dice_QRS, onset_T, offset_T, dice_T = save_results(metrics_CV2, config, execinfo.valid, path_CV2)

    return precision_P, recall_P, precision_QRS, recall_QRS, precision_T, recall_T, onset_P, offset_P, dice_P, onset_QRS, offset_QRS, dice_QRS, onset_T, offset_T, dice_T 

def save_results(metrics, config, test, output_path):
    if output_path[-4:].lower() != '.csv': output_path += '.csv'
    res = dict()
    print('p')
    print(metrics.P)
    print('qrs')
    print(metrics.QRS)
    print('t')
    print(metrics.T)
    precision_P, recall_P, onset_P, offset_P, dice_P           = wave_evaluation_from_metrics(metrics.P,  test) 
    precision_QRS, recall_QRS, onset_QRS, offset_QRS, dice_QRS = wave_evaluation_from_metrics(metrics.QRS,test) 
    precision_T, recall_T, onset_T, offset_T, dice_T           = wave_evaluation_from_metrics(metrics.T,  test) 

    return precision_P, recall_P, precision_QRS, recall_QRS, precision_T, recall_T, onset_P, offset_P, dice_P, onset_QRS, offset_QRS, dice_QRS, onset_T, offset_T, dice_T 

def retrieve_fiducials(results, test, recompute=False):
    wave_fiducials(results.P,   test, recompute)
    wave_fiducials(results.QRS, test, recompute)
    wave_fiducials(results.T,   test, recompute)


def wave_fiducials(wave, test, recompute=False):
    for k in test:
        if recompute or (k not in wave.onset.keys()):
            seg = np.diff(np.pad(wave.wave[k].values,((1,1),),'constant', constant_values=0),axis=-1)

            wave.onset[k]  = np.where(seg ==  1.)[0]
            wave.offset[k] = np.where(seg == -1.)[0] - 1
            wave.peak[k]   = (wave.onset[k] + wave.offset[k])//2

# Comprueba que resultado corresponde con una marca
def get_correspondence_between_gt_and_predicted(fiducials_data, fiducials_results, k, validity, min, max):
    mask_on    = (fiducials_data.onset[k]  >= np.asarray(validity[k][0])[:,np.newaxis]) & (fiducials_data.onset[k]  <= np.asarray(validity[k][1])[:,np.newaxis])
    mask_peak  = (fiducials_data.peak[k]   >= np.asarray(validity[k][0])[:,np.newaxis]) & (fiducials_data.peak[k]   <= np.asarray(validity[k][1])[:,np.newaxis])
    mask_off   = (fiducials_data.offset[k] >= np.asarray(validity[k][0])[:,np.newaxis]) & (fiducials_data.offset[k] <= np.asarray(validity[k][1])[:,np.newaxis])
    mask_total = np.any(mask_on & mask_peak & mask_off, axis=0) # beat has to be found in every one

    d_on = fiducials_data.onset[k][mask_total]
    d_pk = fiducials_data.peak[k][mask_total]
    d_of = fiducials_data.offset[k][mask_total]

 

    min_n = [min[k].item()]
    max_n = [max[k].item()]
    print('minmax')
    print(min_n)
    print(max_n)
    mask_on    = (fiducials_results.onset[k]  >= np.asarray(min_n)[:,np.newaxis]) & (fiducials_results.onset[k]  <= np.asarray(max_n)[:,np.newaxis])
    mask_peak  = (fiducials_results.peak[k]   >= np.asarray(min_n)[:,np.newaxis]) & (fiducials_results.peak[k]   <= np.asarray(max_n)[:,np.newaxis])
    mask_off   = (fiducials_results.offset[k] >= np.asarray(min_n)[:,np.newaxis]) & (fiducials_results.offset[k] <= np.asarray(max_n)[:,np.newaxis])
    mask_total = np.any(mask_on & mask_peak & mask_off, axis=0) # beat has to be found in every one



    r_on = fiducials_results.onset[k][mask_total]
    r_pk = fiducials_results.peak[k][mask_total]
    r_of = fiducials_results.offset[k][mask_total]

    filtA =  (d_on <= r_on[:,np.newaxis]) & (r_on[:,np.newaxis] <= d_of)
    filtB =  (d_on <= r_pk[:,np.newaxis]) & (r_pk[:,np.newaxis] <= d_of)
    filtC =  (d_on <= r_of[:,np.newaxis]) & (r_of[:,np.newaxis] <= d_of)
    filtD = ((r_on <= d_on[:,np.newaxis]) & (d_on[:,np.newaxis] <= r_of)).T
    filtE = ((r_on <= d_pk[:,np.newaxis]) & (d_pk[:,np.newaxis] <= r_of)).T
    filtF = ((r_on <= d_of[:,np.newaxis]) & (d_of[:,np.newaxis] <= r_of)).T

    filt_all = filtA | filtB | filtC | filtD | filtE | filtF

    return filt_all, r_on, r_of, d_on, d_of


def get_correspondence_between_predicted_leads(fiducials_results, k, validity):
    mask_on    = (fiducials_results.onset[k + '_0']  >= np.asarray(validity[k + '_0'][0])[:,np.newaxis]) & (fiducials_results.onset[k + '_0']  <= np.asarray(validity[k + '_0'][1])[:,np.newaxis])
    mask_peak  = (fiducials_results.peak[k + '_0']   >= np.asarray(validity[k + '_0'][0])[:,np.newaxis]) & (fiducials_results.peak[k + '_0']   <= np.asarray(validity[k + '_0'][1])[:,np.newaxis])
    mask_off   = (fiducials_results.offset[k + '_0'] >= np.asarray(validity[k + '_0'][0])[:,np.newaxis]) & (fiducials_results.offset[k + '_0'] <= np.asarray(validity[k + '_0'][1])[:,np.newaxis])
    mask_total = np.any(mask_on & mask_peak & mask_off, axis=0) # beat has to be found in every one

    res_0_on = fiducials_results.onset[k + '_0'][mask_total]
    res_0_pk = fiducials_results.peak[k + '_0'][mask_total]
    res_0_of = fiducials_results.offset[k + '_0'][mask_total]

    mask_on    = (fiducials_results.onset[k + '_1']  >= np.asarray(validity[k + '_1'][0])[:,np.newaxis]) & (fiducials_results.onset[k + '_1']  <= np.asarray(validity[k + '_1'][1])[:,np.newaxis])
    mask_peak  = (fiducials_results.peak[k + '_1']   >= np.asarray(validity[k + '_1'][0])[:,np.newaxis]) & (fiducials_results.peak[k + '_1']   <= np.asarray(validity[k + '_1'][1])[:,np.newaxis])
    mask_off   = (fiducials_results.offset[k + '_1'] >= np.asarray(validity[k + '_1'][0])[:,np.newaxis]) & (fiducials_results.offset[k + '_1'] <= np.asarray(validity[k + '_1'][1])[:,np.newaxis])
    mask_total = np.any(mask_on & mask_peak & mask_off, axis=0) # beat has to be found in every one

    res_1_on = fiducials_results.onset[k + '_1'][mask_total]
    res_1_pk = fiducials_results.peak[k + '_1'][mask_total]
    res_1_of = fiducials_results.offset[k + '_1'][mask_total]

    filtA =  (res_0_on <= res_1_on[:,np.newaxis]) & (res_1_on[:,np.newaxis] <= res_0_of)
    filtB =  (res_0_on <= res_1_pk[:,np.newaxis]) & (res_1_pk[:,np.newaxis] <= res_0_of)
    filtC =  (res_0_on <= res_1_of[:,np.newaxis]) & (res_1_of[:,np.newaxis] <= res_0_of)
    filtD = ((res_1_on <= res_0_on[:,np.newaxis]) & (res_0_on[:,np.newaxis] <= res_1_of)).T
    filtE = ((res_1_on <= res_0_pk[:,np.newaxis]) & (res_0_pk[:,np.newaxis] <= res_1_of)).T
    filtF = ((res_1_on <= res_0_of[:,np.newaxis]) & (res_0_of[:,np.newaxis] <= res_1_of)).T

    filt_all = filtA | filtB | filtC | filtD | filtE | filtF

    return filt_all


def compute_dice_score(mask_1, mask_2):
    intersection = (mask_1 * mask_2).sum()
    union = mask_1.sum() + mask_2.sum()
    return 2.*intersection/(union + np.finfo('double').eps)


def compute_wave_metrics(config, fiducials_data, fiducials_results, wave_metrics, test, validity, min, max, recompute=False):
    leads = 2  # Número de derivaciones

    for k in test:
        if (k not in wave_metrics.keys) or recompute:
            k = str(k)
            # Initialize metrics
            wave_metrics.truepositive[k] = 0
            wave_metrics.falsepositive[k] = 0
            wave_metrics.falsenegative[k] = 0
            wave_metrics.dice[k] = 0
            wave_metrics.onseterror[k] = []
            wave_metrics.offseterror[k] = []

            for lead in range(leads):
                lead_key = f"{k}_{lead}"
                # If the prediction is different for every lead (single-lead strategy)
                filt_all_0, r_on, r_of, d_on, d_of = get_correspondence_between_gt_and_predicted(fiducials_data, fiducials_results, lead_key, validity, min, max)
                
                # Check correspondence of GT beats to detected beats
                corr  = dict()
                corr2 = dict()
                # Account for already detected beats to calculate false positives
                chosen_0 = np.zeros((filt_all_0.shape[0],), dtype=bool)
                # Guarda en cada columna el número de la fila que es verdadero (cual corresponde a cual)
                 # Guarda en cada columna el número de la fila que es verdadero (cual corresponde a cual)
                for i in range(filt_all_0.shape[1]):
                    corr[i]  = [np.where(filt_all_0[:,i])[0].tolist()]
                    chosen_0 = chosen_0 | filt_all_0[:,i]
                for i in range(filt_all_0.shape[0]):
                    corr2[i] = [np.where(filt_all_0[i,:])[0].tolist()]

                # Retrieve beats detected that do not correspond to any GT beat (potential false positives)
                not_chosen = np.where(np.logical_not(chosen_0))[0]
                
                # Compute Dice coefficient
                for i in range(len(validity[lead_key][0])):
                    on  = validity[lead_key][0][i]
                    off = validity[lead_key][1][i]

                    wave_metrics.dice[k] += compute_dice_score(fiducials_data.wave[lead_key][on:off], fiducials_results.wave[lead_key][on:off])
                
                # Compute metrics - Fusion strategy of results of both leads, following Martinez et al.
                for i in range(filt_all_0.shape[1]):
                    # If any GT beat has a correspondence to any segmented beat, true positive + accounts for on/offset error
                    if (len(corr[i][0]) != 0):
                        # Mark beat as true positive
                        wave_metrics.truepositive[k] += 1
                        
                        # To compute the onset-offset errors, check which is the lead with the least error to the GT (Martinez et al.)
                        onset  = (d_on[i] - r_on[corr[i][0]])
                        offset = (d_of[i] - r_of[corr[i][0]])
                        
                        # Concatenate errors in one error vector
                        onset_error  = np.hstack((onset))
                        offset_error = np.hstack((offset))
                        
                        # Onset/offset Error as the value resulting in the minimum absolute value
                        wave_metrics.onseterror[k]  += [int(onset_error[np.argmin(np.abs(onset_error))])]
                        wave_metrics.offseterror[k] += [int(offset_error[np.argmin(np.abs(offset_error))])]
                        
                    # If any GT beat has a correspondence to more than one segmented beat, 
                    #     the rest of the pairs have to be false positives (Martinez et al.)
                 
                    
                    # If any GT beat has no correspondence to any segmented beat, false negative
                    if (len(corr[i][0]) == 0) :
                        wave_metrics.falsenegative[k] += 1
                for i in range(filt_all_0.shape[0]):
                    # If any predicted wave has no correspondence
                    if (len(corr2[i][0]) == 0) :
                        wave_metrics.falsepositive[k] += 1       
                # False positives will correspond to those existing in the results that do not correspond to any beat in the GT (the not chosen)
                wave_metrics.falsepositive[k] += len(not_chosen)
                
            # Normalize Dice coefficient by the number of leads
            wave_metrics.dice[k] /= leads
            
            # Mark the key as computed
            wave_metrics.keys.append(k)


def wave_evaluation_from_metrics(wave_metrics, test):
    tp        = 0
    fp        = 0
    fn        = 0
    dice      = 0
    on        = []
    of        = []
    print(wave_metrics.truepositive)
    for k in test:
        k = str(k)
        tp   += wave_metrics.truepositive[k]
        fp   += wave_metrics.falsepositive[k]
        fn   += wave_metrics.falsenegative[k]
        on   += wave_metrics.onseterror[k]
        of   += wave_metrics.offseterror[k]
        dice += wave_metrics.dice[k]

    if tp == 0 and fp == 0:
        precision = 1
    else:
        precision = tp/(tp+fp)

    if tp == 0 and fn == 0:
        recall = 1
    else:
        recall    = tp/(tp+fn)

    on        = np.asarray(on)
    of        = np.asarray(of)
    dice      = dice/len(test)

    return precision, recall, on, of, dice


def metric_computation(config, data, metrics, results, test, recompute=False):
    min_on = {}
    max_on = {}

    # Calcular el mínimo para cada etiqueta común
    for key in data.P.onset.keys():
        if np.any(data.P.onset[key]):
            min_value_on = np.min([min(data.P.onset[key]), min(data.QRS.onset[key]), min(data.T.onset[key])])
            min_on[key] = min_value_on - 50
        else:
            min_value_on = np.min([min(data.QRS.onset[key]), min(data.T.onset[key])])
            min_on[key] = min_value_on - 50

    for key in data.P.onset.keys():
        if np.any(data.P.offset[key]):
            max_value_off = np.max([max(data.P.offset[key]), max(data.QRS.offset[key]), max(data.T.offset[key])])
            max_on[key] = max_value_off + 50
        else:
            max_value_off = np.max([max(data.QRS.offset[key]), max(data.T.offset[key])])
            max_on[key] = max_value_off + 50

    compute_wave_metrics(config, data.P,   results.P,   metrics.P,   test, data.validity, min_on, max_on, recompute)
    compute_wave_metrics(config, data.QRS, results.QRS, metrics.QRS, test, data.validity, min_on, max_on, recompute)
    compute_wave_metrics(config, data.T,   results.T,   metrics.T,   test, data.validity, min_on, max_on, recompute)
    
    return metrics


