import os
import math
import pandas
import numpy as np
import torch
from torch.utils.data import Dataset
from importlib import import_module
from utils.logger import conditional_makedir
from utils.transforms import DataAugmentationTransform
import sys
import random
import pickle
import os
from data_plot import plot_batch

# convert series to supervised learning
def series_to_supervised(data, n_length, n_stride=1):
    data = np.pad(data,((0,int((math.ceil((float(data.shape[0]) - n_length + n_stride)/n_stride) - 1)*n_stride+n_length-data.shape[0]))),'edge') #Añade 0s al final de secuencia temporar para asegurarse de que hay suficientes datos para crear secuencias
    agg  = np.zeros((math.ceil((data.shape[0] - n_length + n_stride)/n_stride),n_length))

    for i in range(0,agg.shape[0]):
        agg[i,:] = data[i*n_stride:(i*n_stride+n_length)]
    return agg


def supervised_to_series(supervised, n_length, n_stride=1):
    dtype   = supervised.dtype
    agg     = np.zeros(((supervised.shape[0]-1)*n_stride+n_length,))
    contrib = np.zeros(((supervised.shape[0]-1)*n_stride+n_length,))

    for i in range(0,supervised.shape[0]):
        agg[i*n_stride:(i*n_stride+n_length)]       += supervised[i,:]
        contrib[i*n_stride:(i*n_stride+n_length)]   += 1
    return (agg/contrib).astype(dtype)


# Data loader to un-clutter code    
def load_data(filepath):
    dic = dict()
    with open(filepath) as f:
        text = list(f)
    for line in text:
        line = line.replace(' ','').replace('\n','').replace(',,','')
        if line[-1] == ',': line = line[:-1]
        head = line.split(',')[0]
        tail = line.split(',')[1:]
        if tail == ['']:
            tail = np.asarray([])
        else:
            tail = np.asarray(tail).astype(int)

        dic[head] = tail
    return dic


# Data loader to un-clutter code    
def save_data(filepath, dic):
    with open(filepath, 'w') as f:
        for key in dic.keys():
            # f.write("%s,%s\n"%(key,dic[key].tolist()))
            f.write("{},{}\n".format(key,str(dic[key].tolist()).replace(']','').replace('[','').replace(' ','')))


def save_fiducials(fiducial, path):
    with open(path, 'w') as f:
        for key in fiducial.keys():
            f.write("%s,%s\n"%(key,str(fiducial[key].tolist()).replace('[','').replace(']','')))


# class ExecInfo(object):
#     def __init__(self, config, fold, train, valid, test):
#         self.sets           = SetInfo(train, valid, test)
#         self.paths          = PathInfo(config, fold)

#     def __repr__(self):
#         return self.__str__()


# class SetInfo(object):
#     def __init__(self, train, valid, test):
#         self.train          = train
#         self.valid          = valid
#         self.test           = test

#     def __repr__(self):
#         return self.__str__()


# class PathInfo(object):
#     def __init__(self, config, fold):
#         self.summary         = os.path.join(config.output_dir, 'Summary.txt')

#         if (config.splitting == "cross_validation") and fold != None:
#             self.logger      = os.path.join(config.output_dir, config.splitting, 'Training', 'Fold_' + str(fold + 1), 'Model.log')
#             self.state       = os.path.join(config.output_dir, config.splitting, 'Training', 'Fold_' + str(fold + 1), 'Model.hdf5')
#             self.results     = os.path.join(config.output_dir, config.splitting, 'Results', config.data_set, 'Fold_' + str(fold + 1), 'Results_ALL.csv')
#             self.results_CV2 = os.path.join(config.output_dir, config.splitting, 'Results', config.data_set, 'Fold_' + str(fold + 1), 'Results_ALL_CV2.csv')

#         else: # Case "all"
#             self.logger      = os.path.join(config.output_dir, config.splitting, 'Training', 'Total.log')
#             self.state       = os.path.join(config.output_dir, config.splitting, 'Training', 'Total.hdf5')
#             self.results     = os.path.join(config.output_dir, config.splitting, 'Results', config.data_set, 'Total_ALL.csv')
#             self.results_CV2 = os.path.join(config.output_dir, config.splitting, 'Results', config.data_set, 'Total_ALL_CV2.csv')

#         conditional_makedir(self.summary)
#         conditional_makedir(self.logger)
#         conditional_makedir(self.state)
#         conditional_makedir(self.results)
#         conditional_makedir(self.results_CV2)

#     def __repr__(self):
#         return self.__str__()


# class FoldKeys():
#     def __init__(self, train_keys=None, valid_keys=None, test_keys=None):
#         """Use fold = None for whole dataset test"""

#         self.train          = train_keys
#         self.valid          = valid_keys
#         self.test           = test_keys

#     def __str__(self):
#         s = ''
#         for k in self.__dict__.keys():
#             s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
#         return s

#     def __repr__(self):
#         return self.__str__()


# class FoldPaths():
#     def __init__(self, config, fold=None):
#         """Use fold = None for whole dataset test """

#         self.summary         = os.path.join(config.output_dir, 'Summary.txt')

#         if (config.splitting == "cross_validation") and fold != None:
#             self.logger      = os.path.join(config.output_dir, config.splitting, 'Training', 'Fold_' + str(fold + 1), 'Model.log')
#             self.state       = os.path.join(config.output_dir, config.splitting, 'Training', 'Fold_' + str(fold + 1), 'Model.hdf5')
#             self.results     = os.path.join(config.output_dir, config.splitting, 'Results', config.data_set, 'Fold_' + str(fold + 1), 'Results_ALL.csv')
#             self.results_CV2 = os.path.join(config.output_dir, config.splitting, 'Results', config.data_set, 'Fold_' + str(fold + 1), 'Results_ALL_CV2.csv')

#         else: # Case "all"
#             self.logger      = os.path.join(config.output_dir, config.splitting, 'Training', 'Total.log')
#             self.state       = os.path.join(config.output_dir, config.splitting, 'Training', 'Total.hdf5')
#             self.results     = os.path.join(config.output_dir, config.splitting, 'Results', config.data_set, 'Total_ALL.csv')
#             self.results_CV2 = os.path.join(config.output_dir, config.splitting, 'Results', config.data_set, 'Total_ALL_CV2.csv')

#         conditional_makedir(self.summary)
#         conditional_makedir(self.logger)
#         conditional_makedir(self.state)
#         conditional_makedir(self.results)
#         conditional_makedir(self.results_CV2)


#     def __str__(self):
#         s = ''
#         for k in self.__dict__.keys():
#             s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
#         return s

#     def __repr__(self):
#         return self.__str__()


class WaveInformation():
    def __init__(self):
        self.wave   = pandas.DataFrame()
        self.onset  = dict()
        self.peak   = dict()
        self.offset = dict()

    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()

class ExecutionInformation():
    def __init__(self, config, fold, train_keys, test_keys, evaluate):
        """Use fold = None for whole dataset test """

        # Specify fold
        self.fold                   = fold
        self.evaluate               = evaluate
        self.output_dir             = config.output_dir
        self.backend                = config.backend.lower()
        self.data_set               = config.data_set.lower()
        self.splitting              = config.splitting.lower()


        # Define train/test sets
        if self.evaluate == True: # If only evaluating, no need for validation set
            valid_keys          = []
        else:
            if config.combine:
                # Filtrar las etiquetas que solo contienen números
                etiquetas_numericas = [etiqueta for etiqueta in train_keys if etiqueta.isdigit()]

                # Calcular el 20% de las etiquetas numéricas
                n_15_percent = int(len(etiquetas_numericas) * 0.2)

                # Seleccionar el 20% de las etiquetas numéricas
                valid_keys = etiquetas_numericas[:n_15_percent]

                # Guardar el resto de las etiquetas (numéricas y no numéricas)
                train_keys = [etiqueta for etiqueta in train_keys if etiqueta not in valid_keys]
                #Elige unos datos aleatórios para entrenar y validar
            else:
                train_keys          = np.random.permutation(train_keys)
                valid_keys          = train_keys[:math.ceil(config.val_split*len(train_keys))]
                train_keys          = train_keys[math.ceil(config.val_split*len(train_keys)):]
            #Elige unos datos aleatórios para entrenar y validar
        # Set paths
        self.summary        = os.path.join(self.output_dir, 'Summary.txt')

        if (self.splitting == "cross_validation") and self.fold != None:
            self.logger  = os.path.join(self.output_dir, self.backend, self.splitting, 'Training', 'Model_5_3_no_mask.log')
            self.state   = os.path.join(self.output_dir, self.backend, self.splitting, 'Training', 'Model_5_3_no_mask.pth')
            self.results = os.path.join(self.output_dir, self.backend, self.splitting, 'Results', self.data_set, 'Fold_0', 'Results_ALL.csv')
            
        else: # Case "all"
            self.logger  = os.path.join(self.output_dir, self.backend, self.splitting, 'Training', 'Total.log')
            self.state   = os.path.join(self.output_dir, self.backend, self.splitting, 'Training', 'Total.pth')
            self.results = os.path.join(self.output_dir, self.backend, self.splitting, 'Results', self.data_set, 'Total_ALL.csv')
            
        conditional_makedir(self.summary)
        conditional_makedir(self.logger)
        conditional_makedir(self.state)
        conditional_makedir(self.results) #Crea directorios en los path que se pasan

        self.train       = train_keys
        self.valid       = valid_keys
        self.test        = test_keys

    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()


class DataStorage():
    def __init__(self, dataset, validity=None):
        self.dataset    = dataset
        self.validity   = validity
        self.P          = WaveInformation()
        self.QRS        = WaveInformation()
        self.T          = WaveInformation()
        self.null       = WaveInformation()
        self.keys       = []

    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()
    
    def init_P(self, wave, onset, peak, offset):
        self.P.wave     = wave
        self.P.onset    = onset
        self.P.peak     = peak
        self.P.offset   = offset
        self.keys       = list(set(self.keys + wave.keys().tolist()))

    def init_QRS(self, wave, onset, peak, offset):
        self.QRS.wave   = wave
        self.QRS.onset  = onset
        self.QRS.peak   = peak
        self.QRS.offset = offset
        self.keys       = list(set(self.keys + wave.keys().tolist()))

    def init_T(self, wave, onset, peak, offset):
        self.T.wave     = wave
        self.T.onset    = onset
        self.T.peak     = peak
        self.T.offset   = offset
        self.keys       = list(set(self.keys + wave.keys().tolist()))

    def init_null(self, wave):
        self.null.wave     = wave
        self.keys       = list(set(self.keys + wave.keys().tolist()))

class WaveMetricsStorage():
    def __init__(self):
        self.truepositive  = dict()
        self.falsepositive = dict()
        self.falsenegative = dict()
        self.onseterror    = dict()
        self.offseterror   = dict()
        self.dice          = dict()
        self.keys          = []

    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()

    def __getitem__(self, k):
        return self.truepositive[k], self.falsepositive[k], self.falsenegative[k], self.onseterror[k], self.offseterror[k]


class Database(object):
    def __init__(self):
        self.registries = dict()

    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()    


class Registry(object):
    def __init__(self, lead_0, lead_1):
        self.lead_0 = Signal()
        self.lead_1 = Signal()

    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()    


class Signal(object):
    def __init__(self):
        self.P   = Wave()
        self.QRS = Wave()
        self.T   = Wave()


class Wave(object):
    def __init__(self):
        self.signal     = []
        self.validity   = dict()
        self.onset      = []
        self.peak       = []
        self.offset     = []
        self.metrics    = WaveMetricsStorage()

    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()



class MetricsStorage():
    def __init__(self):
        self.P       = WaveMetricsStorage()
        self.QRS     = WaveMetricsStorage()
        self.T       = WaveMetricsStorage()

    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()

    def init_P(self, truepositive, falsepositive, falsenegative, onseterror, offseterror):
        self.P.truepositive    = truepositive
        self.P.falsepositive   = falsepositive
        self.P.falsenegative   = falsenegative
        self.P.onseterror      = onseterror
        self.P.offseterror     = offseterror

    def init_QRS(self, truepositive, falsepositive, falsenegative, onseterror, offseterror):
        self.QRS.truepositive  = truepositive
        self.QRS.falsepositive = falsepositive
        self.QRS.falsenegative = falsenegative
        self.QRS.onseterror    = onseterror
        self.QRS.offseterror   = offseterror

    def init_T(self, truepositive, falsepositive, falsenegative, onseterror, offseterror):
        self.T.truepositive    = truepositive
        self.T.falsepositive   = falsepositive
        self.T.falsenegative   = falsenegative
        self.T.onseterror      = onseterror
        self.T.offseterror     = offseterror


class ConfigParser():
    def __init__(self, config_dict, ex_id, override_augment, data_path2, data_path, data_set, splitting, load_weights, backend, output_dir, evaluate,combine, data_sintetic):
        assert backend.lower() in ('keras', 'torch', 'pytorch')

        # Retrieve information from configuration dictionary
        self.depth           = int(config_dict['A_Depth'])
        self.m_repetitions   = int(config_dict['A_Repetitions'])
        self.start_ch        = int(config_dict['A_InitChannels'])
        self.data_aug        = bool(config_dict['T_DataAug'])
        self.ms_upsampling   = bool(config_dict['A_MSUpsampling'])
        self.atrous_conv     = bool(config_dict['A_ASPP'])
        self.hyperdense      = bool(config_dict['A_HyperDense'])
        self.m_name          = str(config_dict['A_Module'])
        self.loss            = str(config_dict['T_Loss'])
        self.optimizer       = str(config_dict['T_Optimizer'])
        self.inc_rate        = float(config_dict['A_LvlGrowth'])
        self.learning_rate   = float(config_dict['T_LearningRate'])
        self.kernel_init     = str(config_dict['A_KernelInitializer'])
        self.kernel_size     = int(config_dict['A_KernelSize'])
        self.dropout_rate    = float(config_dict['A_DropoutRate'])
        self.batch_size      = int(config_dict['T_BatchSize'])
        self.out_ch          = int(config_dict['A_OutChannels'])
        self.element_size    = int(config_dict['P_ElementSize'])
        self.max_size        = int(config_dict['D_MaxSize'])
        self.maxpool         = int(config_dict['A_MaxPooling'])
        self.sampling_freq   = float(config_dict['D_fs'])
        self.stride          = int(config_dict['T_Stride'])
        self.window          = int(config_dict['T_Window'])
        self.n_epochs        = int(config_dict['T_Epochs'])
        self.lr_patience     = int(config_dict['T_LRPatience'])
        self.patience        = int(config_dict['T_Patience'])
        self.val_split       = float(config_dict['T_ValidationSplit'])
        self.seed            = int(config_dict['T_Seed'])
        self.strategy        = str(config_dict['A_Strategy'])

        if self.strategy in ('single', 'single_lead', 'single-lead', 'single lead'):
            self.in_ch       = 1
        elif self.strategy in ('multi', 'multilead', 'multi_lead', 'multi-lead', 'multi lead'):
            self.in_ch       = 2
        else:
            raise ValueError("Training strategy '" + str(self.strategy) + "' not implemented")

        # Inputs
        self.ex_id           = int(ex_id)
        self.override_augment = override_augment
        self.backend         = backend
        self.data_set        = data_set
        self.data_path2       = os.path.join(data_path2)
        self.data_path       = os.path.join(data_path)
        self.splitting       = splitting
        self.load_weights    = load_weights
        self.evaluate        = evaluate
        self.device          = 'cuda'
        self.output_dir      = output_dir
        self.combine         = combine
        self.data_sintetic   = data_sintetic
        if self.output_dir == None: 
            self.output_dir  = os.path.join(os.path.abspath('./Logs/'), 'Config' + str(self.ex_id))
        else:
            self.output_dir  = os.path.join(self.output_dir, 'Config' + str(self.ex_id))


    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s

    def __repr__(self):
        return self.__str__()


def verificar_ceros(vector,long):
        contador_ceros = 0
        delete = 0 # 1 -> Eliminar datos, 0 -> No eliminar
        for elemento in vector:
            if elemento == 0:
                contador_ceros += 1
            else:
                contador_ceros = 0

            if contador_ceros > long:
                delete = 1
                break
        return delete

def encontrar_primer_cero(entrada):
    indice = 0
    # Encontrar la última secuencia de ceros
    for i in range(len(entrada) - 1, -1, -1):
        if entrada[i] != 0:
            indice = i
            break
    return indice



class MyPyTorchDataset(Dataset):
    '''Generates data for Keras'''
    

    def __init__(self, labels, config, data1, data2, TV, type, shuffle=True):
        '''Initialization'''
        # awgn=20, spikes=(30,200), powerline=(20,50.), baseline=(-5,0.15), pacemaker=15, sat_threshold=5)
        
        # Easier indexing
        #leads = pandas.Index(labels) + f'_{0}'
        print(labels)
        if not config.combine:
            if not str(labels[1]).isdigit():
                leads1 = pandas.Index([f'{label}_{i}' for label in labels for i in range(2)])
            else:
                leads1 = pandas.Index([f'{label}_{i}' for label in labels for i in range(12)])
                if config.override_augment:
                    leads_aug = pandas.Index([f'{label}_{i}_n{j}' for label in labels for i in range(12) for j in range(2)])
                    leads_aug = leads_aug.append(leads1)
            if type == 0 and not str(labels[1]).isdigit(): #Si se usa la QT manual
                if TV == 0:
                    ruta_archivo = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/dict', 'correspondence_QT.pkl')
                else:
                    ruta_archivo = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/dict', 'correspondence_valid.pkl')
                # Leer el diccionario desde el archivo pickle (QT)
                with open(ruta_archivo, 'rb') as archivo:
                    mi_diccionario = pickle.load(archivo)
           
                nombres_diccionario = pandas.Index({valor[0] for valor in mi_diccionario.values()})
            else:
                nombres_diccionario = leads1
                if config.override_augment:
                    nombres_diccionario_aug = leads_aug
            print('nombres_diccionario')
            print(nombres_diccionario)
        else:
            leads = []
            leads_aug = []
            cont = 0
            cont2 = 0
            for i, label in enumerate(labels):

                if label.isdigit():
                    leads[cont:cont+11] = pandas.Index([f'{label}_{i}' for i in range(12)])
                    if config.override_augment:
                        leads_aug[cont2:cont2+11] = ([f'{label}_{i}' for i in range(12)])
                        leads_aug[cont2+11:cont2+35] = ([f'{label}_{i}_n{j}' for i in range(12) for j in range(2)])
                        cont2=cont2+12*3
                    
                    cont=cont+12
                else:
                    leads[cont:cont+1] = pandas.Index([f'{label}_{i}' for i in range(2)])
                    cont=cont+2

            leads1 =([dato for dato in leads if dato.startswith('sel')])
            leads2 = pandas.Index([dato for dato in leads if not dato.startswith('sel')])

            leads1 = pandas.Index(leads1)
            leads_aug = pandas.Index(leads_aug)
            if config.override_augment:
                    
                    nombres_diccionario_aug = leads_aug


           #Si ya se ha guardado self.correspondence
            if type == 0:
                if TV == 0:
                    ruta_archivo = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/dict', 'correspondence_QT.pkl')
                else:
                    ruta_archivo = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/dict', 'correspondence_valid.pkl')
                # Leer el diccionario desde el archivo pickle (QT)
                with open(ruta_archivo, 'rb') as archivo:
                    mi_diccionario = pickle.load(archivo)
            
                nombres_diccionario = pandas.Index({valor[0] for valor in mi_diccionario.values()})
            else:
                nombres_diccionario = leads1

        if config.data_sintetic:
            categories = ['sr', 'sr_ecto', 'aur_tach']

           
            nombres_diccionario_sintetic = pandas.Index([f'{label}_{i}_{j}_{categorie}' for label in labels for i in range(12) for j in range(1) for categorie in categories])
            nombres_diccionario = pandas.Index([f'{label}_{i}_{categorie}' for label in labels for i in range(12) for categorie in categories])

        # Set properties
        self.config             = config
        self.labels             = labels
        self.shuffle            = shuffle
        self.window             = config.window
        self.channels           = config.in_ch
        self.stride             = config.stride
        self.batch_size         = config.batch_size
        if  not config.combine:
            if not config.data_sintetic:
                if config.override_augment:
                    self.dataset            = data1.dataset[nombres_diccionario_aug]
                    self.validity           = data1.validity[nombres_diccionario_aug]
                else:
                    self.dataset            = data1.dataset[nombres_diccionario]
                    self.validity           = data1.validity[nombres_diccionario]
            else:
                self.dataset            = data1.dataset[nombres_diccionario_sintetic]
                self.validity           = data1.validity[nombres_diccionario_sintetic]

            self.mask_p             = data1.P.wave[nombres_diccionario]   # Much simpler index generation
            self.mask_qrs           = data1.QRS.wave[nombres_diccionario] # Much simpler index generation
            self.mask_t             = data1.T.wave[nombres_diccionario]   # Much simpler index generation
            self.mask_null          = data1.null.wave[nombres_diccionario]
            self.mask_generator     = dict()
            for key in nombres_diccionario:
                if not config.data_sintetic:
                    self.mask_generator[key] = create_mask(data1.P.onset[key] ,data1.P.offset[key] ,data1.QRS.onset[key],data1.QRS.offset[key], data1.T.onset[key], data1.T.offset[key], 500, len(data1.dataset[key]) )
                else:
                    self.mask_generator[key] = create_mask(data1.P.onset[key] ,data1.P.offset[key] ,data1.QRS.onset[key],data1.QRS.offset[key], data1.T.onset[key], data1.T.offset[key], 500, 7500 )
            self.TYPE               = type
        else:
            self.dataset            = data1.dataset[nombres_diccionario]
            self.validity           = data1.validity[nombres_diccionario]

            self.mask_p             = data1.P.wave[nombres_diccionario]   # Much simpler index generation
            self.mask_qrs           = data1.QRS.wave[nombres_diccionario] # Much simpler index generation
            self.mask_t             = data1.T.wave[nombres_diccionario]   # Much simpler index generation
            self.mask_null          = data1.null.wave[nombres_diccionario]
            self.mask_generator     = dict()
            for key in nombres_diccionario:
                self.mask_generator[key] = create_mask(data1.P.onset[key] ,data1.P.offset[key] ,data1.QRS.onset[key],data1.QRS.offset[key], data1.T.onset[key], data1.T.offset[key], 500, len(data1.dataset[key]) )
            self.TYPE               = type
            if config.override_augment:
                self.dataset2           = data2.dataset[nombres_diccionario_aug]
                self.validity2          = data2.validity[nombres_diccionario_aug]
            else:
                self.dataset2           = data2.dataset[leads2]
                self.validity2          = data2.validity[leads2]
            self.mask_p2            = data2.P.wave[leads2]   # Much simpler index generation
            self.mask_qrs2          = data2.QRS.wave[leads2] # Much simpler index generation
            self.mask_t2            = data2.T.wave[leads2]   # Much simpler index generation
            self.mask_null2          = data2.null.wave[leads2]
            self.mask_generator2          = dict()
            for key in leads2:
                if not config.data_sintetic:
                    self.mask_generator2[key] = create_mask(data2.P.onset[key] ,data2.P.offset[key] ,data2.QRS.onset[key],data2.QRS.offset[key], data2.T.onset[key], data2.T.offset[key], 500, len(data2.dataset[key]) )
                else:
                    self.mask_generator2[key] = create_mask(data2.P.onset[key] ,data2.P.offset[key] ,data2.QRS.onset[key],data2.QRS.offset[key], data2.T.onset[key], data2.T.offset[key], 500, 7500 )
        # Index-Window correspondence
        self.correspondence = dict()
        counter = 0 # Keep track of how many windows have already been stored

        # Single-lead strategy
        if self.channels == 1: 
            
            if config.combine:
                if TV == 0:
                    ruta_archivo = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/dict', 'correspondence_QT.pkl')
                else:
                    ruta_archivo = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/dict', 'correspondence_valid.pkl')

                # Leer el diccionario desde el archivo pickle (QT)
                with open(ruta_archivo, 'rb') as archivo:
                    mi_diccionario = pickle.load(archivo)

                self.correspondence = mi_diccionario
                long_qt = len(mi_diccionario)
                if config.override_augment:
                    for key in nombres_diccionario_aug:
                        if not key.startswith('sel'):
                            for w in range(len(self.validity2[key][0])):
                                window_elements = max(((self.validity2[key]['off'][w]-self.validity2[key]['on'][w]+1)-self.window+self.stride)//self.stride,0) #Creo que son las veces que tiene que iterar
                                for i in range(window_elements):
                                    self.correspondence[counter+i+long_qt] = [key, self.validity2[key]['on'][w]+self.stride*i]

                                counter += window_elements
                else:
                    for key in leads2:
                        if not key.startswith('sel'):
                            for w in range(len(self.validity2[key][0])):
                                window_elements = max(((self.validity2[key]['off'][w]-self.validity2[key]['on'][w]+1)-self.window+self.stride)//self.stride,0) #Creo que son las veces que tiene que iterar
                                for i in range(window_elements):
                                    self.correspondence[counter+i+long_qt] = [key, self.validity2[key]['on'][w]+self.stride*i]

                                counter += window_elements

            else:
                if not config.data_sintetic:
                    if leads1[1].startswith('sel') and self.TYPE == 0:
                        if TV == 0:
                            ruta_archivo = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/dict', 'correspondence_QT.pkl')
                        else:
                            ruta_archivo = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/dict', 'correspondence_valid.pkl')
                        # Leer el diccionario desde el archivo pickle
                        with open(ruta_archivo, 'rb') as archivo:
                            mi_diccionario = pickle.load(archivo)

                        self.correspondence = mi_diccionario
                    else:
                        if config.override_augment:
                            for key in nombres_diccionario_aug:
                                for w in range(len(self.validity[key][0])):
                                    window_elements = max(((self.validity[key]['off'][w]-self.validity[key]['on'][w]+1)-self.window+self.stride)//self.stride,0) #Creo que son las veces que tiene que iterar
                                    for i in range(window_elements):
                                        self.correspondence[counter+i] = [key, self.validity[key]['on'][w]+self.stride*i]

                                    counter += window_elements
                        else:
                            for key in nombres_diccionario:
                                for w in range(len(self.validity[key][0])):
                                    window_elements = max(((self.validity[key]['off'][w]-self.validity[key]['on'][w]+1)-self.window+self.stride)//self.stride,0) #Creo que son las veces que tiene que iterar
                                    for i in range(window_elements):
                                        self.correspondence[counter+i] = [key, self.validity[key]['on'][w]+self.stride*i]

                                    counter += window_elements
                else:
                    for key in nombres_diccionario_sintetic :
                                for w in range(len(self.validity[key][0])):
                                    window_elements = max(((self.validity[key]['off'][w]-self.validity[key]['on'][w]+1)-self.window+self.stride)//self.stride,0) #Creo que son las veces que tiene que iterar
                                    for i in range(window_elements):
                                        self.correspondence[counter+i] = [key, self.validity[key]['on'][w]+self.stride*i]

                                    counter += window_elements
                    

               #EXTRAE LAS VENTANAS QUE CONTIENEN MARCAS EN EL DICCIONARIO QT
              
                # for key in leads1:
                #     print(key)
                #     for w in range(len(self.validity[key][0])):
                #         window_elements = max(((self.validity[key]['off'][w]-self.validity[key]['on'][w]+1)-self.window+self.stride)//self.stride,0) #Creo que son las veces que tiene que iterar
                #         for i in range(window_elements):
                #             #Si existen espacios en las marcas que sean mayores a la duración de un latido eliminaremos esa ventana
                #             # X = np.empty((window_elements, self.window, self.channels), dtype='float32')
                #             y = np.empty((window_elements, self.window, 3), dtype='float32')

                #             onset     = self.validity[key]['on'][w]+self.stride*i #CAMBIAR LA PARTE DEL DATASET DE LUB A LONGITUD 5000 DE VALIDITY

                #             # X[i,:,0]  = self.dataset[key][onset:onset+self.window] #Recorre datos del dataset de cada 64 posiciones con una ventana, hay overlapping
                #             # Store mask
                #             y[i,:,0]  = self.mask_p[key].values[onset:onset+self.window]
                #             y[i,:,1]  = self.mask_qrs[key].values[onset:onset+self.window]
                #             y[i,:,2]  = self.mask_t[key].values[onset:onset+self.window]
                #             if not(verificar_ceros(y[i,:,0],1000) == 1 & verificar_ceros(y[i,:,1],1000) == 1 & verificar_ceros(y[i,:,2],1000) == 1):
                #                 self.correspondence[counter] = [key, self.validity[key]['on'][w]+self.stride*i]
                #                 counter=counter+1
                #                 print('bien')
                #             # else:
                #             #     pocho=pocho+1
                #             #     print(pocho)
                # # Ruta completa del archivo
                # ruta_archivo = os.path.join(r'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\dict', 'correspondence.pkl')

                # # Guardar el diccionario en un archivo pickle
                # with open(ruta_archivo, 'wb') as archivo:
                #     pickle.dump(self.correspondence, archivo)           
                        

            
        elif self.channels == 2:    # Two-lead strategy. Both leads will have the same validity <- selecting validity of lead '_0'
            for key in self.labels:
                for w in range(len(self.validity[key + '_0'][0])):
                    window_elements = max(((self.validity[key + '_0']['off'][w]-self.validity[key + '_0']['on'][w]+1)-self.window+self.stride)//self.stride,0)#El total de ventanas que va a haber con los datos de cada archivo
                    
                    for i in range(window_elements):
                        self.correspondence[counter+i] = [key, self.validity[key + '_0']['on'][w]+self.stride*i] #Los datos que pone a la salida es una posición cada 64 (NO ENTIENDO)

                    counter += window_elements
        else:                       # Not implemented
            raise NotImplementedError("No database available for " + str(self.channels) + " channels")

        # Convertir el diccionario a una lista de tuplas para facilitar la manipulación
        list_items = list(self.correspondence.items())

        # Aleatorizar el orden de los elementos en la lista
        random.shuffle(list_items)

        # Convertir la lista aleatorizada de vuelta a un diccionario
        self.correspondence = dict(list_items)
        print(self.correspondence)

        # Custom indexing
        self.length_no_aug  = len(self.correspondence.keys())
        self.indexes        = np.arange(len(self.correspondence.keys())) #Indices de 0 a la longitud de datos-1
        
        # print(self.indexes)
    def __len__(self):
        '''Denotes the number of batches per epoch'''
        return math.ceil(float(len(self.indexes))/self.batch_size)

    def __getitem__(self, index):
        '''Generate one batch of data'''
        # Generate self.indexes of the batch
        ix = self.indexes[index*self.batch_size:(index+1)*self.batch_size]
        # Generate data
        if self.channels == 1:
            if not  self.config.data_sintetic:
                if  self.config.combine:
                    X, y, mask = self.__batch_generation_single_c(ix)
                else:
                    X, y, mask = self.__batch_generation_single(ix)
            else:
                X, y, mask = self.__batch_generation_single_sintetic(ix)
        elif self.channels == 2:
            X, y = self.__batch_generation_multi(ix)
            # X = X[:,:,:,np.newaxis]
            # y = y[:,:,np.newaxis,:]
        else:
            raise NotImplementedError("No batch generation strategy for " + str(self.channels) + " channels has been devised")
        # X_z = torch.zeros(len(ix), self.channels, self.window,dtype =torch.float32)
        # y_z = torch.zeros(len(ix), 3, self.window,dtype =torch.float32)
        X = torch.tensor(X, dtype =torch.float32)
        y = torch.tensor(y, dtype =torch.float32)
        #Si existen espacios en las marcas que sean mayores a la duración de un latido eliminaremos esa ventana (¿PONERLO A 0 O VACÍO?)

        return X, y, mask

    def on_epoch_end(self):
        '''Updates self.indexes after each epoch'''
        if self.shuffle == True:
            np.random.shuffle(self.indexes)

    def __batch_generation_single(self, ix):
        '''Generates one datapoint''' 
        # X : (n_samples, *dim, n_channels)
        # Initialization
        X = np.empty((len(ix), self.channels, self.window), dtype='float32')
        mask = np.zeros((len(ix), self.channels, self.window), dtype='float32')
        y = np.empty((len(ix), 4, self.window), dtype='float32')
        # Generate data
        for i, ID in enumerate(ix):
            # Desambiguate data augmentation
          
            j         = ID//self.length_no_aug
            ID        = ID%self.length_no_aug #Ajusta el valor para que este dentro de length_no_aug
            # print(ID)
            # print(self.correspondence[ID])
            w_info    = self.correspondence[ID]
            key       = w_info[0]
            onset     = w_info[1]#CAMBIAR LA PARTE DEL DATASET DE LUB A LONGITUD 5000 DE VALIDITY

            # Store sample
            X[i,0,:]  = self.dataset[key][onset:onset+self.window] #Recorre datos del dataset de cada 64 posiciones con una ventana, hay overlapping
            key = format_string(key)
            # Store mask
            y[i,0,:]  = self.mask_p[key].values[onset:onset+self.window]
            y[i,1,:]  = self.mask_qrs[key].values[onset:onset+self.window]
            y[i,2,:]  = self.mask_t[key].values[onset:onset+self.window]
            y[i,3,:]  = self.mask_null[key].values[onset:onset+self.window]
            mask[i,0,:] = self.mask_generator[key][onset:onset+self.window]
            #VER SI HAY SOLAPE ENTRE ONDAS
            # plot_batch(X[i,0,:],y[i,0,:], y[i,1,:],y[i,2,:],key,onset,self.window,0)
            # plot_batch(X[i,0,:],y[i,0,:], y[i,1,:],y[i,2,:],key,onset,self.window,0)
            # Apply data augmentation:
            # if not(self.DataAugLabel[j] == 'NoAugment'):
            #     Noise = DataAugmentationTransform(X[i,:,0], self.DataAugLabel[j], self.DataAug[j], y[i,:,1])
            #     X[i,:,0] += Noise
           

        return X, y, mask
    

    def __batch_generation_single_c(self, ix):
        '''Generates one datapoint''' 
        # X : (n_samples, *dim, n_channels)
        # Initialization
        X = np.empty((len(ix), self.channels, self.window), dtype='float32')
        mask = np.zeros((len(ix), self.channels, self.window), dtype='float32')
        y = np.empty((len(ix), 4, self.window), dtype='float32')
        # Generate data
        for i, ID in enumerate(ix):
            # Desambiguate data augmentation
          
            j         = ID//self.length_no_aug
            ID        = ID%self.length_no_aug #Ajusta el valor para que este dentro de length_no_aug
            # print(ID)
            # print(self.correspondence[ID])
            w_info    = self.correspondence[ID]
            key       = w_info[0]
            onset     = w_info[1]#CAMBIAR LA PARTE DEL DATASET DE LUB A LONGITUD 5000 DE VALIDITY
            # Store sample
            if key.startswith('sel'):
                X[i,0,:]  = self.dataset[key][onset:onset+self.window] #Recorre datos del dataset de cada 64 posiciones con una ventana, hay overlapping
                
                # Store mask
                y[i,0,:]  = self.mask_p[key].values[onset:onset+self.window]
                y[i,1,:]  = self.mask_qrs[key].values[onset:onset+self.window]
                y[i,2,:]  = self.mask_t[key].values[onset:onset+self.window]
                y[i,3,:]  = self.mask_null[key].values[onset:onset+self.window]
                mask[i,0,:] = self.mask_generator[key][onset:onset+self.window]
                #VER SI HAY SOLAPE ENTRE ONDAS
                # plot_batch(X[i,:,0],y[i,:,0], y[i,:,1],y[i,:,2],key,onset,self.window,0)
                # plot_batch(X[i,:,0],y[i,:,0], y[i,:,1],y[i,:,2],key,onset,self.window,0)
                # Apply data augmentation:
                # if not(self.DataAugLabel[j] == 'NoAugment'):
                #     Noise = DataAugmentationTransform(X[i,:,0], self.DataAugLabel[j], self.DataAug[j], y[i,:,1])
                #     X[i,:,0] += Noise
            else:
                # Store sample
                X[i,0,:]  = self.dataset2[key][onset:onset+self.window] #Recorre datos del dataset de cada 64 posiciones con una ventana, hay overlapping
                key = format_string(key)
                # Store mask
                y[i,0,:]  = self.mask_p2[key].values[onset:onset+self.window]
                y[i,1,:]  = self.mask_qrs2[key].values[onset:onset+self.window]
                y[i,2,:]  = self.mask_t2[key].values[onset:onset+self.window]
                y[i,3,:]  = self.mask_null2[key].values[onset:onset+self.window]
                mask[i,0,:] = self.mask_generator2[key][onset:onset+self.window]
                # plot_batch(X[i,:,0],y[i,:,0], y[i,:,1],y[i,:,2],key,onset,self.window,0)
                # plot_batch(X[i,:,0],y[i,:,0], y[i,:,1],y[i,:,2],key,onset,self.window,0)
                # Apply data augmentation:
                # if not(self.DataAugLabel[j] == 'NoAugment'):
                #     Noise = DataAugmentationTransform(X[i,:,0], self.DataAugLabel[j], self.DataAug[j], y[i,:,1])
                #     X[i,:,0] += Noise

        return X, y, mask
    
    def __batch_generation_single_sintetic(self, ix):
        '''Generates one datapoint''' 
        # X : (n_samples, *dim, n_channels)
        # Initialization
        X = np.empty((len(ix), self.channels, self.window), dtype='float32')
        mask = np.zeros((len(ix), self.channels, self.window), dtype='float32')
        y = np.empty((len(ix), 4, self.window), dtype='float32')
        # Generate data
        for i, ID in enumerate(ix):
            # Desambiguate data augmentation
          
            j         = ID//self.length_no_aug
            ID        = ID%self.length_no_aug #Ajusta el valor para que este dentro de length_no_aug
            # print(ID)
            # print(self.correspondence[ID])
            w_info    = self.correspondence[ID]
            key       = w_info[0]
            onset     = w_info[1]#CAMBIAR LA PARTE DEL DATASET DE LUB A LONGITUD 5000 DE VALIDITY
           
            # Store sample
            X[i,0,:]  = self.dataset[key][onset:onset+self.window] #Recorre datos del dataset de cada 64 posiciones con una ventana, hay overlapping
            key = format_string2(key)
            # Store mask
            y[i,0,:]  = self.mask_p[key].values[onset:onset+self.window]
            y[i,1,:]  = self.mask_qrs[key].values[onset:onset+self.window]
            y[i,2,:]  = self.mask_t[key].values[onset:onset+self.window]
            y[i,3,:]  = self.mask_null[key].values[onset:onset+self.window]
            mask[i,0,:] = self.mask_generator[key][onset:onset+self.window]
            # plot_batch(X[i,0,:],y[i,0,:], y[i,1,:],y[i,2,:],key,onset,self.window,0)
            # plot_batch(X[i,:,0],y[i,:,0], y[i,:,1],y[i,:,2],key,onset,self.window,0)
            # Apply data augmentation:
            # if not(self.DataAugLabel[j] == 'NoAugment'):
            #     Noise = DataAugmentationTransform(X[i,:,0], self.DataAugLabel[j], self.DataAug[j], y[i,:,1])
            #     X[i,:,0] += Noise

        return X, y, mask

    def __batch_generation_multi(self, ix):
        '''Generates one datapoint''' 
        # X : (n_samples, *dim, n_channels)
        # Initialization
        X = np.empty((len(ix), self.window, self.channels), dtype='float32')
        y = np.empty((len(ix), self.window, 3), dtype='float32')

        # Generate data
        for i, ID in enumerate(ix):
            # Desambiguate data augmentation
            j         = ID//self.length_no_aug
            ID        = ID%self.length_no_aug
            w_info    = self.correspondence[ID]
            key       = w_info[0]
            onset     = w_info[1]

            # Store sample
            X[i,:,1]  = self.dataset[key + '_0'][onset:onset+self.window]
            X[i,:,0]  = self.dataset[key + '_1'][onset:onset+self.window]

            # Store mask
            y[i,:,0]  = self.mask_p[key + '_0'].values[onset:onset+self.window] #SI AQUI LO DIVIDO PARA LOS DOS DATASET LA PARTE QUE RELLENE CON 0S O CON NAN DARA PROBLEMAS?
            y[i,:,1]  = self.mask_qrs[key + '_0'].values[onset:onset+self.window]
            y[i,:,2]  = self.mask_t[key + '_0'].values[onset:onset+self.window]

            # # Apply data augmentation:
            # if not(self.DataAugLabel[j] == 'NoAugment'):
            #     Noise_0     = DataAugmentationTransform(X[i,:,0], self.DataAugLabel[j], self.DataAug[j], y[i,:,1])
            #     X[i,:,0]    += Noise_0.squeeze()
            #     Noise_1     = DataAugmentationTransform(X[i,:,0], self.DataAugLabel[j], self.DataAug[j], y[i,:,1])
            #     X[i,:,1]    += Noise_1.squeeze()

        return X, y


    def __str__(self):
        s = ''
        for k in self.__dict__.keys():
            s += '    ├> ' + str(k) + ':\t' + str(self.__dict__[k]) + '\n'
        
        return s
    
    def __repr__(self):
        return str(self)
    


import numpy as np

def create_mask(Pon, Poff, QRSon, QRSoff, Ton, Toff,max_separation, max_length):
    all_marks = np.concatenate((Pon, Poff, QRSon, QRSoff, Ton, Toff))  
    # Sort the combined marks
    all_marks.sort()

    # Initialize mask with zeros
    mask = np.zeros(max_length, dtype='float32')
    # Apply the mask for each mark, considering the maximum separation
    for i in range(len(all_marks)):
        if i == 0:
            # Always start masking from the first mark
            start = all_marks[i]-20
        else:
            # If the distance from the previous mark is greater than max_separation, reset start
            if all_marks[i] - all_marks[i - 1] > max_separation:
                start = all_marks[i]
        
        end = min(max_length, all_marks[i] +20)

        mask[start:end] = 1
        
    return mask

    # Para leer cuando hay aumento de datos 1_0 en vez de 1_0_n
def format_string(s):
    # Divide la cadena en partes usando el guion bajo como separador
    parts = s.split('_')
    
    # Si la cadena tiene más de dos partes, nos quedamos solo con las dos primeras
    if len(parts) > 2:
        return '_'.join(parts[:2])
    
    # Si la cadena ya tiene el formato correcto, la devolvemos tal cual
    return s

def format_string2(s):
    # Divide la cadena en partes usando el guion bajo como separador
    parts = s.split('_')
    
    # Unir las partes que necesitas
    s = f"{parts[0]}_{parts[1]}_{'_'.join(parts[3:])}"
    
    # Si la cadena ya tiene el formato correcto, la devolvemos tal cual
    return s