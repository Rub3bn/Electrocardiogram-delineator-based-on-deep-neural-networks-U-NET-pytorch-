import numpy as np 
import time
import utils.arch_UNET as arch
from utils.logger import conditional_makedir
import os
import random
import tqdm
import scipy as sp
import torch
import math
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from utils.data_structures import save_fiducials
from torch import nn
from torch.utils.data import DataLoader
import torch.nn.functional as F
from argparse import ArgumentParser #Es una forma de estructurar mejor argumentos añadiendolos a una especie de lista
from pandas import read_csv
from pandas import DataFrame
from os import environ
from os.path import join
from os.path import exists
from os.path import abspath
from ast import literal_eval #Convierte texto a lista
from numpy import asarray
from numpy import log
from numpy import logical_not
from numpy.random import seed #Importa una semilla concreta
from scipy.ndimage import distance_transform_edt as dist_transform
from utils.logger import conditional_makedir
from utils.transforms import DistanceMapTransform
import pandas
from utils.data_structures import MyPyTorchDataset
from utils.data_structures import load_data
from utils.data_structures import ConfigParser #Es una clase que se puede usar para inicializar los datos de la plantilla de Configurations
from utils.data_structures import DataStorage #Crea una clase para almacenar e inicializar ordenadamente los datos de todas las ondas (con las funciones de esa clase)
from utils.data_structures import MetricsStorage
from utils.data_structures import encontrar_primer_cero
from utils.data_structures import ExecutionInformation
from utils.check import check_weights_exist
from utils.disambiguator import select_optimizer
from utils.disambiguator import select_loss
from utils.logger import write_summary
from utils.evaluate_capa import evaluate
from utils.evaluate_test import evaluate as testea
from data_plot import plot_batch
from utils.losses import *
from utils.data_structures import format_string
import pickle
import wandb

def main(config): #Función con parámetro config (Ya se verá que hace config)
    # start a new wandb run to track this script
    wandb.init(
        # set the wandb project where this run will be logged
        project="miTFG",

        # track hyperparameters and run metadata
        config={
        "learning_rate": config.learning_rate,
        "architecture": "U-NET",
        "dataset": config.data_path2,
        "epochs": config.n_epochs,
        }
    )

    # Define una métrica personalizada basada en la época
    wandb.define_metric("epoch")
    wandb.define_metric("confusion_matrix_epoch_*", step_metric="epoch")

    if not config.combine :
        seed(seed=config.seed) #Genera una semilla concreta todo el rato
        print('no comb')
        #### LOAD DATASETS ####

        dataset2            = read_csv(join(config.data_path2, 'Dataset.csv'), index_col=0)

        dataset2             = dataset2.sort_index(axis=1)
        labels2             = asarray(list(dataset2))
        print(labels2)
        if override_augment:

            new_columns = {}
            cont = 0
            for i in random.sample(range(1, 9), 2):
                noise            = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{i}.csv', index_col=0)
                noise_labels             = noise.sort_index(axis=1)
                noise_labels             = asarray(list(noise_labels))

                # # Para mostrar todas las columnas
                # pandas.set_option('display.max_columns', None)

                # # Para mostrar todas las filas
                # pandas.set_option('display.max_rows', None)

                noise = noise.iloc[:5000]

                for key in labels2:
                    new_columns[key + f'_n{cont}'] = dataset2[key] + noise[key]

                cont = cont + 1
            
            new_columns_df = pandas.DataFrame(new_columns)
            dataset2 = pandas.concat([dataset2, new_columns_df], axis=1)

            dataset2             = dataset2.sort_index(axis=1)
            labels2             = asarray(list(dataset2))

            print('labels2')
            print(labels2)



        #Contendrá un array NumPy donde cada elemento del array corresponde a una columna del DataFrame dataset.
        description2         = dataset2.describe()

        # Ventana de validación
        ind={}
        for i, key in enumerate(dataset2.keys()):
                ind[i] = encontrar_primer_cero(dataset2[key].values)

        validity2 = pandas.DataFrame({key: [[0], [ind[i]]] for i, key in enumerate(dataset2.keys())}, index=['on', 'off'])  
        print(validity2)


        for k in tqdm.tqdm(labels2):
            # Copy signal just in case
            signal = np.copy(dataset2[k].values)
            
            # Filter signal
            signal = sp.signal.filtfilt(*sp.signal.butter(4,   0.5/500., 'high'),signal.T).T
            signal = sp.signal.filtfilt(*sp.signal.butter(4, 125.0/500.,  'low'),signal.T).T
    
            # Normalize and pad signal for inputing in algorithm
            signal = (dataset2[k] - description2[k]['mean'])/description2[k]['std']
            
            # Store in dataset
            dataset2[k] = signal


        # Initialize data structures for results storage
        data2               = DataStorage(dataset2, validity2)
        results             = DataStorage(dataset2, validity2)
        results_CV2         = DataStorage(dataset2, validity2)
        if not config.data_sintetic:
            # Initialize data storage
            data2.init_P(
                read_csv(join(config.data_path2, 'Pwave.csv'), index_col=0, dtype='float'),
                load_data(join(config.data_path2, 'Pon.csv')),
                load_data(join(config.data_path2, 'Ppeak.csv')),
                load_data(join(config.data_path2, 'Poff.csv'))
            )

            data2.init_QRS(
                read_csv(join(config.data_path2, 'QRSwave.csv'), index_col=0, dtype='float'),
                load_data(join(config.data_path2, 'QRSon.csv')),
                load_data(join(config.data_path2, 'QRSpeak.csv')),
                load_data(join(config.data_path2, 'QRSoff.csv'))
            )

            data2.init_T(
                read_csv(join(config.data_path2, 'Twave.csv'), index_col=0, dtype='float'),
                load_data(join(config.data_path2, 'Ton.csv')),
                load_data(join(config.data_path2, 'Tpeak.csv')),
                load_data(join(config.data_path2, 'Toff.csv'))
            )
            # Utilizar null_obtain cuando no existe null.csv
            # null_obtain(data2,labels2)
            

            data2.init_null(
                read_csv(join(config.data_path2, 'Null.csv'), index_col=0, dtype='float'),
            )
        else:
            # Initialize data storage
            data2.init_P(
                read_csv(join(config.data_path2, 'Pwave.csv'), index_col=0, dtype='float'),
                load_data(join(config.data_path2, 'Pon.csv')),
                [],
                load_data(join(config.data_path2, 'Poff.csv'))
            )

            data2.init_QRS(
                read_csv(join(config.data_path2, 'QRSwave.csv'), index_col=0, dtype='float'),
                load_data(join(config.data_path2, 'QRSon.csv')),
                [],
                load_data(join(config.data_path2, 'QRSoff.csv'))
            )

            data2.init_T(
                read_csv(join(config.data_path2, 'Twave.csv'), index_col=0, dtype='float'),
                load_data(join(config.data_path2, 'Ton.csv')),
                [],
                load_data(join(config.data_path2, 'Toff.csv'))
            )
            # Utilizar null_obtain cuando no existe null.csv
            # null_obtain(data2,labels2)
            

            data2.init_null(
                read_csv(join(config.data_path2, 'Null.csv'), index_col=0, dtype='float'),
            )
        #Comprobación solapamiento de ondas

        # for key in labels2:
        #     P = data2.P.wave[key]
        #     QRS = data2.QRS.wave[key]
        #     T = data2.T.wave[key]
        #     Null = data2.null.wave[key]
        #     vectores = [P, QRS, T, Null]
        #     detectar_solapamiento(vectores)
        # print('################### finish ###################')
        #### TRAIN/TEST DISTRIBUTION IMPORTING ####
    
        if not config.data_sintetic:
            if str(labels2[1][:3]) == "sel":
                train_keys = read_csv('./CommonDistribution/TrainSplit_Labels.csv',index_col=0)#Etiquetas de entrenamiento
        
                test_keys  = read_csv('./CommonDistribution/TestSplit_Labels.csv',index_col=0)

            else:
                train_keys = read_csv('./CommonDistribution/TrainSplit_Labels_L.csv',index_col=0)#Etiquetas de entrenamiento
        
                test_keys  = read_csv('./CommonDistribution/TestSplit_Labels_L.csv',index_col=0)
        else:
            train_keys = read_csv('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/CommonDistribution/train_sintetic.csv',index_col=0)#Etiquetas de entrenamiento
        
            test_keys  = read_csv('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/CommonDistribution/test_sintetic.csv',index_col=0)

        KFolds     = [tuple([train_keys.values[i,:],test_keys.values[i,:]]) for i in range(train_keys.shape[0])]#Contiene 10 arrays que corresponden con las train y test keys juntadas
        #Junta train y test key array en una componente
        print('kfolds')
        print(KFolds)

        # #### TRAIN THE MODEL ####
        # Keep track of training time
        t_start = time.time()
        (train_keys, test_keys)  = KFolds[0]
        # (train_keys, valid_keys) = shuffle_split_array(train_keys, config.val_split)
        execinfo = ExecutionInformation(config, 1, train_keys, test_keys, config.evaluate)
        
        print('execinfo')
        print(execinfo)
        
        # Train a single fold
        if not(config.evaluate):
            print('no evaluate')
            train_fold(config, data2, execinfo, results, results_CV2, dataset2, validity2, True)
    
            # Check total training time
            time_elapsed = time.time() - t_start
            print('\n * Training complete in {:.0f}m {:.0f}s\n'.format(time_elapsed // 60, time_elapsed % 60))

        # Retrieve patient ID from lead data
        IDs = np.asarray(list(set(train_keys.tolist() + test_keys.tolist()))) # Lista test evitando duplicados

        # Sanity check
        if len(IDs) != len(train_keys) + len(test_keys):
            raise ValueError("Some record shared between train and test!")

        # Evaluation of whole dataset
        if config.evaluate:
            print('evaluate')
            model = arch.UNet(config)

            if (config.evaluate) and os.path.exists(execinfo.state):
               
                # Cargar los pesos desde el archivo
                state_dict = torch.load(execinfo.state, map_location=torch.device('cpu'))
                model.load_state_dict(state_dict)
                print('Pesos cargados')
            else:
                raise ValueError("No hay pesos")

            # # Select optimizer and loss + compile
            # optim   = select_optimizer(model, config.optimizer.lower(),lr=config.learning_rate)
            # loss    = select_loss(config.loss.lower())
            # model.compile(optimizer=optim, loss=loss) #Añade el optimizador y la función de pérdidas a la red 
            
            evaluate(model, config, data2, execinfo, results, results_CV2, True) # CAMBIAR A EXTRACT_PREDICTED_RESULTS

    if config.combine :
        seed(seed=config.seed) #Genera una semilla concreta todo el rato

        dataDir1 = "qt-database-1.0.0/qt-database-1.0.0/manual0/"
        dataDir2="lobachevsky-university-electrocardiography-database-1.0.1/data/ToCSV/"

        #### LOAD DATASETS ####

        dataset1            = read_csv(join(dataDir1, 'Dataset.csv'), index_col=0)



        dataset2            = read_csv(join(dataDir2, 'Dataset.csv'), index_col=0)

        dataset1             = dataset1.sort_index(axis=1)
        dataset2             = dataset2.sort_index(axis=1)

        labels1             = asarray(list(dataset1))
        labels2             = asarray(list(dataset2))
    
        if override_augment:
            new_columns = {}
            cont = 0
            for i in random.sample(range(1, 9), 2):
                noise            = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{i}.csv', index_col=0)
                noise_labels             = noise.sort_index(axis=1)
                noise_labels             = asarray(list(noise_labels))

                noise = noise.iloc[:5000]

                for key in labels2:
                    new_columns[key + f'_n{cont}'] = dataset2[key] + noise[key]
                cont = cont + 1
               
            new_columns_df = pandas.DataFrame(new_columns)
            dataset2 = pandas.concat([dataset2, new_columns_df], axis=1)
        
            dataset2             = dataset2.sort_index(axis=1)  
            labels2             = asarray(list(dataset2))
        #Contendrá un array NumPy donde cada elemento del array corresponde a una columna del DataFrame dataset.
        description1         = dataset1.describe()
        description2         = dataset2.describe()

        # Ventana de validación
        ind={}
        for i, key in enumerate(dataset1.keys()):
                ind[i] = encontrar_primer_cero(dataset1[key].values)

        validity1 = pandas.DataFrame({key: [[0], [ind[i]]] for i, key in enumerate(dataset1.keys())}, index=['on', 'off'])  
        print(validity1)

        ind={}
        for i, key in enumerate(dataset2.keys()):
                ind[i] = encontrar_primer_cero(dataset2[key].values)

        validity2 = pandas.DataFrame({key: [[0], [ind[i]]] for i, key in enumerate(dataset2.keys())}, index=['on', 'off'])  
        print(validity2)

        # Zero-center data (Normalización)
        for k in tqdm.tqdm(list(dataset1)):
            # Copy signal just in case
            signal = np.copy(dataset1[k].values)
            
            # Filter signal
            signal = sp.signal.filtfilt(*sp.signal.butter(4,   0.5/500., 'high'),signal.T).T
            signal = sp.signal.filtfilt(*sp.signal.butter(4, 125.0/500.,  'low'),signal.T).T

            # Normalize and pad signal for inputing in algorithm
            signal = (dataset1[k] - description1[k]['mean'])/description1[k]['std']
            
            # Store in dataset
            dataset1[k] = signal
        for key in description2: 
            dataset2[key]    = (dataset2[key] - description2[key]['mean'])/description2[key]['std'] #Normalización (x-mu/sigma)

        # Initialize data structures for results storage
        data1               = DataStorage(dataset1, validity1)
        data2               = DataStorage(dataset2, validity2)
        results             = DataStorage(dataset2, validity2)
        results_CV2         = DataStorage(dataset2, validity2)
        
        # Initialize data storage
        data1.init_P(
            read_csv(join(dataDir1, 'Pwave.csv'), index_col=0, dtype='float'),
            load_data(join(dataDir1, 'Pon.csv')),
            load_data(join(dataDir1, 'Ppeak.csv')),
            load_data(join(dataDir1, 'Poff.csv'))
        )

        data1.init_QRS(
            read_csv(join(dataDir1, 'QRSwave.csv'), index_col=0, dtype='float'),
            load_data(join(dataDir1, 'QRSon.csv')),
            load_data(join(dataDir1, 'QRSpeak.csv')),
            load_data(join(dataDir1, 'QRSoff.csv'))
        )

        data1.init_T(
            read_csv(join(dataDir1, 'Twave.csv'), index_col=0, dtype='float'),
            load_data(join(dataDir1, 'Ton.csv')),
            load_data(join(dataDir1, 'Tpeak.csv')),
            load_data(join(dataDir1, 'Toff.csv'))
        )
        data1.init_null(
            read_csv(join(dataDir1, 'Null.csv'), index_col=0, dtype='float'),
        )

        data2.init_P(
            read_csv(join(dataDir2, 'Pwave.csv'), index_col=0, dtype='float'),
            load_data(join(dataDir2, 'Pon.csv')),
            load_data(join(dataDir2, 'Ppeak.csv')),
            load_data(join(dataDir2, 'Poff.csv'))
        )

        data2.init_QRS(
            read_csv(join(dataDir2, 'QRSwave.csv'), index_col=0, dtype='float'),
            load_data(join(dataDir2, 'QRSon.csv')),
            load_data(join(dataDir2, 'QRSpeak.csv')),
            load_data(join(dataDir2, 'QRSoff.csv'))
        )

        data2.init_T(
            read_csv(join(dataDir2, 'Twave.csv'), index_col=0, dtype='float'),
            load_data(join(dataDir2, 'Ton.csv')),
            load_data(join(dataDir2, 'Tpeak.csv')),
            load_data(join(dataDir2, 'Toff.csv'))
        )
        data2.init_null(
            read_csv(join(dataDir2, 'Null.csv'), index_col=0, dtype='float'),
        )
       
        #### TRAIN/TEST DISTRIBUTION IMPORTING ####
    
       #Lobachevsky
        
        train_keys1 = read_csv('./CommonDistribution/TrainSplit_Labels.csv',index_col=0)#Etiquetas de entrenamiento

        test_keys1  = read_csv('./CommonDistribution/TestSplit_Labels.csv',index_col=0)

        train_keys2 = read_csv('./CommonDistribution/TrainSplit_Labels_L.csv',index_col=0)#Etiquetas de entrenamiento

        test_keys2  = read_csv('./CommonDistribution/TestSplit_Labels_L.csv',index_col=0)

        train_keys = pandas.concat([train_keys1, train_keys2.astype(str)], axis=1)

        test_keys = pandas.concat([test_keys1, test_keys2.astype(str)], axis=1)

        KFolds     = [tuple([train_keys.values[i,:],test_keys.values[i,:]]) for i in range(train_keys.shape[0])]#Contiene 10 arrays que corresponden con las train y test keys juntadas
        #Junta la train y test key array en una componente
        print('kfolds')
        print(KFolds)

        # #### TRAIN THE MODEL ####
        # Keep track of training time
        t_start = time.time()
        (train_keys, test_keys)  = KFolds[0]
        test_keys = tuple(test_keys2.values[0,:].astype(str))
        print('test_keys')
        print(test_keys)
        # (train_keys, valid_keys) = shuffle_split_array(train_keys, config.val_split)
        execinfo = ExecutionInformation(config, 1, train_keys, test_keys, config.evaluate)
        
        print('execinfo')
        print(execinfo)
        
        # Train a single fold
        if not(config.evaluate):
            print('no evaluate')
            train_fold_c(config, data1, data2, execinfo, results, results_CV2, dataset2, validity2, True)


            # Check total training time
            time_elapsed = time.time() - t_start
            print('\n * Training complete in {:.0f}m {:.0f}s\n'.format(time_elapsed // 60, time_elapsed % 60))

        # # Retrieve patient ID from lead data
        # IDs = np.asarray(list(set(train_keys.tolist() + test_keys.tolist()))) # Lista test evitando duplicados

        # # Sanity check
        # if len(IDs) != len(train_keys) + len(test_keys):
        #     raise ValueError("Some record shared between train and test!")

        # # Evaluation of whole dataset
        # if config.evaluate:
        #     print('evaluate')
        #     model = arch.UNet(config)

        #     if (config.evaluate) and os.path.exists(execinfo.state):
               
        #         # Cargar los pesos desde el archivo
        #         state_dict = torch.load(execinfo.state)
        #         model.load_state_dict(state_dict)
        #         print('Pesos cargados')

        #     # # Select optimizer and loss + compile
        #     # optim   = select_optimizer(model, config.optimizer.lower(),lr=config.learning_rate)
        #     # loss    = select_loss(config.loss.lower())
        #     # model.compile(optimizer=optim, loss=loss) #Añade el optimizador y la función de pérdidas a la red 
            
        #     extract(model, config, data2, execinfo, results, results_CV2, True) # CAMBIAR A EXTRACT_PREDICTED_RESULTS


def train_fold(config, data, execinfo,  results, results_CV2, dataset2, validity2, recompute):
    metrics     = MetricsStorage()
    metrics_CV2 = MetricsStorage()
    # Get cpu, gpu or mps device for training.
    device = (
        "cuda"
        if torch.cuda.is_available()
        else "mps"
        if torch.backends.mps.is_available()
        else "cpu"
    )
    print('device')
    print(device)
    ############################# MODEL CREATION ############################
    model = arch.UNet(config) #Creamos UNET
    model.to(device)
    wandb.watch(model, log_freq=100)
    # Select optimizer and loss + compile
    optim   = select_optimizer(model, config.optimizer.lower(),lr=config.learning_rate)

    # If chosen and exists, load weights (fine-tuning, etc.)
    if (config.load_weights or config.evaluate) and os.path.exists(execinfo.state):
        state_dict = torch.load(execinfo.state, map_location=torch.device('cpu'))
        model.load_state_dict(state_dict)
        print('Pesos cargados')
    if (config.load_weights or config.evaluate) and not os.path.exists(execinfo.state):
        raise ValueError("No existen pesos")
    # If the flag to evaluate has not been set, train the model
    if not config.evaluate:
        # Data generators
        print(execinfo.train)
        GeneratorTrain = MyPyTorchDataset(execinfo.train, config, data,'none',0, 1) #Agrupa los datos de forma que cada archivo (entrada) vaya con una marca
        GeneratorValid = MyPyTorchDataset(execinfo.valid, config, data,'none',1, 1)
        print('generator')
        
        dataloader_Train = DataLoader(GeneratorTrain,batch_size = None,shuffle=True)
        dataloader_valid = DataLoader(GeneratorValid,batch_size = None,shuffle=True)
        
        # GeneratorTrain.__init__
        #print(GeneratorValid) 

        # torch train
        epochs = config.n_epochs
        
        train_epochs(dataloader_Train, dataloader_valid, model, None, optim, device, execinfo, data, metrics, metrics_CV2, results, results_CV2,dataset2, validity2)
        
        print("Done!")


def train_fold_c(config, data1, data2, execinfo, results, results_CV2, dataset2, validity2, recompute):
    
    metrics     = MetricsStorage()
    metrics_CV2 = MetricsStorage()
    # Get cpu, gpu or mps device for training.
    device = (
        "cuda"
        if torch.cuda.is_available()
        else "mps"
        if torch.backends.mps.is_available()
        else "cpu"
    )
    print('device')
    print(device)
    ############################# MODEL CREATION ############################
    model = arch.UNet(config) #Creamos UNET
    model.to(device)
    wandb.watch(model, log_freq=100)
    # Select optimizer and loss + compile
    optim   = select_optimizer(model, config.optimizer.lower(),lr=config.learning_rate)

    # If chosen and exists, load weights (fine-tuning, etc.)
    if (config.load_weights or config.evaluate) and os.path.exists(execinfo.state):
        state_dict = torch.load(execinfo.state, map_location=torch.device('cpu'))
        model.load_state_dict(state_dict)
        print('Pesos cargados')
    if (config.load_weights or config.evaluate) and not os.path.exists(execinfo.state):
        raise ValueError("No existen pesos")

    # If the flag to evaluate has not been set, train the model
    if not config.evaluate:
        # Data generators
        print(execinfo.train)
        print(execinfo.valid)
        GeneratorTrain = MyPyTorchDataset(execinfo.train, config, data1, data2, 0, 0) #Agrupa los datos de forma que cada archivo (entrada) vaya con una marca
        GeneratorValid = MyPyTorchDataset(execinfo.valid, config, data1, data2, 1, 0)
        print('generator')
        
        dataloader_Train = DataLoader(GeneratorTrain,batch_size = None,shuffle=True)
        dataloader_valid = DataLoader(GeneratorValid,batch_size = None,shuffle=True)
      
        # GeneratorTrain.__init__
        #print(GeneratorValid) 

        # torch train
        epochs = config.n_epochs
        
        train_epochs(dataloader_Train, dataloader_valid, model, None, optim, device, execinfo, data2, metrics, metrics_CV2, results, results_CV2,dataset2, validity2)
        
        print("Done!")



def train_epochs(dataloader,dataloader_valid, model, loss_fn, optimizer, device, execinfo, data1,  metrics, metrics_CV2, results, results_CV2, dataset2, validity2):
   
    paso_muesta = 100
    cont = 0
    size_d = len(dataloader.dataset)
    model.train()
    epochs = config.n_epochs

    
    size_metrics = math.ceil(epochs*size_d/paso_muesta) + epochs*3
    J_it=np.zeros(size_metrics+1)
    J_it_epoch = np.zeros(epochs)
    J = nn.CrossEntropyLoss(ignore_index=np.inf)
    metricas = {
        'losses_te': [],
        'losses_tr': [],
        'precision_P_te': [],
        'recall_P_te': [],
        'precision_QRS_te': [],
        'recall_QRS_te': [],
        'precision_T_te': [],
        'recall_T_te': [],
        'precision_P_tr': [],
        'recall_P_tr': [],
        'precision_QRS_tr': [],
        'recall_QRS_tr': [],
        'precision_T_tr': [],
        'recall_T_tr': []
    }
    cont2 = 0
    cont3 = 0
    for epoch in range(epochs):
        progress_bar = tqdm.tqdm(dataloader, desc=f'Epoch {epoch + 1}/{epochs}', leave=False)
        for batch, (X, y, mask) in enumerate(dataloader):
            
            model.train()
            if batch % paso_muesta == 0:
                cont = cont + 1
            # Compute prediction error
            # plot_batch(X[batch,0,:],y[batch,0,:], y[batch,1,:],y[batch,2,:],'g',0,config.window,1)
            y_true = y
            y = torch.argmax(y, dim=1) #Convertir etiquetas one-hot a clases simples
            
            X, y, mask = X.to(device), y.to(device), mask.to(device)

        
            optimizer.zero_grad()

            pred = model(X)

            mask = mask.squeeze(1)

            loss = masked_ce(pred, y, mask)

            # Backpropagation
            loss.backward()
            optimizer.step()
            

            # if batch % (math.ceil(size_d / 4)+1) == 0:
            #     cm = test_epochs(dataloader_valid, model, loss_fn, device, epoch)
            progress_bar.set_postfix({'Loss': J_it[cont-1]})
            progress_bar.update()
             
        
        # Imprime la pérdida promedio de la época
        results             = DataStorage(dataset2, validity2)
        results_CV2         = DataStorage(dataset2, validity2)
        
        metrics     = MetricsStorage()
        metrics_CV2 = MetricsStorage()
        if not config.data_sintetic:
            precision_P_te, recall_P_te, precision_QRS_te, recall_QRS_te, precision_T_te, recall_T_te, onset_P_te, offset_P_te, dice_P_te, onset_QRS_te, offset_QRS_te, dice_QRS_te, onset_T_te, offset_T_te, dice_T_te , J_it_te = test_epochs(dataloader_valid, model, loss_fn, device, epoch,execinfo, data1, metrics, metrics_CV2, results, results_CV2)
            precision_P_tr, recall_P_tr, precision_QRS_tr, recall_QRS_tr, precision_T_tr, recall_T_tr, onset_P_tr, offset_P_tr, dice_P_tr, onset_QRS_tr, offset_QRS_tr, dice_QRS_tr, onset_T_tr, offset_T_tr, dice_T_tr , J_it_tr = test_epochs(dataloader, model, loss_fn, device, epoch,execinfo, data1, metrics, metrics_CV2, results, results_CV2)

            wandb.log({"loss_batch_te": J_it_te})
            wandb.log({"loss_batch_tr": J_it_tr})

            
            wandb.log({
                "precision_P_te": precision_P_te,
                "recall_P_te": recall_P_te,
                "precision_QRS_te": precision_QRS_te,
                "recall_QRS_te": recall_QRS_te,
                "precision_T_te": precision_T_te,
                "recall_T_te": recall_T_te,
                "J_it_te": J_it_te,
                "precision_P_tr": precision_P_tr,
                "recall_P_tr": recall_P_tr,
                "precision_QRS_tr": precision_QRS_tr,
                "recall_QRS_tr": recall_QRS_tr,
                "precision_T_tr": precision_T_tr,
                "recall_T_tr": recall_T_tr,
                "onset_P_te" : onset_P_te,
                "offset_P_te" : offset_P_te,
                "onset_P_tr" : onset_P_tr,
                "offset_P_tr" : offset_P_tr,
                "onset_QRS_te" : onset_QRS_te,
                "offset_QRS_te" : offset_QRS_te,
                "onset_QRS_tr" : onset_QRS_tr,
                "offset_QRS_tr" : offset_QRS_tr,
                "onset_T_te" : onset_T_te,
                "offset_T_te" : offset_T_te,
                "onset_T_tr" : onset_T_tr,
                "offset_T_tr" : offset_T_tr,
                "J_it_tr": J_it_tr,
                "epoch" : epoch
            })


            metrics_values = [
                (precision_P_te, recall_P_te, 'precision_P_te', 'recall_P_te'),
                (precision_QRS_te, recall_QRS_te, 'precision_QRS_te', 'recall_QRS_te'),
                (precision_T_te, recall_T_te, 'precision_T_te', 'recall_T_te'),
                (precision_P_tr, recall_P_tr, 'precision_P_tr', 'recall_P_tr'),
                (precision_QRS_tr, recall_QRS_tr, 'precision_QRS_tr', 'recall_QRS_tr'),
                (precision_T_tr, recall_T_tr, 'precision_T_tr', 'recall_T_tr')
            ]


            metricas['losses_te'].append(J_it_te)
            metricas['losses_tr'].append(J_it_tr)

            for prec, rec, prec_key, rec_key in metrics_values:
                metricas[prec_key].append(prec)
                metricas[rec_key].append(rec)

    torch.save(model.state_dict(), execinfo.state)

   
    # Guardar las métricas en archivos .npy
    save_paths = {
        'losses_te': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/losses_te_UNET.npy',
        'losses_tr': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/losses_tr_UNET.npy',
        'precision_P_te': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/precision_P_te_UNET.npy',
        'recall_P_te': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/recall_P_te_UNET.npy',
        'precision_QRS_te': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/precision_QRS_te_UNET.npy',
        'recall_QRS_te': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/recall_QRS_te_UNET.npy',
        'precision_T_te': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/precision_T_te_UNET.npy',
        'recall_T_te': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/recall_T_te_UNET.npy',
        'precision_P_tr': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/precision_P_tr_UNET.npy',
        'recall_P_tr': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/recall_P_tr_UNET.npy',
        'precision_QRS_tr': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/precision_QRS_tr_UNET.npy',
        'recall_QRS_tr': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/recall_QRS_tr_UNET.npy',
        'precision_T_tr': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/precision_T_tr_UNET.npy',
        'recall_T_tr': '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/metrics_represent/5_3_sint/recall_T_tr_UNET.npy'
    }

    # Convierte las listas a arrays de numpy y guárdalas
    for key, path in save_paths.items():
        np.save(path, np.array(metricas[key]))


def masked_ce(logits, labels, mask):
    loss = torch.nn.functional.cross_entropy(logits, labels, reduction='none')
    loss = loss * mask
    loss = loss.sum() / mask.sum()
    return loss

def test_epochs(dataloader, model, loss_fn,device, step, execinfo, data1, metrics, metrics_CV2, results, results_CV2):
    
    size = len(dataloader.dataset)
    paso_muesta = 50
    pas = 0
    size_d = len(dataloader.dataset)
    model.train()
    epochs = config.n_epochs
    size_metrics = math.ceil(epochs*size_d/paso_muesta)
    J_it=np.zeros(size_metrics)
    model.eval()
    test_loss, correct = 0, 0
    precision = {}
    recall = {}
    torch.save(model.state_dict(), execinfo.state)
    J_it = 0
    with torch.no_grad():
        for X, y, mask in dataloader:
            y = torch.argmax(y, dim=1) #Convertir etiquetas one-hot a clases simples
            
            X, y, mask = X.to(device), y.to(device), mask.to(device)

            pred = model(X)

            mask = mask.squeeze(1)

            loss = masked_ce(pred, y, mask)

            print(loss.item())
            J_it += loss.item() / size_d
    
    precision_P, recall_P, precision_QRS, recall_QRS, precision_T, recall_T, onset_P, offset_P, dice_P, onset_QRS, offset_QRS, dice_QRS, onset_T, offset_T, dice_T = testea(model, config, data1, execinfo, metrics, metrics_CV2, results, results_CV2, False)
            

    return precision_P, recall_P, precision_QRS, recall_QRS, precision_T, recall_T, onset_P, offset_P, dice_P, onset_QRS, offset_QRS, dice_QRS, onset_T, offset_T, dice_T, J_it

def Precision(y_true, y_pred, epoch):
    # Aplanar las etiquetas verdaderas y las predicciones para usar en sklearn.metrics.confusion_matrix
    y_true = y_true.view(-1).cpu().numpy()
    y_pred = y_pred.view(-1).cpu().numpy()
    print(y_pred)
    print(y_true)
    labels = [0, 1, 2, 3]  # Corresponden a 'P', 'QRS', 'T', 'null'
    
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    precision, recall = calculate_metrics(cm)
   
    return cm, precision, recall
def calculate_metrics(cm):
    # Inicializa diccionarios para precisión y recall
    precision = {}
    recall = {}

    # Calcula precisión y recall para cada clase
    for i, label in enumerate(["P", "QRS", "T", "null"]):
        tp = cm[i, i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp

        precision[label] = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall[label] = tp / (tp + fn) if (tp + fn) > 0 else 0

    return precision, recall    

def DiceLoss(y_true, y_pred):
    smooth = torch.finfo(y_true.dtype).eps
    y_true_f = y_true.view(y_true.size(0), -1)
    y_pred_f = y_pred.view(y_pred.size(0), -1)
    intersection = torch.sum(y_true_f * y_pred_f, dim=-1, keepdim=True)
    union = torch.sum(y_true_f, dim=-1, keepdim=True) + torch.sum(y_pred_f, dim=-1, keepdim=True)
    dice = torch.mean((2. * intersection + 1. + smooth) / (union + 1. + smooth))
    return 1 - dice  

def null_obtain(data,labels):
    null = pandas.DataFrame()
    labels = asarray(list(data.P.wave))
    print(labels)
    for label in labels:
    
        P = data.P.wave[label]
        QRS = data.QRS.wave[label]
        T = data.T.wave[label]
        null[label] = ([1 - max(v1, v2, v3) for v1, v2, v3 in zip(P, QRS, T)])
        null[label] = null[label].astype(int)
    null.to_csv(os.path.join(config.data_path2, 'Null.csv'), index=True)
    
def detectar_solapamiento(vectores):
    for i, vector in enumerate(vectores):
        for j, otro_vector in enumerate(vectores):
            if i != j:  # Evitar comparar un vector consigo mismo
                if any(x == 1 and y == 1 for x, y in zip(vector, otro_vector)):
                    print(f"Solapamiento detectado entre el vector {i+1} y el vector {j+1}")


if __name__ == '__main__':
    # Retrieve input data
    parser = ArgumentParser() #Añade argumentos con el nombre que pones en la primera coma
    parser.add_argument('--evaluate',       type=str, default='no', help='whether to train or evaluate')
    parser.add_argument('--backend',        type=str, default='keras', help='backend to use')
    parser.add_argument('--data_path',      type=str, default="qt-database-1.0.0/qt-database-1.0.0/automatic/", help='qt-database-1.0.0/qt-database-1.0.0/manual0/   lobachevsky-university-electrocardiography-database-1.0.1/data/ToCSV/   /home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/combined_noise_data/')
    parser.add_argument('--data_path2',      type=str, default="qt-database-1.0.0/qt-database-1.0.0/automatic/", help='qt-database-1.0.0/qt-database-1.0.0/manual0/   lobachevsky-university-electrocardiography-database-1.0.1/data/ToCSV/   /home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/combined_noise_data/')
    parser.add_argument('--data_set',       type=str, default='manual0', help='which dataset to use, in {automatic, manual0, manual1}')
    parser.add_argument('--stride',         type=int, default=None, help='override default stride')
    parser.add_argument('--data_aug',       type=str, default='no', help='override data augmentation')
    parser.add_argument('--n_epochs',       type=str, default=None, help='override number of epochs')
    parser.add_argument('--output_dir',     type=str, default=None, help='output directory to store weights and evaluations')
    parser.add_argument('--config_path',    type=str, default='./Configurations.csv' , help='file with all considered configurations')    
    parser.add_argument('--splitting',      type=str, default='cross_validation', help='"cross_validation" or "all"')
    parser.add_argument('--load_weights',   type=str, default='no', help='Load existing weights? Useful for fine-tuning')
    parser.add_argument('--config',         type=int, default=0, help='specific configuration to run')
    parser.add_argument('--combine',        type=str, default='yes', help='combine QT and Lob')
    parser.add_argument('--data_sintetic',  type=str, default='no', help='data sintetic trainting')
    
    inputs              = parser.parse_args()

    ex_id               = inputs.config
    data_set            = inputs.data_set
    override_stride     = inputs.stride
    override_augment    = inputs.data_aug.lower() in ['1', 'true', 'yes', 'y']

    override_epochs     = inputs.n_epochs
    data_path2          = inputs.data_path
    data_path           = inputs.data_path2
    config_path         = inputs.config_path
    output_dir          = inputs.output_dir
    backend             = inputs.backend    
    splitting           = inputs.splitting
    load_weights        = inputs.load_weights.lower() in ['1', 'true', 'yes', 'y']
    evaluate            = inputs.evaluate.lower() in ['1', 'true', 'yes', 'y']
    combine             = inputs.combine.lower() in ['1', 'true', 'yes', 'y']
    data_sintetic       = inputs.data_sintetic.lower() in ['1', 'true', 'yes', 'y']

    # Store 
    Configurations      = read_csv(config_path,index_col=0) #Accede al archivo de configuraciones
  
  
    ExecutionParams     = Configurations.T[int(ex_id)] #Traspone y accede con un índice a una cofiguración especifica
 
    if (override_augment != None) and (override_augment not in ['', 'None']) and (override_augment in ['1', 'true', 'yes', 'y']):
        ExecutionParams['T_DataAug'] = True
    if (override_stride != None) and (override_stride not in ['', 'None']):
        ExecutionParams['T_Stride']  = int(override_stride)
    if (override_epochs != None) and (override_epochs not in ['', 'None']):
        ExecutionParams['T_Epochs']  = int(override_epochs)
   
    #### PARAMETERS ####    
    config = ConfigParser(ExecutionParams, ex_id, override_augment, data_path2, data_path, data_set, splitting, load_weights, backend, output_dir, evaluate,combine, data_sintetic)
    # print(config.data_path2)
    print("CURRENT CONFIGURATION: ")
    print(" ")
    print(ExecutionParams)
    print(" ")
    print("Data path:      " + config.data_path2)
    print("Data path2:      " + config.data_path)
    print("Output path:    " + config.output_dir)
    print("Training split: " + config.splitting)
    print("Train model:    " + str(not config.evaluate))
    print("Load weights:   " + str(config.load_weights))
    print("Backend:        " + config.backend)
    print(" ")

    print(config)
    print(config.seed)
    # Call main function
    main(config)
