function val_est = correspondencia_val(marcas, results, tolerancia)
    % Inicializar un vector para almacenar los valores parecidos
    val_est = 100000*ones(length(marcas),1); 
    % Comparar y retener los valores parecidos
    for i = 1:length(marcas)
        for j = 1:length(results)
            if abs(marcas(i) - results(j)) <= tolerancia
                % El valor es parecido, añadirlo al vector
                if val_est(i) > results(j)
                    val_est(i) = [results(j)];
                end
            end
        end
    end
    val_est = val_est';
end