import numpy as np
import wfdb
import os
import os.path
import pandas
import glob
from utils.data_structures import save_fiducials
from axis_data import get_minmax
from scipy.interpolate import interp1d

dataDir = "qt-database-1.0.0/qt-database-1.0.0/"
dataDir2="lobachevsky-university-electrocardiography-database-1.0.1/data/"

dataset = pandas.DataFrame() #Datos en forma de matriz 2D con índices
dataset2 = pandas.DataFrame()
dataset_new = pandas.DataFrame()
records           = glob.glob(dataDir + '*.dat') #Elegir los archivos .dat
records2          =glob.glob(dataDir2 + '*.dat') #Obtiene exactamente los path de cada archivo .dat
lengths           = np.zeros(len(records),)
nsig              = np.zeros(len(records),)
lengths2           = np.zeros(len(records2),)
nsig2              = np.zeros(len(records2),)
maxSize           = 450000
maxSize_noI       =225000
maxSize2          =5000

# Retrieve the signals    
for filename in records:
    fname = os.path.splitext(os.path.split(filename)[1])[0]
    print(fname)
    # Read record
    rec = wfdb.rdrecord(dataDir + fname)
    dataset[fname + '_0']               = (rec.adc()[-1,0] - rec.baseline[0])/np.asarray(rec.adc_gain[0])*np.ones((maxSize_noI,))
    dataset[fname + '_1']               = (rec.adc()[-1,1] - rec.baseline[1])/np.asarray(rec.adc_gain[1])*np.ones((maxSize_noI,))


    dataset[fname + '_0'][:rec.sig_len] = (rec.adc()[:,0] - rec.baseline[0])/np.asarray(rec.adc_gain[0])
    dataset[fname + '_1'][:rec.sig_len] = (rec.adc()[:,1] - rec.baseline[1])/np.asarray(rec.adc_gain[1])
    
    # Crear un arreglo con el doble de puntos
    dataset_new_0 = np.linspace(0, len(dataset[fname + '_0']) - 1, 2 * (len(dataset[fname + '_0']) - 1) + 1)
    dataset_new_1 = np.linspace(0, len(dataset[fname + '_1']) - 1, 2 * (len(dataset[fname + '_1']) - 1) + 1)
    
    # Crear una función de interpolación lineal
    f_0 = interp1d(np.arange(len(dataset[fname + '_0'])), dataset[fname + '_0'], kind='linear')
    f_1 = interp1d(np.arange(len(dataset[fname + '_1'])), dataset[fname + '_1'], kind='linear')

    # Interpolar la señal en el nuevo arreglo
    dataset_new[fname + '_0'] = f_0(dataset_new_0)
    dataset_new[fname + '_1'] = f_1(dataset_new_1)

dataset_new.to_csv(os.path.join(dataDir,'automatic','Dataset.csv'))

# QRSon_automatic   = dict()
# QRSpeak_automatic = dict()
# QRSoff_automatic  = dict()

# Pon_automatic     = dict()
# Ppeak_automatic   = dict()
# Poff_automatic    = dict()

# Ton_automatic     = dict()
# Tpeak_automatic   = dict()
# Toff_automatic    = dict()

# QRSon_manual0     = dict()
# QRSpeak_manual0   = dict()
# QRSoff_manual0    = dict()

# Pon_manual0       = dict()
# Ppeak_manual0     = dict()
# Poff_manual0      = dict()

# Ton_manual0       = dict()
# Tpeak_manual0     = dict()
# Toff_manual0      = dict()

# QRSon_manual1     = dict()
# QRSpeak_manual1   = dict()
# QRSoff_manual1    = dict()

# Pon_manual1       = dict()
# Ppeak_manual1     = dict()
# Poff_manual1      = dict()

# Ton_manual1       = dict()
# Tpeak_manual1     = dict()
# Toff_manual1      = dict()

# Pwave_automatic   = pandas.DataFrame()
# QRSwave_automatic = pandas.DataFrame()
# Twave_automatic   = pandas.DataFrame()

# Pwave_manual0     = pandas.DataFrame()
# QRSwave_manual0   = pandas.DataFrame()
# Twave_manual0     = pandas.DataFrame()

# Pwave_manual1     = pandas.DataFrame()
# QRSwave_manual1   = pandas.DataFrame()
# Twave_manual1     = pandas.DataFrame()



# for filename in records:
#     fname = os.path.splitext(os.path.split(filename)[1])[0]

#     ############# MANUAL ANNOTATIONS #############
#     # First annotator & filter _out_ repeated T fiducials (some registries mark T and T prime)
#     manual0 = wfdb.rdann(dataDir + fname, 'q1c', return_label_elements=['label_store', 'symbol'] , summarize_labels=None)
#     indexes = np.where(np.diff(manual0.label_store) == 0)[0]+1
#     manual0.num = np.delete(manual0.num, indexes)
#     manual0.label_store = np.delete(manual0.label_store, indexes)
#     manual0.sample = np.delete(manual0.sample, indexes)*2-1 #Interpolación

#     # Second annotator & filter _out_ repeated T fiducials (some registries mark T and T prime)
#     if os.path.exists(dataDir + fname + '.q2c'):
#         manual1 = wfdb.rdann(dataDir + fname, 'q2c', return_label_elements=['label_store', 'symbol'], summarize_labels=None)
#         indexes = np.where(np.diff(manual1.label_store) == 0)[0]+1
#         manual1.num = np.delete(manual1.num, indexes)
#         manual1.label_store = np.delete(manual1.label_store, indexes)
#         manual1.sample = np.delete(manual1.sample, indexes)*2-1
    
#     ############# AUTOMATIC ANNOTATIONS #############
#     # First algorithm & filter _out_ repeated T fiducials (some registries mark T and T prime)
#     automatic0 = wfdb.rdann(dataDir + fname, 'pu0', return_label_elements=['label_store', 'symbol'], summarize_labels=None)
#     indexes = np.where(np.diff(automatic0.label_store) == 0)[0]+1
#     automatic0.num = np.delete(automatic0.num, indexes)
#     automatic0.label_store = np.delete(automatic0.label_store, indexes)
#     automatic0.sample = np.delete(automatic0.sample, indexes)*2-1
    
#     # Second algorithm & filter _out_ repeated T fiducials (some registries mark T and T prime)
#     automatic1 = wfdb.rdann(dataDir + fname, 'pu1', return_label_elements=['label_store', 'symbol'], summarize_labels=None)
#     indexes = np.where(np.diff(automatic1.label_store) == 0)[0]+1
#     automatic1.num = np.delete(automatic1.num, indexes)
#     automatic1.label_store = np.delete(automatic1.label_store, indexes)
#     automatic1.sample = np.delete(automatic1.sample, indexes)*2-1
    
#     ############# RETRIEVE BINARY MASKS #############
#     maskP_automatic0   = np.zeros((maxSize,),dtype='int8')
#     maskQRS_automatic0 = np.zeros((maxSize,),dtype='int8')
#     maskT_automatic0   = np.zeros((maxSize,),dtype='int8')

#     maskP_automatic1   = np.zeros((maxSize,),dtype='int8')
#     maskQRS_automatic1 = np.zeros((maxSize,),dtype='int8')
#     maskT_automatic1   = np.zeros((maxSize,),dtype='int8')

#     maskP_manual0      = np.zeros((maxSize,),dtype='int8')
#     maskQRS_manual0    = np.zeros((maxSize,),dtype='int8')
#     maskT_manual0      = np.zeros((maxSize,),dtype='int8')

#     maskP_manual1      = np.zeros((maxSize,),dtype='int8')
#     maskQRS_manual1    = np.zeros((maxSize,),dtype='int8')
#     maskT_manual1      = np.zeros((maxSize,),dtype='int8')

#     # Automatic 0
#     for i in range(automatic0.sample[np.where(automatic0.label_store == 24)[0]].size):
#         maskP_automatic0[(automatic0.sample[np.where(automatic0.label_store == 24)[0]-1])[i]:(automatic0.sample[np.where(automatic0.label_store == 24)[0]+1])[i]] = True

#     for i in range(automatic0.sample[np.where(automatic0.label_store == 1)[0]].size):
#         maskQRS_automatic0[(automatic0.sample[np.where(automatic0.label_store == 1)[0]-1])[i]:(automatic0.sample[np.where(automatic0.label_store == 1)[0]+1])[i]] = True

#     for i in range(automatic0.sample[np.where(automatic0.label_store == 27)[0]].size):
#         maskT_automatic0[(automatic0.sample[np.where(automatic0.label_store == 27)[0]-1])[i]:(automatic0.sample[np.where(automatic0.label_store == 27)[0]+1])[i]] = True

#     # Automatic 1
#     for i in range(automatic1.sample[np.where(automatic1.label_store == 24)[0]].size):
#         maskP_automatic1[(automatic1.sample[np.where(automatic1.label_store == 24)[0]-1])[i]:(automatic1.sample[np.where(automatic1.label_store == 24)[0]+1])[i]] = True

#     for i in range(automatic1.sample[np.where(automatic1.label_store == 1)[0]].size):
#         maskQRS_automatic1[(automatic1.sample[np.where(automatic1.label_store == 1)[0]-1])[i]:(automatic1.sample[np.where(automatic1.label_store == 1)[0]+1])[i]] = True

#     for i in range(automatic1.sample[np.where(automatic1.label_store == 27)[0]].size):
#         maskT_automatic1[(automatic1.sample[np.where(automatic1.label_store == 27)[0]-1])[i]:(automatic1.sample[np.where(automatic1.label_store == 27)[0]+1])[i]] = True


#     # Manual 0
#     for i in range(manual0.sample[np.where(manual0.label_store == 24)[0]].size):
#         maskP_manual0[(manual0.sample[np.where(manual0.label_store == 24)[0]-1])[i]:(manual0.sample[np.where(manual0.label_store == 24)[0]+1])[i]] = True

#     for i in range(manual0.sample[np.where(manual0.label_store == 1)[0]].size):
#         maskQRS_manual0[(manual0.sample[np.where(manual0.label_store == 1)[0]-1])[i]:(manual0.sample[np.where(manual0.label_store == 1)[0]+1])[i]] = True

#     for i in range(manual0.sample[np.where(manual0.label_store == 27)[0]].size):
#         maskT_manual0[(manual0.sample[np.where(manual0.label_store == 27)[0]-1])[i]:(manual0.sample[np.where(manual0.label_store == 27)[0]+1])[i]] = True

#     # Manual 1
#     if os.path.exists(dataDir + fname + '.q2c'):
#         for i in range(manual1.sample[np.where(manual1.label_store == 24)[0]].size):
#             maskP_manual1[(manual1.sample[np.where(manual1.label_store == 24)[0]-1])[i]:(manual1.sample[np.where(manual1.label_store == 24)[0]+1])[i]] = True

#         for i in range(manual1.sample[np.where(manual1.label_store == 1)[0]].size):
#             maskQRS_manual1[(manual1.sample[np.where(manual1.label_store == 1)[0]-1])[i]:(manual1.sample[np.where(manual1.label_store == 1)[0]+1])[i]] = True

#         for i in range(manual1.sample[np.where(manual1.label_store == 27)[0]].size):
#             maskT_manual1[(manual1.sample[np.where(manual1.label_store == 27)[0]-1])[i]:(manual1.sample[np.where(manual1.label_store == 27)[0]+1])[i]] = True

    
#     ############# CHOOSE ALGORITHM WITH HIGHEST DICE COEFFICIENT FOR THAT LEAD #############
#     dice_P_00 = np.sum(maskP_manual0 * maskP_automatic0)*2.0 / (np.sum(maskP_manual0) + np.sum(maskP_automatic0))
#     dice_P_01 = np.sum(maskP_manual0 * maskP_automatic1)*2.0 / (np.sum(maskP_manual0) + np.sum(maskP_automatic1))
#     dice_P_10 = np.sum(maskP_manual1 * maskP_automatic0)*2.0 / (np.sum(maskP_manual1) + np.sum(maskP_automatic0))
#     dice_P_11 = np.sum(maskP_manual1 * maskP_automatic1)*2.0 / (np.sum(maskP_manual1) + np.sum(maskP_automatic1))

#     dice_QRS_00 = np.sum(maskQRS_manual0 * maskQRS_automatic0)*2.0 / (np.sum(maskQRS_manual0) + np.sum(maskQRS_automatic0))
#     dice_QRS_01 = np.sum(maskQRS_manual0 * maskQRS_automatic1)*2.0 / (np.sum(maskQRS_manual0) + np.sum(maskQRS_automatic1))
#     dice_QRS_10 = np.sum(maskQRS_manual1 * maskQRS_automatic0)*2.0 / (np.sum(maskQRS_manual1) + np.sum(maskQRS_automatic0))
#     dice_QRS_11 = np.sum(maskQRS_manual1 * maskQRS_automatic1)*2.0 / (np.sum(maskQRS_manual1) + np.sum(maskQRS_automatic1))

#     dice_T_00 = np.sum(maskT_manual0 * maskT_automatic0)*2.0 / (np.sum(maskT_manual0) + np.sum(maskT_automatic0))
#     dice_T_01 = np.sum(maskT_manual0 * maskT_automatic1)*2.0 / (np.sum(maskT_manual0) + np.sum(maskT_automatic1))
#     dice_T_10 = np.sum(maskT_manual1 * maskT_automatic0)*2.0 / (np.sum(maskT_manual1) + np.sum(maskT_automatic0))
#     dice_T_11 = np.sum(maskT_manual1 * maskT_automatic1)*2.0 / (np.sum(maskT_manual1) + np.sum(maskT_automatic1))

#     dice_0_P   = (dice_P_00 + dice_P_10)/2
#     dice_0_QRS = (dice_QRS_00 + dice_QRS_10)/2
#     dice_0_T   = (dice_T_00 + dice_T_10)/2

#     dice_1_P   = (dice_P_01 + dice_P_11)/2
#     dice_1_QRS = (dice_QRS_01 + dice_QRS_11)/2
#     dice_1_T   = (dice_T_01 + dice_T_11)/2

#     dice_0 = dice_0_P+dice_0_QRS+dice_0_T
#     dice_1 = dice_1_P+dice_1_QRS+dice_1_T

#     ############# STORE RESULTS FOR AUTOMATIC SEGMENTATION #############
#     # Decide between the two automatic annotations for each wave
#     # P wave
#     if dice_0_P > dice_1_P:
#         # STORE MASKS
#         annotation = automatic0

#         Pwave_automatic[fname + '_0']   = maskP_automatic0
#         Pwave_automatic[fname + '_1']   = maskP_automatic0
#     elif dice_0_P < dice_1_P:
#         # STORE MASKS
#         annotation = automatic1

#         Pwave_automatic[fname + '_0']   = maskP_automatic1
#         Pwave_automatic[fname + '_1']   = maskP_automatic1
#     else:
#         if dice_0 >= dice_1:
#             # STORE MASKS
#             annotation = automatic0

#             Pwave_automatic[fname + '_0']   = maskP_automatic0
#             Pwave_automatic[fname + '_1']   = maskP_automatic0
#         else:
#             # STORE MASKS
#             annotation = automatic1

#             Pwave_automatic[fname + '_0']   = maskP_automatic1
#             Pwave_automatic[fname + '_1']   = maskP_automatic1

#     # P fiducials
#     Pon_automatic[fname + '_0']     = annotation.sample[np.where(annotation.label_store == 24)[0]-1]
#     Pon_automatic[fname + '_1']     = annotation.sample[np.where(annotation.label_store == 24)[0]-1]
#     Ppeak_automatic[fname + '_0']   = annotation.sample[np.where(annotation.label_store == 24)[0]]
#     Ppeak_automatic[fname + '_1']   = annotation.sample[np.where(annotation.label_store == 24)[0]]
#     Poff_automatic[fname + '_0']    = annotation.sample[np.where(annotation.label_store == 24)[0]+1]
#     Poff_automatic[fname + '_1']    = annotation.sample[np.where(annotation.label_store == 24)[0]+1]

#     # QRS wave
#     if dice_0_QRS > dice_1_QRS:
#         # STORE MASKS
#         annotation = automatic0

#         QRSwave_automatic[fname + '_0']   = maskQRS_automatic0
#         QRSwave_automatic[fname + '_1']   = maskQRS_automatic0
#     elif dice_0_QRS < dice_1_QRS:
#         # STORE MASKS
#         annotation = automatic1

#         QRSwave_automatic[fname + '_0']   = maskQRS_automatic1
#         QRSwave_automatic[fname + '_1']   = maskQRS_automatic1
#     else:
#         if dice_0 >= dice_1:
#             # STORE MASKS
#             annotation = automatic0

#             QRSwave_automatic[fname + '_0']   = maskQRS_automatic0
#             QRSwave_automatic[fname + '_1']   = maskQRS_automatic0
#         else:
#             # STORE MASKS
#             annotation = automatic1

#             QRSwave_automatic[fname + '_0']   = maskQRS_automatic1
#             QRSwave_automatic[fname + '_1']   = maskQRS_automatic1

#     # QRS fiducials
#     QRSon_automatic[fname + '_0']     = annotation.sample[np.where(annotation.label_store == 1)[0]-1]
#     QRSon_automatic[fname + '_1']     = annotation.sample[np.where(annotation.label_store == 1)[0]-1]
#     QRSpeak_automatic[fname + '_0']   = annotation.sample[np.where(annotation.label_store == 1)[0]]
#     QRSpeak_automatic[fname + '_1']   = annotation.sample[np.where(annotation.label_store == 1)[0]]
#     QRSoff_automatic[fname + '_0']    = annotation.sample[np.where(annotation.label_store == 1)[0]+1]
#     QRSoff_automatic[fname + '_1']    = annotation.sample[np.where(annotation.label_store == 1)[0]+1]

#     # T wave
#     if dice_0_T > dice_1_T:
#         # STORE MASKS
#         annotation = automatic0

#         Twave_automatic[fname + '_0']   = maskT_automatic0
#         Twave_automatic[fname + '_1']   = maskT_automatic0
#     elif dice_0_T < dice_1_T:
#         # STORE MASKS
#         annotation = automatic1

#         Twave_automatic[fname + '_0']   = maskT_automatic1
#         Twave_automatic[fname + '_1']   = maskT_automatic1
#     else:
#         if dice_0 >= dice_1:
#             # STORE MASKS
#             annotation = automatic0

#             Twave_automatic[fname + '_0']   = maskT_automatic0
#             Twave_automatic[fname + '_1']   = maskT_automatic0
#         else:
#             # STORE MASKS
#             annotation = automatic1

#             Twave_automatic[fname + '_0']   = maskT_automatic1
#             Twave_automatic[fname + '_1']   = maskT_automatic1

#     # T fiducials
#     Ton_automatic[fname + '_0']     = annotation.sample[np.where(annotation.label_store == 27)[0]-1]
#     Ton_automatic[fname + '_1']     = annotation.sample[np.where(annotation.label_store == 27)[0]-1]
#     Tpeak_automatic[fname + '_0']   = annotation.sample[np.where(annotation.label_store == 27)[0]]
#     Tpeak_automatic[fname + '_1']   = annotation.sample[np.where(annotation.label_store == 27)[0]]
#     Toff_automatic[fname + '_0']    = annotation.sample[np.where(annotation.label_store == 27)[0]+1]
#     Toff_automatic[fname + '_1']    = annotation.sample[np.where(annotation.label_store == 27)[0]+1]

#     ############# STORE RESULTS FOR MANUAL SEGMENTATION #############
#     Pwave_manual0[fname + '_0'] = maskP_manual0
#     Pwave_manual0[fname + '_1'] = maskP_manual0
#     QRSwave_manual0[fname + '_0'] = maskQRS_manual0
#     QRSwave_manual0[fname + '_1'] = maskQRS_manual0
#     Twave_manual0[fname + '_0'] = maskT_manual0
#     Twave_manual0[fname + '_1'] = maskT_manual0
    
#     Pon_manual0[fname + '_0']     = manual0.sample[np.where(manual0.label_store == 24)[0]-1]
#     Pon_manual0[fname + '_1']     = manual0.sample[np.where(manual0.label_store == 24)[0]-1]
#     Ppeak_manual0[fname + '_0']   = manual0.sample[np.where(manual0.label_store == 24)[0]]
#     Ppeak_manual0[fname + '_1']   = manual0.sample[np.where(manual0.label_store == 24)[0]]
#     Poff_manual0[fname + '_0']    = manual0.sample[np.where(manual0.label_store == 24)[0]+1]
#     Poff_manual0[fname + '_1']    = manual0.sample[np.where(manual0.label_store == 24)[0]+1]

#     # QRS wave
#     QRSon_manual0[fname + '_0']   = manual0.sample[np.where(manual0.label_store == 1)[0]-1]
#     QRSon_manual0[fname + '_1']   = manual0.sample[np.where(manual0.label_store == 1)[0]-1]
#     QRSpeak_manual0[fname + '_0'] = manual0.sample[np.where(manual0.label_store == 1)[0]]
#     QRSpeak_manual0[fname + '_1'] = manual0.sample[np.where(manual0.label_store == 1)[0]]
#     QRSoff_manual0[fname + '_0']  = manual0.sample[np.where(manual0.label_store == 1)[0]+1]
#     QRSoff_manual0[fname + '_1']  = manual0.sample[np.where(manual0.label_store == 1)[0]+1]

#     # T wave
#     Ton_manual0[fname + '_0']     = manual0.sample[np.where(manual0.label_store == 27)[0]-1]
#     Ton_manual0[fname + '_1']     = manual0.sample[np.where(manual0.label_store == 27)[0]-1]
#     Tpeak_manual0[fname + '_0']   = manual0.sample[np.where(manual0.label_store == 27)[0]]
#     Tpeak_manual0[fname + '_1']   = manual0.sample[np.where(manual0.label_store == 27)[0]]
#     Toff_manual0[fname + '_0']    = manual0.sample[np.where(manual0.label_store == 27)[0]+1]
#     Toff_manual0[fname + '_1']    = manual0.sample[np.where(manual0.label_store == 27)[0]+1]


#     Pwave_manual1[fname + '_0'] = maskP_manual1
#     Pwave_manual1[fname + '_1'] = maskP_manual1
#     QRSwave_manual1[fname + '_0'] = maskQRS_manual1
#     QRSwave_manual1[fname + '_1'] = maskQRS_manual1
#     Twave_manual1[fname + '_0'] = maskT_manual1
#     Twave_manual1[fname + '_1'] = maskT_manual1

#     # Manual 1
#     if os.path.exists(dataDir + fname + '.q2c'):

#         Pon_manual1[fname + '_0']     = manual1.sample[np.where(manual1.label_store == 24)[0]-1]
#         Pon_manual1[fname + '_1']     = manual1.sample[np.where(manual1.label_store == 24)[0]-1]
#         Ppeak_manual1[fname + '_0']   = manual1.sample[np.where(manual1.label_store == 24)[0]]
#         Ppeak_manual1[fname + '_1']   = manual1.sample[np.where(manual1.label_store == 24)[0]]
#         Poff_manual1[fname + '_0']    = manual1.sample[np.where(manual1.label_store == 24)[0]+1]
#         Poff_manual1[fname + '_1']    = manual1.sample[np.where(manual1.label_store == 24)[0]+1]

#         # QRS wave
#         QRSon_manual1[fname + '_0']   = manual1.sample[np.where(manual1.label_store == 1)[0]-1]
#         QRSon_manual1[fname + '_1']   = manual1.sample[np.where(manual1.label_store == 1)[0]-1]
#         QRSpeak_manual1[fname + '_0'] = manual1.sample[np.where(manual1.label_store == 1)[0]]
#         QRSpeak_manual1[fname + '_1'] = manual1.sample[np.where(manual1.label_store == 1)[0]]
#         QRSoff_manual1[fname + '_0']  = manual1.sample[np.where(manual1.label_store == 1)[0]+1]
#         QRSoff_manual1[fname + '_1']  = manual1.sample[np.where(manual1.label_store == 1)[0]+1]

#         # T wave
#         Ton_manual1[fname + '_0']     = manual1.sample[np.where(manual1.label_store == 27)[0]-1]
#         Ton_manual1[fname + '_1']     = manual1.sample[np.where(manual1.label_store == 27)[0]-1]
#         Tpeak_manual1[fname + '_0']   = manual1.sample[np.where(manual1.label_store == 27)[0]]
#         Tpeak_manual1[fname + '_1']   = manual1.sample[np.where(manual1.label_store == 27)[0]]
#         Toff_manual1[fname + '_0']    = manual1.sample[np.where(manual1.label_store == 27)[0]+1]
#         Toff_manual1[fname + '_1']    = manual1.sample[np.where(manual1.label_store == 27)[0]+1]
#     else:
#         Pon_manual1[fname + '_0']     = np.asarray([])
#         Pon_manual1[fname + '_1']     = np.asarray([])
#         Ppeak_manual1[fname + '_0']   = np.asarray([])
#         Ppeak_manual1[fname + '_1']   = np.asarray([])
#         Poff_manual1[fname + '_0']    = np.asarray([])
#         Poff_manual1[fname + '_1']    = np.asarray([])

#         # QRS wave
#         QRSon_manual1[fname + '_0']   = np.asarray([])
#         QRSon_manual1[fname + '_1']   = np.asarray([])
#         QRSpeak_manual1[fname + '_0'] = np.asarray([])
#         QRSpeak_manual1[fname + '_1'] = np.asarray([])
#         QRSoff_manual1[fname + '_0']  = np.asarray([])
#         QRSoff_manual1[fname + '_1']  = np.asarray([])

#         # T wave
#         Ton_manual1[fname + '_0']     = np.asarray([])
#         Ton_manual1[fname + '_1']     = np.asarray([])
#         Tpeak_manual1[fname + '_0']   = np.asarray([])
#         Tpeak_manual1[fname + '_1']   = np.asarray([])
#         Toff_manual1[fname + '_0']    = np.asarray([])
#         Toff_manual1[fname + '_1']    = np.asarray([])
        

# Pwave_automatic.to_csv(os.path.join(dataDir,'automatic','Pwave.csv'))
# QRSwave_automatic.to_csv(os.path.join(dataDir,'automatic','QRSwave.csv'))
# Twave_automatic.to_csv(os.path.join(dataDir,'automatic','Twave.csv'))


# #### SAVE DATABASE ####
# save_fiducials(Pon_automatic, os.path.join(dataDir,'automatic','Pon.csv'))
# save_fiducials(Ppeak_automatic, os.path.join(dataDir,'automatic','Ppeak.csv'))
# save_fiducials(Poff_automatic, os.path.join(dataDir,'automatic','Poff.csv'))
# save_fiducials(QRSon_automatic, os.path.join(dataDir,'automatic','QRSon.csv'))
# save_fiducials(QRSpeak_automatic, os.path.join(dataDir,'automatic','QRSpeak.csv'))
# save_fiducials(QRSoff_automatic, os.path.join(dataDir,'automatic','QRSoff.csv'))
# save_fiducials(Ton_automatic, os.path.join(dataDir,'automatic','Ton.csv'))
# save_fiducials(Tpeak_automatic, os.path.join(dataDir,'automatic','Tpeak.csv'))
# save_fiducials(Toff_automatic, os.path.join(dataDir,'automatic','Toff.csv'))


# # for filename in records2:
# #     fname = os.path.splitext(os.path.split(filename)[1])[0] #Obtenemos el nombre del archivo sin extensión
# #     # Read record
# #     rec = wfdb.rdrecord(dataDir2 + fname) #Leemos el archivo
# #     print(fname)
# #     nombres = ['i', 'ii', 'iii', 'avr', 'avl', 'avf', 'v1', 'v2', 'v3', 'v4', 'v5', 'v6']
   

# #     dataset2[fname + '_0']               = (rec.adc()[-1,0] - rec.baseline[0])/np.asarray(rec.adc_gain[0])*np.ones((maxSize2,)) #Crea un array con el último valor de cada archivo por si hubiese alguno de menor longitud
# #     dataset2[fname + '_1']               = (rec.adc()[-1,1] - rec.baseline[1])/np.asarray(rec.adc_gain[1])*np.ones((maxSize2,))
# #     dataset2[fname + '_2']               = (rec.adc()[-1,2] - rec.baseline[2])/np.asarray(rec.adc_gain[2])*np.ones((maxSize2,)) #Crea un array con el último valor de cada archivo por si hubiese alguno de menor longitud
# #     dataset2[fname + '_3']               = (rec.adc()[-1,3] - rec.baseline[3])/np.asarray(rec.adc_gain[3])*np.ones((maxSize2,))
# #     dataset2[fname + '_4']               = (rec.adc()[-1,4] - rec.baseline[4])/np.asarray(rec.adc_gain[4])*np.ones((maxSize2,)) #Crea un array con el último valor de cada archivo por si hubiese alguno de menor longitud
# #     dataset2[fname + '_5']               = (rec.adc()[-1,5] - rec.baseline[5])/np.asarray(rec.adc_gain[5])*np.ones((maxSize2,))
# #     dataset2[fname + '_6']               = (rec.adc()[-1,6] - rec.baseline[6])/np.asarray(rec.adc_gain[6])*np.ones((maxSize2,)) #Crea un array con el último valor de cada archivo por si hubiese alguno de menor longitud
# #     dataset2[fname + '_7']               = (rec.adc()[-1,7] - rec.baseline[7])/np.asarray(rec.adc_gain[7])*np.ones((maxSize2,))
# #     dataset2[fname + '_8']               = (rec.adc()[-1,8] - rec.baseline[8])/np.asarray(rec.adc_gain[8])*np.ones((maxSize2,)) #Crea un array con el último valor de cada archivo por si hubiese alguno de menor longitud
# #     dataset2[fname + '_9']               = (rec.adc()[-1,9] - rec.baseline[9])/np.asarray(rec.adc_gain[9])*np.ones((maxSize2,))
# #     dataset2[fname + '_10']               = (rec.adc()[-1,10] - rec.baseline[10])/np.asarray(rec.adc_gain[10])*np.ones((maxSize2,)) #Crea un array con el último valor de cada archivo por si hubiese alguno de menor longitud
# #     dataset2[fname + '_11']               = (rec.adc()[-1,11] - rec.baseline[11])/np.asarray(rec.adc_gain[11])*np.ones((maxSize2,))
    
# #     dataset2[fname + '_0'][:rec.sig_len] = (rec.adc()[:,0] - rec.baseline[0])/np.asarray(rec.adc_gain[0])
# #     dataset2[fname + '_1'][:rec.sig_len] = (rec.adc()[:,1] - rec.baseline[1])/np.asarray(rec.adc_gain[1]) 
# #     dataset2[fname + '_2'][:rec.sig_len] = (rec.adc()[:,2] - rec.baseline[2])/np.asarray(rec.adc_gain[2])
# #     dataset2[fname + '_3'][:rec.sig_len] = (rec.adc()[:,3] - rec.baseline[3])/np.asarray(rec.adc_gain[3])
# #     dataset2[fname + '_4'][:rec.sig_len] = (rec.adc()[:,4] - rec.baseline[4])/np.asarray(rec.adc_gain[4])
# #     dataset2[fname + '_5'][:rec.sig_len] = (rec.adc()[:,5] - rec.baseline[5])/np.asarray(rec.adc_gain[5]) 
# #     dataset2[fname + '_6'][:rec.sig_len] = (rec.adc()[:,6] - rec.baseline[6])/np.asarray(rec.adc_gain[6])
# #     dataset2[fname + '_7'][:rec.sig_len] = (rec.adc()[:,7] - rec.baseline[7])/np.asarray(rec.adc_gain[7]) 
# #     dataset2[fname + '_8'][:rec.sig_len] = (rec.adc()[:,8] - rec.baseline[8])/np.asarray(rec.adc_gain[8])
# #     dataset2[fname + '_9'][:rec.sig_len] = (rec.adc()[:,9] - rec.baseline[9])/np.asarray(rec.adc_gain[9]) 
# #     dataset2[fname + '_10'][:rec.sig_len] = (rec.adc()[:,10] - rec.baseline[10])/np.asarray(rec.adc_gain[10])
# #     dataset2[fname + '_11'][:rec.sig_len] = (rec.adc()[:,11] - rec.baseline[11])/np.asarray(rec.adc_gain[11]) 
# # print(dataset2)
# # print(len(dataset2))
# # dataset2.to_csv(os.path.join(dataDir2, 'ToCSV', 'Dataset2.csv'))
# # print(len(dataset2))
# # print((rec.adc()[:,0] - rec.baseline[0])/np.asarray(rec.adc_gain[0])) #Salen mal los valores
# # print(rec.baseline[0])
# # print(rec.adc_gain[10]) 


# # QRSon_manual     = dict()
# # QRSpeak_manual   = dict()
# # QRSoff_manual    = dict()

# # Pon_manual       = dict()
# # Ppeak_manual     = dict()
# # Poff_manual      = dict()

# # Ton_manual       = dict()
# # Tpeak_manual     = dict()
# # Toff_manual      = dict()


# # Pwave_manual     = pandas.DataFrame()
# # QRSwave_manual   = pandas.DataFrame()
# # Twave_manual    = pandas.DataFrame()
# # contador=0
# # for filename in records2:
# #     print(filename)
# #     # print(contador)
# #     contador+=1
# #     # if contador != 179:
# #     fname = os.path.splitext(os.path.split(filename)[1])[0]
# #     print(fname)
# #     # print(fname)
# #     ############# MANUAL ANNOTATIONS #############
# #     # First annotator & filter _out_ repeated T fiducials (some registries mark T and T prime)
# #     nombres = ['i', 'ii', 'iii', 'avr', 'avl', 'avf', 'v1', 'v2', 'v3', 'v4', 'v5', 'v6']
# #     manual_n = {} #Las distintas capas
# #     manual_n = [None] * 13
# #     for i, nombre in enumerate(nombres):
# #         if os.path.exists(dataDir2 + fname + f'.{nombre}'):
# #             manual = wfdb.rdann(dataDir2 + fname, f'{nombre}', return_label_elements=['label_store', 'symbol'], summarize_labels=None)
# #             indexes = np.where(np.diff(manual.label_store) == 0)[0]+1 #Las etiquetas son (,N,P,),T pero en número
# #             #Indexes es por si hay algún 0 no tenerlo en cuenta
# #             manual.num = np.delete(manual.num, indexes)
# #             # print(manual.label_store)
# #             # print(indexes)
# #             # print(manual.sample)
# #             manual.label_store = np.delete(manual.label_store, indexes)
# #             manual.sample = np.delete(manual.sample, indexes)
# #             # Agregar manual al diccionario
# #             manual_n[i] = manual
    
# #     # print(manual_n[3].label_store)
# #     # print('lalala')
# #     # print(manual_n[3].symbol)
# #     # print(manual_n[3].sample)
# #     ############ RETRIEVE BINARY MASKS #############
# #     maskP_manual = {}
# #     maskQRS_manual = {}
# #     maskT_manual = {}
# #     for i in range(12):
# #         maskP_manual[i]     = np.zeros((maxSize2,),dtype='int8')
# #         maskQRS_manual[i]    = np.zeros((maxSize2,),dtype='int8')
# #         maskT_manual[i]      = np.zeros((maxSize2,),dtype='int8')
        
    
# #     # Creamos las máscaras que incican las diferentes ondas con 1s y 0s
# #     for j in range(len(manual_n) - 1):
# #         for i in range(manual_n[j].sample[np.where(manual_n[j].label_store == 24)[0]].size):
# #             maskP_manual_a = maskP_manual[j]
# #             maskP_manual_a[(manual_n[j].sample[np.where(manual_n[j].label_store == 24)[0]-1])[i]:(manual_n[j].sample[np.where(manual_n[j].label_store == 24)[0]+1])[i]] = True
# #             maskP_manual[j]=maskP_manual_a
# #         for i in range(manual_n[j].sample[np.where(manual_n[j].label_store == 1)[0]].size):
# #             maskQRS_manual_a = maskQRS_manual[j]
# #             # print(fname)
# #             # if contador >= 177:
# #             #     print(j)
# #             #     print(manual_n[j].sample)
# #             #     print(np.where(manual_n[j].label_store == 1))
# #             #     print(np.where(manual_n[j].label_store == 1)[0])
# #             #     print((manual_n[j].sample[np.where(manual_n[j].label_store == 1)[0]-1]))
# #             #     print((manual_n[j].sample[np.where(manual_n[j].label_store == 1)[0]+1]))
# #             pos = (np.where(manual_n[j].label_store == 1)[0]+1)
# #             if (pos[-1]) < len(manual_n[j].sample):
# #                 maskQRS_manual_a[(manual_n[j].sample[np.where(manual_n[j].label_store == 1)[0]-1])[i]:(manual_n[j].sample[np.where(manual_n[j].label_store == 1)[0]+1])[i]] = True
# #                 maskQRS_manual[j]=maskQRS_manual_a
# #         for i in range(manual_n[j].sample[np.where(manual_n[j].label_store == 27)[0]].size):
# #             maskT_manual_a = maskT_manual[j]
# #             maskT_manual_a[(manual_n[j].sample[np.where(manual_n[j].label_store == 27)[0]-1])[i]:(manual_n[j].sample[np.where(manual_n[j].label_store == 27)[0]+1])[i]] = True
# #             maskT_manual[j] = maskT_manual_a
    
# #     ############# STORE RESULTS FOR MANUAL SEGMENTATION #############
# #     for i in range(len(manual_n) - 1):
# #         Pwave_manual[fname + '_' +  str(i)] = maskP_manual[i]
# #         QRSwave_manual[fname + '_' +  str(i)] = maskQRS_manual[i]
# #         Twave_manual[fname + '_' +  str(i)] = maskT_manual[i]
    
# #     for i in range(len(manual_n) - 1):
# #         Pon_manual[fname + '_' +  str(i)]     = manual.sample[np.where(manual.label_store == 24)[0]-1]
# #         Ppeak_manual[fname + '_' +  str(i)]   = manual.sample[np.where(manual.label_store == 24)[0]] #No entiendo el número 24
# #         Poff_manual[fname + '_' +  str(i)]    = manual.sample[np.where(manual.label_store == 24)[0]+1]

# #     # QRS wave
# #     for i in range(len(manual_n) - 1):
# #         QRSon_manual[fname + '_' +  str(i)]   = manual.sample[np.where(manual.label_store == 1)[0]-1]
# #         QRSpeak_manual[fname + '_' +  str(i)] = manual.sample[np.where(manual.label_store == 1)[0]]
# #         QRSoff_manual[fname + '_' +  str(i)]  = manual.sample[np.where(manual.label_store == 1)[0]+1]

# #     # T wave
# #     for i in range(len(manual_n) - 1):
# #         Ton_manual[fname + '_' +  str(i)]     = manual.sample[np.where(manual.label_store == 27)[0]-1]
# #         Tpeak_manual[fname + '_' +  str(i)]   = manual.sample[np.where(manual.label_store == 27)[0]]
# #         Toff_manual[fname + '_' +  str(i)]    = manual.sample[np.where(manual.label_store == 27)[0]+1]


# # Pwave_manual.to_csv(os.path.join(dataDir2,'ToCSV','Pwave.csv'))
# # QRSwave_manual.to_csv(os.path.join(dataDir2,'ToCSV','QRSwave.csv'))
# # Twave_manual.to_csv(os.path.join(dataDir2,'ToCSV','Twave.csv'))

# # ### SAVE DATABASE ####
# # save_fiducials(Pon_manual, os.path.join(dataDir2,'ToCSV','Pon.csv'))
# # save_fiducials(Ppeak_manual, os.path.join(dataDir2,'ToCSV','Ppeak.csv'))
# # save_fiducials(Poff_manual, os.path.join(dataDir2,'ToCSV','Poff.csv'))
# # save_fiducials(QRSon_manual, os.path.join(dataDir2,'ToCSV','QRSon.csv'))
# # save_fiducials(QRSpeak_manual, os.path.join(dataDir2,'ToCSV','QRSpeak.csv'))
# # save_fiducials(QRSoff_manual, os.path.join(dataDir2,'ToCSV','QRSoff.csv'))
# # save_fiducials(Ton_manual, os.path.join(dataDir2,'ToCSV','Ton.csv'))
# # save_fiducials(Tpeak_manual, os.path.join(dataDir2,'ToCSV','Tpeak.csv'))
# # save_fiducials(Toff_manual, os.path.join(dataDir2,'ToCSV','Toff.csv'))