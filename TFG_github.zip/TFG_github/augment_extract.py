# # NOISE EXTRACT

# # import os
# # import scipy.io
# # import pandas as pd

# # # Función para procesar los archivos .mat y guardarlos en un DataFrame
# # def process_ecg_data(root_folder, num_folders, variable_name):
# #     df = pd.DataFrame()

# #     for i in range(1, num_folders + 1):
# #         print(i)
# #         folder_name = str(i)
# #         mat_file_path = os.path.join(root_folder, folder_name, 'simECGdata_ds.mat')
        
# #         if os.path.exists(mat_file_path):
# #             mat_data = scipy.io.loadmat(mat_file_path)
# #             if variable_name in mat_data:
# #                 ecg_data = mat_data[variable_name]  # Asumiendo que ecg_data es una matriz de múltiples capas
# #                 # for j in range(ecg_data.shape[0]):  # Iterar sobre las capas
# #                 for j in range(12):
# #                     key = f"{folder_name}_{j}"
# #                     df[key] = ecg_data[j].flatten().tolist()  # Asegurarse de que los datos estén en una sola dimensión
# #             else:
# #                 print(f"Variable '{variable_name}' no encontrada en {mat_file_path}")
# #         else:
# #             print(f"Archivo {mat_file_path} no encontrado")

# #     return df


# # # Ruta de la carpeta raíz donde están las carpetas numeradas
# # root_folder = '/mnt/cephfs/home/bio/bcoscull/tests/dataset/bigeminy/'
# # num_folders = 500
# # variable_name = 'multileadNoise_All'  # Reemplaza esto con el nombre de la variable correcta en tus archivos .mat
# # output_folder = "/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise"

# # # Procesar los datos
# # for j in range(9):

# #     mat_file_path = os.path.join(root_folder, f"noise_{j+1}")

# #     df = process_ecg_data(mat_file_path, num_folders, variable_name)

# #     # Guardar el archivo CSV en la carpeta de salida
# #     output_file = os.path.join(output_folder, f"noise_{j+1}.csv")
# #     df.to_csv(output_file)









# # # #  DATA-AUG EXTRACT
# import os
# import scipy.io
# import pandas as pd
# import random
# from utils.data_structures import save_fiducials
# import numpy

# # # Función para procesar los archivos .mat y guardarlos en un DataFrame
# def process_ecg_data(num_folders, variable_name, categories,root_folder_base):
#     data_dict = {}
#     for category in categories:
#         print(category)
#         root_folder = os.path.join(root_folder_base, category)
#         noise_folders = ["noise_10"]
#         cont2 = 1
#         for i in range(1, num_folders + 1): 
#             print(f"Procesando paciente {i} en {root_folder}")
#             folder_name = str(i)
#             cont = 0
#             print(cont2)
#             for noise in noise_folders:
#                 mat_file_path = os.path.join(root_folder, noise, folder_name, 'simECGdata_ds.mat')
            
#                 if os.path.exists(mat_file_path):
#                     mat_data = scipy.io.loadmat(mat_file_path)
#                     if variable_name in mat_data:
#                         ecg_data = mat_data[variable_name]  # Asumiendo que ecg_data es una matriz de múltiples capas
#                         for j in range(12):
#                             key = f"{folder_name}_{j}_{cont}_{category}"
                            
#                             data_dict[key] = ecg_data[j].flatten().tolist()  # Asegurarse de que los datos estén en una sola dimensión
                        
#                             cont2 = cont2 +1          
#                     else:
#                         print(f"Variable '{variable_name}' no encontrada en {mat_file_path}")
#                 else:
#                     print(f"Archivo {mat_file_path} no encontrado")
#                 cont = cont + 1

#     # Convertir el diccionario a un DataFrame de pandas
#     df = pd.DataFrame(data_dict)

#     return df

# # Ruta de la carpeta raíz donde están las carpetas numeradas
# root_folder_base = '/mnt/cephfs/home/bio/bcoscull/tests/dataset/'
# categories = ['sr', 'sr_ecto', 'aur_tach']

# num_folders = 300
# variable_name = 'multileadECG'  # Reemplaza esto con el nombre de la variable correcta en tus archivos .mat
# output_file = "/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/combined_noise_data.csv"

# # Crear un DataFrame vacío para acumular todos los datos
# combined_df = pd.DataFrame()

# # Procesar los datos

# df = process_ecg_data(num_folders, variable_name,categories,root_folder_base)


# # Guardar el archivo CSV combinado
# df.to_csv(output_file)



# # Fiducials extract
# folds = ['sr', 'sr_ecto', 'fib_aur_ecto', 'aur_tach']
# # folds = ['sr','aur_tach']
# categories = ['Pon', 'Poff', 'QRSon', 'QRSoff', 'Ton', 'Toff']

# for categorie in categories:   
#     print(categorie)
#     wave = dict()
#     for fold in folds:
#         cont = 1 
#         print(fold)
#         mat_file_path = f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/augment_data/{fold}_waves/{categorie}.mat'
#         # Cargar el archivo .mat
#         mat_data = scipy.io.loadmat(mat_file_path)
#         data = mat_data[f'{categorie}_values']
#         print(data)
#         # Iterar sobre las filas del archivo .mat
#         # for i in range(data.shape[0]):
#         for i in range(400):
#             for j in range(data.shape[1]):
#                 # Crear el nombre de la variable
#                 variable_name = f'{cont}_{j}_{fold}'
               
#                 # Obtener los datos del ECG
#                 wave[variable_name] = data[i][j]
#             cont = cont + 1
#     save_fiducials(wave, os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/combined_noise_data',f'{categorie}.csv'))



# # # Fiducials waves extract
# folds = ['sr', 'sr_ecto', 'fib_aur_ecto', 'aur_tach']
# categories = ['P', 'P', 'QRS', 'QRS', 'T', 'T']

# for k in range(0, len(categories), 2):
#     categorie1 = categories[k]
#     categorie2 = categories[k+1]
    
#     print(categorie1)
#     print(categorie2)
#     cont = 1 
#     wave = dict()
#     for fold in folds:
#         cont = 1 
#         print(fold)
#         mat_file_path1 = f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/augment_data/{fold}_waves/{categorie1}on.mat'
#         mat_file_path2 = f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/augment_data/{fold}_waves/{categorie1}off.mat'
#         # Cargar el archivo .mat
#         mat_data1 = scipy.io.loadmat(mat_file_path1)
#         mat_data2 = scipy.io.loadmat(mat_file_path2)

#         data1 = mat_data1[f'{categorie1}on_values']
#         data2 = mat_data2[f'{categorie2}off_values']
        
#         # Iterar sobre las filas del archivo .mat
#         # for i in range(data.shape[0]):
#         for i in range(400):
#             for j in range(data1.shape[1]):
#                 # Crear el nombre de la variable
#                 variable_name = f'{cont}_{j}_{fold}'
               
#                 inicios = data1[i][j]
#                 finales = data2[i][j]

#                 inicios = inicios[0]
#                 finales = finales[0]
                
#                  # Inicializar la lista con ceros
#                 mascara = [0] * 7500
                
#                 # Verificar que inicios y finales tengan la misma longitud
#                 if len(inicios) != len(finales):
#                     inicios, finales = eliminar_fuera_de_rango(inicios, finales)
#                 # Crear la máscara binaria
#                 for inicio, final in zip(inicios, finales):
#                     # print(inicio)
#                     # print(final)
#                     if inicio < 0 or final >= 7500 or inicio > final:
                       
#                         inicios, finales = eliminar_fuera_de_rango(inicios, finales)
#                     for l in range(inicio, final + 1):
#                         mascara[l] = 1

#                 # Obtener los datos del ECG
#                 wave[variable_name] = numpy.array(mascara) 
#             cont = cont + 1
#     df = pd.DataFrame(wave)
#     output_file = os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/combined_noise_data',f'{categorie1}wave.csv')
#     df.to_csv(output_file)
   
#     def eliminar_fuera_de_rango(inicios, finales, rango=150):
#         nuevos_inicios = []
#         nuevos_finales = []

#         for i, inicio in enumerate(inicios):
#             en_rango = False
#             for final in finales:
#                 final = int(final)
#                 inicio = int(inicio)
#                 if final - inicio <= rango and final - inicio >0:
#                     nuevos_inicios.append(inicio)
#                     nuevos_finales.append(final)
#                     break
        
#         return nuevos_inicios, nuevos_finales


# Extraer los .mat a escritorio local

# from scipy.io import loadmat, savemat

# # Especifica la ruta completa del archivo en el servidor remoto
# for i in range(1,501):
#     ruta_remota = f'/mnt/cephfs/home/bio/bcoscull/tests/dataset/fib_aur_ecto/noise_10/{i}/simECGdata_ds.mat'
#     ruta_temporal = f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/augment_data/sr_ecto/simECGdata_ds_{i}.mat'  # Ruta temporal en el servidor

#     # Carga el archivo .mat
#     data = loadmat(ruta_remota)
#     print(i)

#     # Guarda el archivo .mat en una ubicación temporal en el servidor remoto (si es necesario)
#     savemat(ruta_temporal, data)

# # .mat waves a CSV



# Añadir ruido al dataset sintético
from pandas import read_csv
from numpy import asarray
from os.path import join
import numpy as np
import os
import random
from utils.data_structures import format_string

dataset2            = read_csv(join("/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/combined_noise_data", 'Dataset.csv'), index_col=0)

dataset2             = dataset2.sort_index(axis=1)
labels2             = asarray(list(dataset2))
labels2_sorted = np.sort(labels2)

print(labels2_sorted)

noise1 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{1}.csv', index_col=0)
print(1)
noise2 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{2}.csv', index_col=0)
print(2)
noise3 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{3}.csv', index_col=0)
print(3)
noise4 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{4}.csv', index_col=0)
print(4)
noise5 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{5}.csv', index_col=0)
print(5)
noise6 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{6}.csv', index_col=0)
print(6)
noise7 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{7}.csv', index_col=0)
print(7)
noise8 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{8}.csv', index_col=0)
print(8)
noise9 = read_csv(f'/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/noise/noise_{9}.csv', index_col=0)
print(9)
noises = [noise1, noise2, noise3, noise4, noise5, noise6, noise7, noise8, noise9]

cont = 0
for key in labels2:
    cont = cont+1
    for i in random.sample(range(1, 9), 1):
        noise = random.choice(noises)
        key2 = format_string(key)
        dataset2[key] = dataset2[key] + noise[key2]
        print(key)
dataset2.to_csv(os.path.join('/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/combined_noise_data', f"Dataset_noise.csv"))
print(cont)