from pandas import read_csv
from os.path import join
import matplotlib.pyplot as plt
import wfdb
import os
import numpy as np

def get_minmax(fname,a):
    # a:  1-> LOBACHEVSKY  2-> QT
    #fname='sele0166_0'
    ################ LOBACHEVSKY ################
    if a == 1:
        marcaDir="lobachevsky-university-electrocardiography-database-1.0.1/data/"
        fname_s = fname.split('.')[0]
        m = fname.split('.')[1]
        manual = wfdb.rdann(marcaDir + fname_s, m, return_label_elements=['label_store', 'symbol'], summarize_labels=None)

        # Vector de marcas (supongamos que las marcas están en segundos)
        marcas = manual.sample

        limite_inferior = min(marcas)-100
        limite_superior = max(marcas)+100
    return limite_inferior,limite_superior

def axis_acot(fname):
    cont=0
    minmax = {}
    marcaDir = "qt-database-1.0.0/qt-database-1.0.0/"

    manual = wfdb.rdann(marcaDir + fname, 'q1c', return_label_elements=['label_store', 'symbol'], summarize_labels=None)
    marcas=manual.sample*2-1
    # Calcular la media y desviación estándar de las marcas
    media_marcas = np.mean(marcas)
    desviacion_estandar_marcas = np.std(marcas)

    # Definir un umbral (por ejemplo, 2 veces la desviación estándar)
    umbral = 2 * desviacion_estandar_marcas
    # print('umbral')
    # print(umbral)
    # print(media_marcas)
    # Encontrar valores atípicos
    for marca in marcas:
        if abs(marca - media_marcas) < umbral:
            minmax[cont] = marca
            cont += 1
    # print('minmax')
    # print(minmax)
    limite_inferior = min(minmax.values())
    limite_superior = max(minmax.values())
    # print(min)
    # print(max)
    return limite_inferior,limite_superior

def axis_acot_dataset(fname):
    cont=0
    minmax = {}
    marcaDir = "qt-database-1.0.0/qt-database-1.0.0/"

    manual = wfdb.rdann(marcaDir + fname, 'q1c', return_label_elements=['label_store', 'symbol'], summarize_labels=None)
    marcas=manual.sample
    # Calcular la media y desviación estándar de las marcas
    media_marcas = np.mean(marcas)
    desviacion_estandar_marcas = np.std(marcas)

    # Definir un umbral (por ejemplo, 2 veces la desviación estándar)
    umbral = 2 * desviacion_estandar_marcas
    # print('umbral')
    # print(umbral)
    # print(media_marcas)
    # Encontrar valores atípicos
    for marca in marcas:
        if abs(marca - media_marcas) < umbral:
            minmax[cont] = marca
            cont += 1
    # print('minmax')
    # print(minmax)
    limite_inferior = min(minmax.values())
    limite_superior = max(minmax.values())
    # print(min)
    # print(max)
    return limite_inferior,limite_superior