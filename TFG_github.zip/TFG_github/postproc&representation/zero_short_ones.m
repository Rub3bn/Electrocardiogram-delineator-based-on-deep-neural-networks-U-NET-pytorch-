function [signal, wave_s, wave_e] = zero_short_ones(signal, min_length, wave_s, wave_e)
    sig_size = size(signal);
    for i=2:sig_size(2)
        signali = signal(:,i);
        wave_s_i = str2num(cell2mat(wave_s(i-1,:)));
        wave_e_i = str2num(cell2mat(wave_e(i-1,:)));

        % Recorrer todas las secuencias de 1s
        for k = 2:length(wave_s_i)
            len = wave_e_i(k) - wave_s_i(k) + 1;
            if len < min_length
                signali(wave_s_i(k)+1:wave_e_i(k)+1) = 0;
                wave_s_i(k) = 0;
                wave_e_i(k) = 0;
            end
        end
        if wave_s_i ~= 0
            wave_s_i = wave_s_i(wave_s_i ~= 0);
        end
        if wave_e_i ~= 0         
            wave_e_i = wave_e_i(wave_e_i ~= 0);
        end
        

        wave_s(i-1,:) = mat2cell(num2str(wave_s_i),1);
        wave_e(i-1,:) = mat2cell(num2str(wave_e_i),1);

        signal(:,i) = signali;
    end
end
