function plot_multi(dataset, dataset_ind, Pwave, QRSwave, Twave, rPwave, rQRSwave, rTwave, Pwave_ind, QRSwave_ind, Twave_ind, rPwave_ind, rQRSwave_ind, rTwave_ind,x_inf,x_sup)
    
    for j = 1:12:length(rPwave_ind)-1
        for i = 1:3
            fig1 = figure(1);
            fig1.Position(1:2) = [1 50];
            fig1.Position(3:4) = [1550 400];
           
            fig2 = figure(2);
            fig2.Position(1:2) = [1 450];
            fig2.Position(3:4) = [1550 400];

            r_ind=rPwave_ind((j+i));
            posicion = find(strcmp(rPwave_ind, r_ind));
            rPwave_i=rPwave(:,posicion);
            rQRSwave_i=rQRSwave(:,posicion);
            rTwave_i=rTwave(:,posicion);
    
            posicion = find(strcmp(Pwave_ind, r_ind));
            Pwave_i=Pwave(:,posicion);
            QRSwave_i=QRSwave(:,posicion);
            Twave_i=Twave(:,posicion);
            
            posicion = find(strcmp(dataset_ind, r_ind));
            dataset_i = dataset(:,posicion);
            
            max_d = max(dataset_i);
            min_d = min(dataset_i);

            figure(1)
            subplot(3,1,i)
            

            plot(dataset_i)
            hold on
            posiciones_unos = find(Pwave_i == 1);
            posiciones_ceros = find(Pwave_i == 0);
            Pwave_i(posiciones_unos) = max_d;
            Pwave_i(posiciones_ceros) = min_d;
            area(Pwave_i, 'FaceColor','r','basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
            posiciones_unos = find(QRSwave_i == 1);
            posiciones_ceros = find(QRSwave_i == 0);
            QRSwave_i(posiciones_unos) = max_d;
            QRSwave_i(posiciones_ceros) = min_d;
            area(QRSwave_i, 'FaceColor','g','basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
            posiciones_unos = find(Twave_i == 1);
            posiciones_ceros = find(Twave_i == 0);
            Twave_i(posiciones_unos) = max_d;
            Twave_i(posiciones_ceros) = min_d;
            area(Twave_i, 'FaceColor','y', 'basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
            hold off
    
            title(r_ind)
            xlim([x_inf, x_sup]); ylim([min_d, max_d])

            figure(2)
            subplot(3,1,i)
            

            plot(dataset_i)
            hold on
            posiciones_unos = find(rPwave_i == 1);
            posiciones_ceros = find(rPwave_i == 0);
            rPwave_i(posiciones_unos) = max_d;
            rPwave_i(posiciones_ceros) = min_d;
            area(rPwave_i, 'FaceColor','r','basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
            posiciones_unos = find(rQRSwave_i == 1);
            posiciones_ceros = find(rQRSwave_i == 0);
            rQRSwave_i(posiciones_unos) = max_d;
            rQRSwave_i(posiciones_ceros) = min_d;
            area(rQRSwave_i, 'FaceColor','g','basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
            posiciones_unos = find(rTwave_i == 1);
            posiciones_ceros = find(rTwave_i == 0);
            rTwave_i(posiciones_unos) = max_d;
            rTwave_i(posiciones_ceros) = min_d;
            area(rTwave_i, 'FaceColor','y', 'basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
            
            title(r_ind)
            xlim([x_inf, x_sup]); ylim([min_d, max_d])
            hold off
        end
        figure(1)
        sgtitle('marks')
        figure(2)
        sgtitle('results')
        pause
    end
end