function signal = multilead_proces(rPwave)
    sig_size = size(rPwave);
    starts = [];
    ends = [];
    for i=2:12:sig_size(2)
        for j = 1:12
            ind = i+j-1;
            signali = signal(:,ind);
            % Detectar los cambios en la señal
            changes = diff([0; signali(:); 0]);
            
            % Encontrar el inicio y el fin de cada secuencia de 1s
            starts(:,j) = find(changes == 1);
            ends(:,j) = find(changes == -1) - 1;
        end

        for n = 1:size(starts,1)

        end

    end
end