% Se analizan las 12 capas de un record
% -> Si existen partes de la señal de una capa que no se ha detectado onda
% pero en el resto de capas si (al menos 6 de ellas) se hará el promedio de
% los bordes de estas y se añadirá a esa capa
function [wave_s, wave_e, wave] = proces_multi(wave_s, wave_e, wave, rango)
    wave_i = zeros (size(wave,1),12);
    for i = 1:12:size(wave_s,1)
        for k=1:12
            wave_s_i{k} = str2num(cell2mat(wave_s(k+i-1,:)));
            wave_e_i{k} = str2num(cell2mat(wave_e(k+i-1,:)));
        end
  
        % Número de capas y número de inicios en cada capa
        [~, numCapas] = size(wave_s_i);
        
        % Recorrer cada capa
        for capa = 1:numCapas
            wave_capa_s = wave_s_i{capa};
            wave_capa_e = wave_e_i{capa};
            numInicios = length(wave_capa_s);
            % Recorrer cada inicio en la capa actual
            for idx = 1:numInicios
                cont = 0;
                cont2 = 0;
                ind_capa = [];
                wave_s_actual = wave_capa_s(idx);
                posicion_s = zeros(12,1);
                posicion_e = zeros(12,1);
                value_s = zeros(12,1);
                value_e = zeros(12,1);
                
                % Verificar en las demás capas
                for otraCapa = 1:numCapas
                    wave_capa_so = wave_s_i{otraCapa};
                    wave_capa_eo = wave_e_i{otraCapa};
                    
                    % Verificar si hay algún inicio en el rango de +/- 15 muestras
                    if ~any(abs(wave_capa_so - wave_s_actual) <= rango)
                        cont = cont + 1;
                        ind_capa(cont) = otraCapa;
                    else
                        cont2= cont2+1;
                        [~, posicion_s(cont2)] = min(abs(wave_capa_so - wave_s_actual));
                        [~, posicion_e(cont2)] = min(abs(wave_capa_eo - wave_s_actual));
                        value_s(cont2) = wave_capa_so(posicion_s(cont2));
                        value_e(cont2) = wave_capa_eo(posicion_e(cont2));
                    end
                end
                if cont > 6
                    % Rango de valores del 1 al 12
                    ind_completos = 1:12;
                    
                    % Encontrar los valores que no están en el vector A
                    ind_faltantes = setdiff(ind_completos, ind_capa);

                    for j = 1:12
%                         capa_i = ind_faltantes(j);
%                         value_s_i = value_s(j)
%                         value_e_i = value_e(j)
%                         w_start = wave_s_i{capa_i};
%                         w_end = wave_e_i{capa_i};
% 
%                         w_start = w_start(w_start ~= 0);
%                         w_end = w_end(w_end ~= 0);
%                         
%                         wave(w_start:w_end,i + capa_i) = 0;
                       
%                         wave_s_new = wave_s_i(wave_s_i ~= w_start);
%                         wave_e_new = wave_e_i(wave_e_i ~= w_end);
%                         wave_s(capa_i+i,:) = mat2cell(num2str(wave_s_new));
%                         wave_e(capa_i+i,:) = mat2cell(num2str(wave_e_new));

                         capa_i = j;

                        w_start = wave_s_i{capa_i};
                        w_end = wave_e_i{capa_i};
                        
                        value_s = value_s(value_s ~= 0);
                        value_e = value_e(value_e ~= 0);

                        init = round(mean (value_s));
                        fin = round(mean(value_e));
                            
                        wave(init-30:fin+30,i + capa_i) = 0;
%                         wave_s(capa_i+i,:) = mat2cell(num2str(sort([w_start, init])),1);
%                         wave_e(capa_i+i,:) = mat2cell(num2str(sort([w_end, fin])),1);
                    end
                end
                if cont < 6
                    for j = 1:length(ind_capa)
                        capa_i = ind_capa(j);

                        w_start = wave_s_i{capa_i};
                        w_end = wave_e_i{capa_i};
                        
                        value_s = value_s(value_s ~= 0);
                        value_e = value_e(value_e ~= 0);

                        init = round(mean (value_s));
                        fin = round(mean(value_e));
                            
                        wave(init:fin,i + capa_i) = 1;
                        wave_s(capa_i+i,:) = mat2cell(num2str(sort([w_start, init])),1);
                        wave_e(capa_i+i,:) = mat2cell(num2str(sort([w_end, fin])),1);
                    end
                end

            end
        end
    end
end