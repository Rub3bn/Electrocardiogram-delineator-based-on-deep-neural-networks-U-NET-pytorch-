%%
clear all
close all
%%
% Generar 160 números aleatorios en un rango de 1 a 200 sin repeticiones
numeros_totales = 200;
numeros_primer_grupo = 160;
numeros_segundo_grupo = 40;

% Generar los 160 números aleatorios sin repeticiones
grupo_1 = randperm(numeros_totales, numeros_primer_grupo);

% Generar los 40 números restantes que no estén en el primer grupo
todos_los_numeros = 1:numeros_totales;
grupo_2 = setdiff(todos_los_numeros, grupo_1);

disp('Grupo 1 (160 números aleatorios):');
disp(grupo_1);

disp('Grupo 2 (40 números restantes):');
disp(grupo_2);

fid = fopen('C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\indices_aleator.txt', 'w');

% Escribe los datos de las variables en el archivo
% Guardar Grupo 1 en el archivo
fprintf(fid, 'Grupo 1 (160 números aleatorios):\n');
fprintf(fid, '%d', grupo_1(1));
for i = 2:length(grupo_1)
    fprintf(fid, ',%d', grupo_1(i));
end
fprintf(fid, '\n');

% Guardar Grupo 2 en el archivo
fprintf(fid, 'Grupo 2 (40 números restantes):\n');
fprintf(fid, '%d', grupo_2(1));
for i = 2:length(grupo_2)
    fprintf(fid, ',%d', grupo_2(i));
end

a=1:160;
% Guardar Serie 160 en el archivo
fprintf(fid, '160:\n');
fprintf(fid, '%d', a(1));
for i = 2:length(a)
    fprintf(fid, ',%d', a(i));
end

fclose(fid);