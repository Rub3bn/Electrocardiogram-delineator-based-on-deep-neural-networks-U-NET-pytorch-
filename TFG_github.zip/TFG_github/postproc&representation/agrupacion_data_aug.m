ind = {'Poff', 'Pon','QRSoff', 'QRSon', 'Toff', 'Ton'};

for i = 6
    onda = ind{i};
%     l0 = load(['C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\data_aug\' onda '.mat']);
    l1 = load(['C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\data_aug\aur_tach_waves\' onda '.mat']);
    %l2 = load(['C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\data_aug\sr_ector_waves_2\' onda '.mat']);
    i
%     w0 = l0.Ton_values;
    w1 = l1.Ton_values;
%     w2 = l2.Ton_values;
    
%     w0 = w0(1:10,:);
    Ton_values = w1(1:500,:);
%     w2 = w2(101:500,:);
    
%     Ton_values = [w0; w1; w2];

    ruta_carpeta = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\data_aug\aur_tach_waves_def\';
    nombre_archivo = fullfile(ruta_carpeta, [onda '.mat']);

    save(nombre_archivo,[onda '_values']);
end