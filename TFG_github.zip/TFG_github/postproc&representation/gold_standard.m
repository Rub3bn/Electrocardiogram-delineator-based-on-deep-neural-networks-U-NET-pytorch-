function [wave_global, wave_ind_g, wave_s_g, wave_e_g] = gold_standard(wave, wave_s, wave_e, wave_ind, rango)

    wave_global = zeros (size(wave,1),(size(wave,2)-1)/12);
    
    cont_ind = 1;
    ind = 1;
    cont_se = 1;
    for i = 1:12:size(wave_s,1)
        wave_ind_i = wave_ind(1,i+1);
        wave_ind_g{ind} = str2double(regexprep(cell2mat(wave_ind_i), '_\d', ''));
        ind = ind + 1;
        for k=1:12
            wave_ss_i = wave_s(k+i-1,:);
            wave_ee_i = wave_e(k+i-1,:);
            wave_s_i{k} = str2num(cell2mat(wave_ss_i.(2)));
            wave_e_i{k} = str2num(cell2mat(wave_ee_i.(2)));
        end
  
        % Número de capas y número de inicios en cada capa
        [~, numCapas] = size(wave_s_i);
        
        % Recorrer cada capa
        for capa = 1:numCapas
            wave_capa = zeros (size(wave,1),1);
            wave_capa_s = wave_s_i{capa};
            wave_capa_e = wave_e_i{capa};
            numInicios = length(wave_capa_s);
            % Recorrer cada inicio en la capa actual
            for idx = 2:numInicios
                cont = 0;
                cont2 = 0;
                ind_capa = [];
                wave_s_actual = wave_capa_s(idx);
                wave_e_actual = wave_capa_e(idx);
                posicion_s = zeros(12,1);
                posicion_e = zeros(12,1);
                value_s = zeros(12,1);
                value_e = zeros(12,1);
                
                % Verificar en las demás capas
                for otraCapa = 1:numCapas
                    wave_capa_so = wave_s_i{otraCapa};
                    wave_capa_eo = wave_e_i{otraCapa};
                    
                    % Verificar si hay algún inicio en el rango de +/- 15 muestras
                    if any(abs(wave_capa_so - wave_s_actual) <= rango)
                        cont = cont + 1;
                    end
                    if any(abs(wave_capa_eo - wave_e_actual) <= rango)
                        cont2 = cont2 + 1;
                    end

                end
                
                if cont >= 5 && cont2 >= 5
                    wave_capa(wave_s_actual+1:wave_e_actual+1,1) = 1;
                    wave_global(:,cont_ind) = wave_global(:,cont_ind) | wave_capa;
                end

            end
        end

        % Detectar los cambios en la señal
        changes = diff([0;wave_global(:,cont_ind); 0]);
       
        % Encontrar el inicio y el fin de cada secuencia de 1s
        wave_s_g{cont_ind} = find(changes == 1);
        wave_e_g{cont_ind} = find(changes == -1) - 1;
    
        cont_ind = cont_ind + 1;
        
    end

end