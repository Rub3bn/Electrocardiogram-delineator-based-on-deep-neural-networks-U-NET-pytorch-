function plot_gold(dataset, dataset_ind, Pwave, QRSwave, Twave, Pwave_ind, x_inf,x_sup)
    fig = figure;
    fig.Position(1:2) = [25 200];
    fig.Position(3:4) = [1500 3];
    for i = 1:length(Pwave_ind)-1
        
        Pwave_i=Pwave(:,i)
        QRSwave_i=QRSwave(:,i);
        Twave_i=Twave(:,i);
        
        dataset_i = dataset(:,i);
        
        max_d = max(dataset_i)
        min_d = min(dataset_i);

        plot(dataset_i)
        hold on
        posiciones_unos = find(Pwave_i == 1);
        posiciones_ceros = find(Pwave_i == 0);
        Pwave_i(posiciones_unos) = max_d;
        Pwave_i(posiciones_ceros) = min_d;
        area(Pwave_i, 'FaceColor','r','basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
        posiciones_unos = find(QRSwave_i == 1);
        posiciones_ceros = find(QRSwave_i == 0);
        QRSwave_i(posiciones_unos) = max_d;
        QRSwave_i(posiciones_ceros) = min_d;
        area(QRSwave_i, 'FaceColor','g','basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
        posiciones_unos = find(Twave_i == 1);
        posiciones_ceros = find(Twave_i == 0);
        Twave_i(posiciones_unos) = max_d
        Twave_i(posiciones_ceros) = min_d;
        area(Twave_i, 'FaceColor','y', 'basevalue',min_d,'FaceAlpha',.3,'EdgeAlpha',.3);
        hold off

        title('marks ',Pwave_ind(1,i))

        xlim([x_inf, x_sup]); ylim([min_d, max_d])
        
        pause
    end
end