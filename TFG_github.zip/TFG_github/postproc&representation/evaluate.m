    %%
clear all
close all
%% Automatic
%Wave
indi=0;
r_rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPwave.csv';
r_rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSwave.csv';
r_rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rTwave.csv';

rPwave = readtable(r_rutaPwave, 'VariableNamingRule', 'preserve');
rQRSwave = readtable(r_rutaQRSwave, 'VariableNamingRule', 'preserve');
rTwave = readtable(r_rutaTwave, 'VariableNamingRule', 'preserve');

rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Pwave.csv';
rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\QRSwave.csv';
rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Twave.csv';

Pwave = readtable(rutaPwave, 'VariableNamingRule', 'preserve');
QRSwave = readtable(rutaQRSwave, 'VariableNamingRule', 'preserve');
Twave = readtable(rutaTwave, 'VariableNamingRule', 'preserve');

rutaDataset = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Dataset.csv';

dataset = readtable(rutaDataset, 'VariableNamingRule', 'preserve');

%% Manual_Lobac
%Wave
indi=1;
r_rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPwave.csv';
r_rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSwave.csv';
r_rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rTwave.csv';

rPwave = readtable(r_rutaPwave, 'VariableNamingRule', 'preserve');
rQRSwave = readtable(r_rutaQRSwave, 'VariableNamingRule', 'preserve');
rTwave = readtable(r_rutaTwave, 'VariableNamingRule', 'preserve');

rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Pwave.csv';
rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSwave.csv';
rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Twave.csv';

Pwave = readtable(rutaPwave, 'VariableNamingRule', 'preserve');
QRSwave = readtable(rutaQRSwave, 'VariableNamingRule', 'preserve');
Twave = readtable(rutaTwave, 'VariableNamingRule', 'preserve');

rutaDataset = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Dataset.csv';

dataset = readtable(rutaDataset, 'VariableNamingRule', 'preserve');

%% Manual_QT
%Wave
indi=2;
r_rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPwave.csv';
r_rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSwave.csv';
r_rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rTwave.csv';

rPwave = readtable(r_rutaPwave, 'VariableNamingRule', 'preserve');
rQRSwave = readtable(r_rutaQRSwave, 'VariableNamingRule', 'preserve');
rTwave = readtable(r_rutaTwave, 'VariableNamingRule', 'preserve');

rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Pwave.csv';
rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\QRSwave.csv';
rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Twave.csv';

Pwave = readtable(rutaPwave, 'VariableNamingRule', 'preserve');
QRSwave = readtable(rutaQRSwave, 'VariableNamingRule', 'preserve');
Twave = readtable(rutaTwave, 'VariableNamingRule', 'preserve');

rutaDataset = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Dataset.csv';

dataset = readtable(rutaDataset, 'VariableNamingRule', 'preserve');
%%
rPwave_ind =rPwave.Properties.VariableNames;
rQRSwave_ind =rQRSwave.Properties.VariableNames;
rTwave_ind =rTwave.Properties.VariableNames;

Pwave_ind =Pwave.Properties.VariableNames;
QRSwave_ind =QRSwave.Properties.VariableNames;
Twave_ind =Twave.Properties.VariableNames;

dataset_ind = dataset.Properties.VariableNames;

rPwave = table2array(rPwave);
rQRSwave = table2array(rQRSwave);
rTwave = table2array(rTwave);

Pwave = table2array(Pwave);
QRSwave = table2array(QRSwave);
Twave = table2array(Twave);

dataset = table2array(dataset);
%%
x_inf = 1000;
x_sup = 6000;
plot_ECG(dataset, dataset_ind, Pwave, QRSwave, Twave, rPwave, rQRSwave, rTwave, Pwave_ind, QRSwave_ind, Twave_ind, rPwave_ind, rQRSwave_ind, rTwave_ind,x_inf,x_sup)
%%
%Si usamos la libreria lobachevsky las primeras y ultimas muestras no se
%contabilizan
if indi == 1 
    rPwave = rPwave(750:4000,:);
    rQRSwave = rQRSwave(750:4000,:);
    rTwave = rTwave(750:4000,:);
    Pwave = Pwave(750:4000,:);
    QRSwave = QRSwave(750:4000,:);
    Twave = Twave(750:4000,:);
    dataset = dataset(750:4000,:);
end
if indi == 2
    [ind_last,max_length] = armon_QT(Pwave, QRSwave, Twave, Pwave_ind, QRSwave_ind, Twave_ind);
end
%% Dice coefficient
clc
if indi ~= 2
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Pwave_ind, ind));
        
        fiducials_data=Pwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanP=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=rQRSwave_ind(1,i+1);
        posicion = find(strcmp(QRSwave_ind, ind));
        
        fiducials_data=QRSwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanQRS=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rTwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Twave_ind, ind));
        
        fiducials_data=Twave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanT=nanmean(dice)
end
if indi == 2
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Pwave_ind, ind));
        
        fiducials_data=Pwave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanP=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=rQRSwave_ind(1,i+1);
        posicion = find(strcmp(QRSwave_ind, ind));
        
        fiducials_data=QRSwave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanQRS=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rTwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Twave_ind, ind));
        
        fiducials_data=Twave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanT=nanmean(dice)
end

%% Precisión y recall
clc
% Calcular True Positives (TP), False Positives (FP) y False Negatives (FN)
TP = 0;
FP = 0;
FN = 0;

if indi ~= 2
    for i = 1:length(rPwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Pwave_ind, ind));
        
        fiducials_data=Pwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        %El programa no detecta bien cuando no hay onda P
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end 
    precisionP = TP/(TP+FP)
    recallP    = TP/(TP+FN)
        
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rQRSwave_ind)-1
        ind=rQRSwave_ind(1,i+1);
        posicion = find(strcmp(QRSwave_ind, ind));
        
        fiducials_data=QRSwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionQRS = TP/(TP+FP)
    recallQRS    = TP/(TP+FN)
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rTwave_ind)-1
        ind=rTwave_ind(1,i+1);
        posicion = find(strcmp(Twave_ind, ind));
        
        fiducials_data=Twave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
            
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionT = TP/(TP+FP)
    recallT    = TP/(TP+FN)
end

if indi == 2
    for i = 1:length(rPwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Pwave_ind, ind));
        
        fiducials_data=Pwave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        %El programa no detecta bien cuando no hay onda P
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end 
    precisionP = TP/(TP+FP)
    recallP    = TP/(TP+FN)
        
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rQRSwave_ind)-1
        ind=rQRSwave_ind(1,i+1);
        posicion = find(strcmp(QRSwave_ind, ind));
        
        fiducials_data=QRSwave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionQRS = TP/(TP+FP)
    recallQRS    = TP/(TP+FN)
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rTwave_ind)-1
        ind=rTwave_ind(1,i+1);
        posicion = find(strcmp(Twave_ind, ind));
        
        fiducials_data=Twave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
            
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionT = TP/(TP+FP)
    recallT    = TP/(TP+FN)
end

%% Save
% Abre el archivo para escritura

fid = fopen('C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\Evaluacion\dice_precision.txt', 'w');

% Escribe los datos de las variables en el archivo
fprintf(fid, 'dice_meanP: %.5f\n', dice_meanP);
fprintf(fid, 'dice_meanQRS: %.5f\n', dice_meanQRS);
fprintf(fid, 'dice_meanT: %.5f\n', dice_meanT);

fprintf(fid, 'Precicion_P: %.5f\n', precisionP);
fprintf(fid, 'Precision_QRS: %.5f\n', precisionQRS);
fprintf(fid, 'Precision_T: %.5f\n', precisionT);

fprintf(fid, 'Recall_P: %.5f\n', recallP);
fprintf(fid, 'Recall_QRS: %.5f\n', recallQRS);
fprintf(fid, 'Recall_T: %.5f\n', recallT);
% Cierra el archivo
fclose(fid);


%%
% Guarda la variable en un archivo .mat
save('maxmin.mat','ind_last','max_length');

% Luego, si ejecutas clear all, todas las variables se eliminarán
clear all;
%%
% Puedes cargar la variable guardada nuevamente
load('maxmin.mat');

%% Onset, offset Lobachevsky
%On
ind=1;
r_rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPon.csv';
r_rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSon.csv';
r_rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rTon.csv';

rPon= readtable(r_rutaPon, 'VariableNamingRule', 'preserve');
rQRSon = readtable(r_rutaQRSon, 'VariableNamingRule', 'preserve');
rTon = readtable(r_rutaTon, 'VariableNamingRule', 'preserve');

rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Pon.csv';
rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSon.csv';
rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Ton.csv';

Pon = readtable(rutaPon, 'VariableNamingRule', 'preserve');
QRSon = readtable(rutaQRSon, 'VariableNamingRule', 'preserve');
Ton = readtable(rutaTon, 'VariableNamingRule', 'preserve');

%Off
r_rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPoff.csv';
r_rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSoff.csv';
r_rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rToff.csv';

rPoff = readtable(r_rutaPoff, 'VariableNamingRule', 'preserve');
rQRSoff = readtable(r_rutaQRSoff, 'VariableNamingRule', 'preserve');
rToff = readtable(r_rutaToff, 'VariableNamingRule', 'preserve');

rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Poff.csv';
rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSoff.csv';
rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Toff.csv';

Poff = readtable(rutaPoff, 'VariableNamingRule', 'preserve');
QRSoff = readtable(rutaQRSoff, 'VariableNamingRule', 'preserve');
Toff = readtable(rutaToff, 'VariableNamingRule', 'preserve');

%% Onset, offset QT automatic
%On
ind=2;
r_rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPon.csv';
r_rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSon.csv';
r_rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rTon.csv';

rPon= readtable(r_rutaPon, 'VariableNamingRule', 'preserve');
rQRSon = readtable(r_rutaQRSon, 'VariableNamingRule', 'preserve');
rTon = readtable(r_rutaTon,'Range','A1:B21', 'VariableNamingRule', 'preserve');

rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Pon.csv';
rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\QRSon.csv';
rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Ton.csv';

Pon = readtable(rutaPon, 'VariableNamingRule', 'preserve');
QRSon = readtable(rutaQRSon, 'VariableNamingRule', 'preserve');
Ton = readtable(rutaTon, 'VariableNamingRule', 'preserve');

%Off
r_rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPoff.csv';
r_rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSoff.csv';
r_rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rToff.csv';

rPoff = readtable(r_rutaPoff, 'VariableNamingRule', 'preserve');
rQRSoff = readtable(r_rutaQRSoff, 'VariableNamingRule', 'preserve');
rToff = readtable(r_rutaToff,'Range','A1:B21', 'VariableNamingRule', 'preserve'); %Cuidado con 'A1:B21'

rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Poff.csv';
rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\QRSoff.csv';
rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Toff.csv';

Poff = readtable(rutaPoff, 'VariableNamingRule', 'preserve');
QRSoff = readtable(rutaQRSoff, 'VariableNamingRule', 'preserve');
Toff = readtable(rutaToff, 'VariableNamingRule', 'preserve');

%% Onset, offset QT Manual
%On
ind=2;
r_rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPon.csv';
r_rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSon.csv';
r_rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rTon.csv';

rPon= readtable(r_rutaPon, 'VariableNamingRule', 'preserve');
rQRSon = readtable(r_rutaQRSon, 'VariableNamingRule', 'preserve');
rTon = readtable(r_rutaTon,'Range','A1:B21', 'VariableNamingRule', 'preserve');

rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Pon.csv';
rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\QRSon.csv';
rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Ton.csv';

Pon = readtable(rutaPon, 'VariableNamingRule', 'preserve');
QRSon = readtable(rutaQRSon, 'VariableNamingRule', 'preserve');
Ton = readtable(rutaTon, 'VariableNamingRule', 'preserve');

%Off
r_rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPoff.csv';
r_rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSoff.csv';
r_rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rToff.csv';

rPoff = readtable(r_rutaPoff, 'VariableNamingRule', 'preserve');
rQRSoff = readtable(r_rutaQRSoff, 'VariableNamingRule', 'preserve');
rToff = readtable(r_rutaToff,'Range','A1:B21', 'VariableNamingRule', 'preserve'); %Cuidado con 'A1:B21'

rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Poff.csv';
rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\QRSoff.csv';
rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Toff.csv';

Poff = readtable(rutaPoff, 'VariableNamingRule', 'preserve');
QRSoff = readtable(rutaQRSoff, 'VariableNamingRule', 'preserve');
Toff = readtable(rutaToff, 'VariableNamingRule', 'preserve');
%%

% Cast a cell
rPon = table2cell(rPon);
rQRSon = table2cell(rQRSon);
rTon = table2cell(rTon);

rPoff = table2cell(rPoff);
rQRSoff = table2cell(rQRSoff);
rToff = table2cell(rToff);

Pon = table2cell(Pon);
QRSon = table2cell(QRSon);
Ton = table2cell(Ton);

Poff = table2cell(Poff);
QRSoff = table2cell(QRSoff);
Toff = table2cell(Toff);

% % %Cast a array lobachevsky
if ind == 1
    
    rPon_ind = cell2mat(rPon(:,1));
    rQRSon_ind = cell2mat(rQRSon(:,1));
    rTon_ind = cell2mat(rTon(:,1));
    
    rPoff_ind = cell2mat(rPoff(:,1));
    rQRSoff_ind = cell2mat(rPoff(:,1));
    rToff_ind = cell2mat(rPoff(:,1));
    
    Pon_ind = cell2mat(Pon(:,1));
    QRSon_ind = cell2mat(QRSon(:,1));
    Ton_ind = cell2mat(Ton(:,1));
    
    Poff_ind = cell2mat(Poff(:,1));
    QRSoff_ind = cell2mat(QRSoff(:,1));
    Toff_ind = cell2mat(Toff(:,1));

%Cast a array QT
else
    rPon_ind = cellstr((rPon(:,1)));
    rQRSon_ind = cellstr(rQRSon(:,1));
    rTon_ind = cellstr(rTon(:,1));
    
    rPoff_ind = cellstr(rPoff(:,1));
    rQRSoff_ind = cellstr(rQRSoff(:,1));
    rToff_ind = cellstr(rToff(:,1));
    
    Pon_ind = cellstr(Pon(:,1));
    QRSon_ind = cellstr(QRSon(:,1));
    Ton_ind = cellstr(Ton(:,1));
    
    Poff_ind = cellstr(Poff(:,1));
    QRSoff_ind = cellstr(QRSoff(:,1));
    Toff_ind = cellstr(Toff(:,1));
end

% %%
% if ind == 1 
%     rPwave = rPwave(750:4000,:);
%     rQRSwave = rQRSwave(750:4000,:);
%     rTwave = rTwave(750:4000,:);
%     Pwave = Pwave(750:4000,:);
%     QRSwave = QRSwave(750:4000,:);
%     Twave = Twave(750:4000,:);
%     dataset = dataset(750:4000,:);
% end
%% Onset,offset, desviación tipica QT automatic
clc
tol=100;
sampling_freq=500;
for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rPon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rPoff_ind);
    posicion_on = buscar_ind(ind_ron,Pon_ind);
    posicion_off = buscar_ind(ind_ron,Poff_ind);
    
    res_on = rPon(i,2);
    res_off = rPoff(posicion_roff(1),2);
    data_on = Pon(posicion_on(1),2);
    data_off = Poff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);
   
    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);
  
    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end
    %Los valores en los que se obtienen NaN se deben a que no hay onda
    err_on_P_n(i) = nanmean(abs(data_on - res_on));
    err_off_P_n(i) = nanmean(abs(data_off - res_off));

end
err_on_P = nanmean(abs(err_on_P_n))/sampling_freq*1000
err_off_P = nanmean(abs(err_off_P_n))/sampling_freq*1000
std_on_P = nanstd(abs(err_on_P_n))/sampling_freq*1000
std_off_P = nanstd(abs(err_off_P_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rQRSon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rQRSoff_ind);
    posicion_on = buscar_ind(ind_ron,QRSon_ind);
    posicion_off = buscar_ind(ind_ron, QRSoff_ind);
    
    res_on = rQRSon(i,2);
    res_off = rQRSoff(posicion_roff(1),2);
    data_on = QRSon(posicion_on(1),2);
    data_off = QRSoff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));
    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_QRS_n(i) = nanmean(abs(data_on - res_on));
    err_off_QRS_n(i) = nanmean(abs(data_off - res_off));

end
err_on_QRS = nanmean(abs(err_on_QRS_n))/sampling_freq*1000
err_off_QRS = nanmean(abs(err_off_QRS_n))/sampling_freq*1000
std_on_QRS = nanstd(abs(err_on_QRS_n))
std_off_QRS = nanstd(abs(err_off_QRS_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rTon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rToff_ind);
    posicion_on = buscar_ind(ind_ron,Ton_ind);
    posicion_off = buscar_ind(ind_ron,Toff_ind);
    
    res_on = rTon(i,2);
    res_off = rToff(posicion_roff(1),2);
    data_on = Ton(posicion_on(1),2);
    data_off = Toff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));
    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_T_n(i) = nanmean(abs(data_on - res_on));
    err_off_T_n(i) = nanmean(abs(data_off - res_off));

end
err_on_T = nanmean(abs(err_on_T_n))/sampling_freq*1000
err_off_T = nanmean(abs(err_off_T_n))/sampling_freq*1000
std_on_T = nanstd(abs(err_on_T_n))
std_off_T = nanstd(abs(err_off_T_n))/sampling_freq*1000

%% Onset,offset, desviación tipica QT manual
clc
tol=100;
sampling_freq=500;
for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rPon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rPoff_ind);
    posicion_on = buscar_ind(ind_ron,Pon_ind);
    posicion_off = buscar_ind(ind_ron,Poff_ind);
    
    res_on_old = rPon(i,2);
    res_off_old = rPoff(posicion_roff(1),2);
    data_on_old = Pon(posicion_on(1),2);
    data_off_old = Poff(posicion_off(1),2);

    res_on_old = cell2mat(res_on_old);
    res_off_old = cell2mat(res_off_old);
    data_on_old = cell2mat(data_on_old);
    data_off_old = cell2mat(data_off_old);

    res_on_old = str2double(strsplit(res_on_old));
    res_off_old = str2double(strsplit(res_off_old));
    data_on_old = str2double(strsplit(data_on_old));
    data_off_old = str2double(strsplit(data_off_old));

    count_ron=1;
    count_roff=1;
    count_don=1;
    count_doff=1;
    for j=1:length(res_on_old)
        if res_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_on_old(j) < ind_last(posicion_on)
            res_on(count_ron) = res_on_old(j);
            count_ron = count_ron+1;
        end
    end
    for j=1:length(res_off_old)
        if res_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_off_old(j) < ind_last(posicion_on)
            res_off(count_roff) = res_off_old(j);
            count_roff = count_roff+1;
        end
    end
    for j=1:length(data_on_old)
        if data_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_on_old(j) < ind_last(posicion_on)
            data_on(count_don) = data_on_old(j);
            count_don = count_don+1;
        end
    end
    for j=1:length(data_off_old)
        if data_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_off_old(j) < ind_last(posicion_on)
            data_off(count_doff) = data_off_old(j);
            count_doff = count_doff+1;
        end
    end

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);
   
    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);
  
    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end
    %Los valores en los que se obtienen NaN se deben a que no hay onda
    err_on_P_n(i) = nanmean(abs(data_on - res_on));
    err_off_P_n(i) = nanmean(abs(data_off - res_off));

end
err_on_P = nanmean(abs(err_on_P_n))/sampling_freq*1000
err_off_P = nanmean(abs(err_off_P_n))/sampling_freq*1000
std_on_P = nanstd(abs(err_on_P_n))/sampling_freq*1000
std_off_P = nanstd(abs(err_off_P_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rQRSon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rQRSoff_ind);
    posicion_on = buscar_ind(ind_ron,QRSon_ind);
    posicion_off = buscar_ind(ind_ron, QRSoff_ind);
    
    res_on_old = rQRSon(i,2);
    res_off_old = rQRSoff(posicion_roff(1),2);
    data_on_old = QRSon(posicion_on(1),2);
    data_off_old = QRSoff(posicion_off(1),2);

    res_on_old = cell2mat(res_on_old);
    res_off_old = cell2mat(res_off_old);
    data_on_old = cell2mat(data_on_old);
    data_off_old = cell2mat(data_off_old);

    res_on_old = str2double(strsplit(res_on_old));
    res_off_old = str2double(strsplit(res_off_old));
    data_on_old = str2double(strsplit(data_on_old));
    data_off_old = str2double(strsplit(data_off_old));

    count_ron=1;
    count_roff=1;
    count_don=1;
    count_doff=1;
    for j=1:length(res_on_old)
        if res_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_on_old(j) < ind_last(posicion_on)
            res_on(count_ron) = res_on_old(j);
            count_ron = count_ron+1;
        end
    end
    for j=1:length(res_off_old)
        if res_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_off_old(j) < ind_last(posicion_on)
            res_off(count_roff) = res_off_old(j);
            count_roff = count_roff+1;
        end
    end
    for j=1:length(data_on_old)
        if data_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_on_old(j) < ind_last(posicion_on)
            data_on(count_don) = data_on_old(j);
            count_don = count_don+1;
        end
    end
    for j=1:length(data_off_old)
        if data_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_off_old(j) < ind_last(posicion_on)
            data_off(count_doff) = data_off_old(j);
            count_doff = count_doff+1;
        end
    end

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_QRS_n(i) = nanmean(abs(data_on - res_on));
    err_off_QRS_n(i) = nanmean(abs(data_off - res_off));

end
err_on_QRS = nanmean(abs(err_on_QRS_n))/sampling_freq*1000
err_off_QRS = nanmean(abs(err_off_QRS_n))/sampling_freq*1000
std_on_QRS = nanstd(abs(err_on_QRS_n))
std_off_QRS = nanstd(abs(err_off_QRS_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rTon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rToff_ind);
    posicion_on = buscar_ind(ind_ron,Ton_ind);
    posicion_off = buscar_ind(ind_ron,Toff_ind);
    
    res_on_old = rTon(i,2);
    res_off_old = rToff(posicion_roff(1),2);
    data_on_old = Ton(posicion_on(1),2);
    data_off_old = Toff(posicion_off(1),2);

    res_on_old = cell2mat(res_on_old);
    res_off_old = cell2mat(res_off_old);
    data_on_old = cell2mat(data_on_old);
    data_off_old = cell2mat(data_off_old);

    res_on_old = str2double(strsplit(res_on_old));
    res_off_old = str2double(strsplit(res_off_old));
    data_on_old = str2double(strsplit(data_on_old));
    data_off_old = str2double(strsplit(data_off_old));

    count_ron=1;
    count_roff=1;
    count_don=1;
    count_doff=1;
    for j=1:length(res_on_old)
        if res_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_on_old(j) < ind_last(posicion_on)
            res_on(count_ron) = res_on_old(j);
            count_ron = count_ron+1;
        end
    end
    for j=1:length(res_off_old)
        if res_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_off_old(j) < ind_last(posicion_on)
            res_off(count_roff) = res_off_old(j);
            count_roff = count_roff+1;
        end
    end
    for j=1:length(data_on_old)
        if data_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_on_old(j) < ind_last(posicion_on)
            data_on(count_don) = data_on_old(j);
            count_don = count_don+1;
        end
    end
    for j=1:length(data_off_old)
        if data_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_off_old(j) < ind_last(posicion_on)
            data_off(count_doff) = data_off_old(j);
            count_doff = count_doff+1;
        end
    end

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_T_n(i) = nanmean(abs(data_on - res_on));
    err_off_T_n(i) = nanmean(abs(data_off - res_off));

end
err_on_T = nanmean(abs(err_on_T_n))/sampling_freq*1000
err_off_T = nanmean(abs(err_off_T_n))/sampling_freq*1000
std_on_T = nanstd(abs(err_on_T_n))
std_off_T = nanstd(abs(err_off_T_n))/sampling_freq*1000

%% Onset,offset, desviación tipica Lobachevsky
clc
tol=100;
sampling_freq=500;
for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rPon_ind(i);

    posicion_roff = find(rPoff_ind == ind_ron);
    posicion_on = find(Pon_ind == ind_ron);
    posicion_off = find(Poff_ind == ind_ron);
    
    res_on = rPon(i,2);
    res_off = rPoff(posicion_roff(1),2);
    data_on = Pon(posicion_on(1),2);
    data_off = Poff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);
   
    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);
  
    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end
    %Los valores en los que se obtienen NaN se deben a que no hay onda
    err_on_P_n(i) = nanmean(abs(data_on - res_on));
    err_off_P_n(i) = nanmean(abs(data_off - res_off));

end
err_on_P = nanmean(abs(err_on_P_n))/sampling_freq*1000
err_off_P = nanmean(abs(err_off_P_n))/sampling_freq*1000
std_on_P = nanstd(abs(err_on_P_n))/sampling_freq*1000
std_off_P = nanstd(abs(err_off_P_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rQRSon_ind(i);
    posicion_roff = find(rQRSoff_ind == ind_ron);
    posicion_on = find(QRSon_ind == ind_ron);
    posicion_off = find(QRSoff_ind == ind_ron);
    
    res_on = rQRSon(i,2);
    res_off = rQRSoff(posicion_roff(1),2);
    data_on = QRSon(posicion_on(1),2);
    data_off = QRSoff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));
    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_QRS_n(i) = nanmean(abs(data_on - res_on));
    err_off_QRS_n(i) = nanmean(abs(data_off - res_off));

end
err_on_QRS = nanmean(abs(err_on_QRS_n))/sampling_freq*1000
err_off_QRS = nanmean(abs(err_off_QRS_n))/sampling_freq*1000
std_on_QRS = nanstd(abs(err_on_QRS_n))
std_off_QRS = nanstd(abs(err_off_QRS_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rTon_ind(i);
    posicion_roff = find(rToff_ind == ind_ron);
    posicion_on = find(Ton_ind == ind_ron);
    posicion_off = find(Toff_ind == ind_ron);
    
    res_on = rTon(i,2);
    res_off = rToff(posicion_roff(1),2);
    data_on = Ton(posicion_on(1),2);
    data_off = Toff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));
    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_T_n(i) = nanmean(abs(data_on - res_on));
    err_off_T_n(i) = nanmean(abs(data_off - res_off));

end
err_on_T = nanmean(abs(err_on_T_n))/sampling_freq*1000
err_off_T = nanmean(abs(err_off_T_n))/sampling_freq*1000
std_on_T = nanstd(abs(err_on_T_n))
std_off_T = nanstd(abs(err_off_T_n))/sampling_freq*1000

%% Save
fid = fopen('C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\Evaluacion\on_off.txt', 'w');

% Escribe los datos de las variables en el archivo
fprintf(fid, 'err_on_P: %.5f\n', err_on_P);
fprintf(fid, 'err_on_QRS: %.5f\n', err_on_QRS);
fprintf(fid, 'err_on_T: %.5f\n', err_on_T);

fprintf(fid, 'err_off_P: %.5f\n', err_off_P);
fprintf(fid, 'err_off_QRS: %.5f\n', err_off_QRS);
fprintf(fid, 'err_off_T: %.5f\n', err_off_T);

fprintf(fid, 'std_on_P: %.5f\n', std_on_P);
fprintf(fid, 'std_on_QRS: %.5f\n', std_on_QRS);
fprintf(fid, 'std_on_T: %.5f\n', std_on_T);

fprintf(fid, 'std_off_P: %.5f\n', std_off_P);
fprintf(fid, 'std_off_QRS: %.5f\n', std_off_QRS);
fprintf(fid, 'std_off_T: %.5f\n', std_off_T);

% Cierra el archivo
fclose(fid);
