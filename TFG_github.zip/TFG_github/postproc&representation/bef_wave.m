function [num] = bef_wave(vector, value, modo)
    % Encontrar todos los elementos menores que el valor dado
    lower_elements = vector(vector < value);
    if modo == 1
        % Comprobar si hay al menos dos elementos menores que el valor dado
        if length(lower_elements) >= 2
            % Seleccionar el segundo más grande de los elementos menores
            sorted_lower_elements = sort(lower_elements);
            num = sorted_lower_elements(end-1);
        else
            % Si no hay suficientes elementos menores, asignar un valor vacío o adecuado
            num = []; % O algún valor que indique que no hay suficientes elementos menores
        end
    end
    if modo ==2
        % Si existen elementos menores, encontrar el máximo de ellos
        if ~isempty(lower_elements)
            num = max(lower_elements);
        else
            num = []; % O algún valor que indique que no hay elementos menores
        end
    end

    up_elements = vector(vector > value);
    if modo == 3
        if ~isempty(up_elements)
            num =min(up_elements);
        else
            num = []; % O algún valor que indique que no hay elementos menores
        end
    end


end
