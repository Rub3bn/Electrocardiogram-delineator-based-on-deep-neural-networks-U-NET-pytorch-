% NORMAS
% -> Si una onda aparece a menos de x muestras de otra onda se comprobará cual
% es la onda anterior y posterior y se eliminará la onda que no
% corresponda. Si la anterior no corresponde con el orden habitual de las
% ondas se calcularán las longitudes de ambas ondas y se eliminará una de
% las dos si se considera despreciable, sino se dejarán ambas ondas.
%
% -> Si una onda esta completamente pegada a otra, es decir, 1 muestras de
% separación, se observará la onda anterior y posterior y se rellenará todo
% el espacio de ambas ondas con la onda que corresponda
%
% -> Si existen dos ondas sepraradas a menos de x muestras y son del mismo
% tipo se rellenará el espacio entre ellas de ese tipo de onda
%
%

function [rPwave,rQRSwave,rTwave] = pre_overlap2(rPwave,rQRSwave,rTwave)
    sig_size = size(rPwave);
    
    for k=2:sig_size(2)
        rPwave_i = rPwave(:,k);
        rQRSwave_i = rQRSwave(:,k);
        rTwave_i = rTwave(:,k);
        % Detectar los cambios en la señal
        changes_P = diff([0; rPwave_i(:); 0])';
        changes_QRS = diff([0; rQRSwave_i(:); 0])';
        changes_T = diff([0; rTwave_i(:); 0])';
        
        % Encontrar el inicio y el fin de cada secuencia de 1s
        P_wave_s = find(changes_P == 1);
        P_wave_e = find(changes_P == -1) - 1;
    
        QRS_wave_s = find(changes_QRS == 1);
        QRS_wave_e = find(changes_QRS == -1) - 1;

        T_wave_s = find(changes_T == 1);
        T_wave_e = find(changes_T == -1) - 1;
        
        % Crear una estructura para almacenar las ondas y sus tipos
        waves_s = [P_wave_s, QRS_wave_s,T_wave_s];
        waves_e = [P_wave_e, QRS_wave_e,T_wave_e];
        
        waves_e_o = sort(waves_e);
        waves_s_o = sort(waves_s);
        
        % Inicializar una celda para almacenar las ondas demasiado juntas
        too_close_waves = {};
        
        % Recorrer la lista ordenada de todos los inicios de ondas
        for i = 2:length(waves_s) - 1
            for j = i+1:length(waves_e)
                % Calcular la distancia entre dos ondas consecutivas distintas
                dist = abs(waves_e_o(i) - waves_s_o(j)); %Si son ondas diferentes saldrá positivo
                pose = find(waves_e == waves_e_o(i));
                pose = pose(1);
                poss = find(waves_s == waves_s_o(j));
                poss = poss(1);
                if pose <= length(P_wave_e)
                    ind1 = 1;
                else if pose >= length(P_wave_e) && pose <= length(P_wave_e)+length(QRS_wave_e)
                    ind1 = 2;
                else
                    ind1 = 3;
                end
                end
               
                if poss <= length(P_wave_s)
                    ind2 = 1;
                    
                else if  poss >= length(P_wave_s) && poss <= length(P_wave_s)+length(QRS_wave_s)
                    ind2 = 2;
                else 
                    ind2 = 3;
                end
                end
        
                if dist == 1
                    dist
                    too_close_waves = [too_close_waves; waves_e(pose), ind1, waves_s(poss), ind2, dist];
                end
            end
        end
        
        for i = 1:length(too_close_waves)
            
            ae = too_close_waves{i}(1);
            as = too_close_waves{i}(3);
        
            pose = find(waves_e == ae);
            poss = find(waves_s == as);
        
            pose_o = find(waves_e_o == ae);
            poss_o = find(waves_s_o == as);
        
            typee = too_close_waves{i}(2);
            types = too_close_waves{i}(4);
        
            dist = too_close_waves{i}(5);
        
            onda_ant2 = bef_wave(waves_s, ae,1);
        
            pos_ant = find(waves_s == onda_ant2);
        
            if pos_ant <= length(P_wave_s)
                start1 = bef_wave(waves_s,ae,2);
                end2 = bef_wave(waves_e, as,3);
                if dist == 1
                    rPwave_i(start1:end2) = 0;
                    rQRSwave_i(start1:end2) = 1;
                    rTwave_i(start1:end2) = 0;
                end
            end
            if pos_ant > length(P_wave_s) && pos_ant <= (length(P_wave_s) + length(QRS_wave_s))
                start1 = bef_wave(waves_s,ae,2);
                end2 = bef_wave(waves_e, as,3);
                if dist == 1
                    rPwave_i(start1:end2) = 0;
                    rQRSwave_i(start1:end2) = 0;
                    rTwave_i(start1:end2) = 1;
                end
            end
        
            if pos_ant > (length(P_wave_s) + length(QRS_wave_s))
                start1 = bef_wave(waves_s,ae,2);
                end2 = bef_wave(waves_e, as,3);
                if dist == 1
                    rPwave_i(start1:end2) = 1;
                    rQRSwave_i(start1:end2) = 0;
                    rTwave_i(start1:end2) = 0;
                
                end
            end
        end

        rPwave(:,k) = rPwave_i;
        rQRSwave(:,k) = rQRSwave_i';
        rTwave(:,k) = rTwave_i';

    end
%     
%     for k=2:size(rPwave,2)
%         k
%         rPwave_i = rPwave(:,k);
%         rQRSwave_i = rQRSwave(:,k);
%         rTwave_i = rTwave(:,k);
%         % Detectar los cambios en la señal
%         changes_P = diff([0; rPwave_i(:); 0]);
%         changes_QRS = diff([0; rQRSwave_i(:); 0]);
%         changes_T = diff([0; rTwave_i(:); 0]);
% 
%         % Encontrar el inicio y el fin de cada secuencia de 1s
%         P_wave_s1 = num2str(find(changes_P == 1));
%         P_wave_e1 = num2str(find(changes_P == -1) - 1);
%     
%         QRS_wave_s1 = num2str(find(changes_QRS == 1));
%         QRS_wave_e1 = num2str(find(changes_QRS == -1) - 1);
% 
%         T_wave_s1 = num2str(P_wave_s1);
%         T_wave_e1= num2str(P_wave_e1);
% 
% 
%         P_wave_ss{k} = P_wave_s1
%         P_wave_ee{k} = P_wave_e1;
%     
%         QRS_wave_ss{k} = QRS_wave_s1;
%         QRS_wave_ee{k} = QRS_wave_e1;
% 
%         T_wave_ss{k} = T_wave_s1;
%         T_wave_ee{k}= T_wave_e1;
% 
%     end
%     rPon = P_wave_ss;
%     rPoff = P_wave_ee;
% 
%     rQRSon = QRS_wave_ss;
%     rQRSoff = QRS_wave_ee;
% 
%     rTon = T_wave_ss;
%     rToff = T_wave_ee;
end