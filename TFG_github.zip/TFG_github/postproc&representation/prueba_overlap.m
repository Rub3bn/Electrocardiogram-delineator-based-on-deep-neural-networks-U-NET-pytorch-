 % Ejemplo de datos
P_wave_s = [1, 16];
QRS_wave_s = [8, 21, 25];
T_wave_s = 12;

P_wave_e = [4, 18];
QRS_wave_e = [9, 23, 27];
T_wave_e = 13;

rPwave_i   = [1 1 1 1 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0];
rQRSwave_i = [0 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 1 1 1];
rTwave_i   = [0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0];

%CORREGIR PROBLEMA CON EL PRIMER TÉRMINO

% Definir el umbral de distancia mínima permitida entre dos ondas distintas
threshold = 2;

% Crear una estructura para almacenar las ondas y sus tipos
waves_s = [P_wave_s, QRS_wave_s,T_wave_s];
waves_e = [P_wave_e, QRS_wave_e,T_wave_e];

waves_e_o = sort(waves_e);
waves_s_o = sort(waves_s);

% Inicializar una celda para almacenar las ondas demasiado juntas
too_close_waves = {};

% Recorrer la lista ordenada de todos los inicios de ondas
for i = 1:length(waves_s) - 1
    for j = i+1:length(waves_e)
        % Calcular la distancia entre dos ondas consecutivas distintas
        dist = abs(waves_e_o(i) - waves_s_o(j)); %Si son ondas diferentes saldrá positivo
        pose = find(waves_e == waves_e_o(i));
        poss = find(waves_s == waves_s_o(j));
        if pose <= length(P_wave_e)
            ind1 = 1;
        else if pose >= length(P_wave_e) && pose <= length(P_wave_e)+length(QRS_wave_e)
            ind1 = 2;
        else
            ind1 = 3;
        end
        end

        if poss <= length(P_wave_s)
            ind2 = 1;
        else if  poss >= length(P_wave_s) && poss <= length(P_wave_s)+length(QRS_wave_s)
            ind2 = 2;
        else 
            ind2 = 3;
        end
        end

        if dist <= threshold
            too_close_waves = [too_close_waves; waves_e(pose), ind1, waves_s(poss), ind2, dist];
        end
    end
end

for i = 1:length(too_close_waves)
    
    ae = too_close_waves{i}(1);
    as = too_close_waves{i}(3);

    pose = find(waves_e == ae);
    poss = find(waves_s == as);

    pose_o = find(waves_e_o == ae);
    poss_o = find(waves_s_o == as);

    typee = too_close_waves{i}(2);
    types = too_close_waves{i}(4);

    dist = too_close_waves{i}(5);

    onda_ant2 = bef_wave(waves_s, ae,1);

    pos_ant = find(waves_s == onda_ant2);

    if pos_ant <= length(P_wave_s)
        start1 = bef_wave(waves_s,ae,2);
        end2 = bef_wave(waves_e, as,3);
        if types == typee
            if types == 1
                rPwave_i(start1:end2) = 1;
            else if types == 2
                rQRSwave_i(start1:end2) = 1;
            else
                rTwave_i(start1:end2) = 1;
            end
            end
        else if dist == 1
            rPwave_i(start1:end2) = 0;
            rQRSwave_i(start1:end2) = 1;
            rTwave_i(start1:end2) = 0;
        else
            if typee == 2
                start_w = bef_wave(waves_s, ae,2);
                rQRSwave_i(start_w:ae) = 1;
                rPwave_i(start1:end2) = 0;
                rTwave_i(start1:end2) = 0;
                
            else if types == 2
                end_w = bef_wave(waves_e, as,3);
                rQRSwave_i(as:end_w) = 1;
                rPwave_i(start1:end2) = 0;
                rTwave_i(start1:end2) = 0;
                
            else
                %VER SI ES LO MAS ACERTADO ¡¡¡¡¡¡¡¡¡
                rPwave_i(start1:end2) = 0;
                rQRSwave_i(start1:end2) = 0;
                rTwave_i(start1:end2) = 0;
            end
            end
        end
        end
    end
    if pos_ant > length(P_wave_s) && pos_ant <= (length(P_wave_s) + length(QRS_wave_s))
        start1 = bef_wave(waves_s,ae,2);
        end2 = bef_wave(waves_e, as,3);
        if types == typee
            if types == 1
                rPwave_i(start1:end2) = 1;
            else if types == 2
                rQRSwave_i(start1:end2) = 1;
            else
                rTwave_i(start1:end2) = 1;
            end
            end
        else if dist == 1
            rPwave_i(start1:end2) = 0;
            rQRSwave_i(start1:end2) = 0;
            rTwave_i(start1:end2) = 1;
        else
            if typee == 3
                start_w = bef_wave(waves_s, ae,2);
                rTwave_i(start_w:ae) = 1;
                rQRSwave_i(start1:end2) = 0;
                rPwave_i(start1:end2) = 0;
                
            else if types == 3
                end_w = bef_wave(waves_e, as,3);
                rTwave_i(as:end_w) = 1;
                rQRSwave_i(start1:end2) = 0;
                rPwave_i(start1:end2) = 0;
                
            else
                %VER SI ES LO MAS ACERTADO ¡¡¡¡¡¡¡¡¡
                rPwave_i(start1:end2) = 0;
                rQRSwave_i(start1:end2) = 0;
                rTwave_i(start1:end2) = 0;
            end
            end
        end
        end
    end

    if pos_ant > (length(P_wave_s) + length(QRS_wave_s))
        start1 = bef_wave(waves_s,ae,2);
        end2 = bef_wave(waves_e, as,3);
        if types == typee
            if types == 1
                rPwave_i(start1:end2) = 1;
            else if types == 2
                rQRSwave_i(start1:end2) = 1;
            else
                rTwave_i(start1:end2) = 1;
            end
            end
        else if dist == 1
            rPwave_i(start1:end2) = 1;
            rQRSwave_i(start1:end2) = 0;
            rTwave_i(start1:end2) = 0;
        else
            if typee == 1
                start_w = bef_wave(waves_s, ae,2);
                rPwave_i(start_w:ae) = 1;
                rQRSwave_i(start1:end2) = 0;
                rTwave_i(start1:end2) = 0;
                
            else if types == 1
                end_w = bef_wave(waves_e, as,3);
                rPwave_i(as:end_w) = 1;
                rQRSwave_i(start1:end2) = 0;
                rTwave_i(start1:end2) = 0;
                
            else
                %VER SI ES LO MAS ACERTADO ¡¡¡¡¡¡¡¡¡
                rPwave_i(start1:end2) = 0;
                rQRSwave_i(start1:end2) = 0;
                rTwave_i(start1:end2) = 0;
            end
            end
        end
        end
    end
    
end
    

