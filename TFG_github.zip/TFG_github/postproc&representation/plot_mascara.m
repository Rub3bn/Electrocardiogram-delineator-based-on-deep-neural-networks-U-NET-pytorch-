function plot_mascara(dataset, dataset_ind, Pwave, QRSwave, Twave, rPwave, rQRSwave, rTwave, Pwave_ind, QRSwave_ind, Twave_ind, rPwave_ind, rQRSwave_ind, rTwave_ind,x_inf,x_sup)
    fig = figure;
    fig.Position(1:2) = [25 200];
    fig.Position(3:4) = [1500 400];
    for i = 1:length(rPwave_ind)-1
        t = (0:5000-1) * (1/500);
        r_ind=rPwave_ind(i+1);
        posicion = find(strcmp(rPwave_ind, r_ind))
        rPwave_i=rPwave(:,posicion);
        rQRSwave_i=rQRSwave(:,posicion);
        rTwave_i=rTwave(:,posicion);

        posicion = find(strcmp(Pwave_ind, r_ind));
        Pwave_i=Pwave(:,posicion);
        QRSwave_i=QRSwave(:,posicion);
        Twave_i=Twave(:,posicion);
        
        posicion = find(strcmp(dataset_ind, r_ind));
        dataset_i = dataset(:,posicion);
        
        max_d = 1;
        min_d = min(dataset_i);
        
        t = (0:5000-1) * 1/500;

        subplot(4,1,1)
        plot(t,dataset_i, 'LineWidth', 1)
        xlabel('Segundos')
        grid on
        title('Electrocardiograma')
        xlim([x_inf, x_sup]); ylim([min_d, max_d])
        subplot(4,1,2)
        posiciones_unos = find(Pwave_i == 1);
        posiciones_ceros = find(Pwave_i == 0);
        Pwave_i(posiciones_unos) = 1;
        Pwave_i(posiciones_ceros) = 0;
        plot(t, Pwave_i,'color','r', 'LineWidth', 1);
        xlim([x_inf, x_sup]); ylim([0, max_d])
        title('Onda P ')
        xlabel('Segundos')
        grid on
        subplot(4,1,3)
        xlabel('Segundos')
        grid on
        posiciones_unos = find(QRSwave_i == 1);
        posiciones_ceros = find(QRSwave_i == 0);
        QRSwave_i(posiciones_unos) = 1;
        QRSwave_i(posiciones_ceros) = 0;
        plot(t, QRSwave_i,'color',[0, 0.5, 0], 'LineWidth', 1);
        title('Complejo QRS')
        xlim([x_inf, x_sup]); ylim([0, max_d])
        xlabel('Segundos')
        grid on
        subplot(4,1,4)
        posiciones_unos = find(Twave_i == 1);
        posiciones_ceros = find(Twave_i == 0);
        Twave_i(posiciones_unos) = 1;
        Twave_i(posiciones_ceros) = 0;
        plot(t, Twave_i,'color',[0.8, 0.8, 0], 'LineWidth', 1);
        title('Onda T')
        xlabel('Segundos')
        xlim([x_inf, x_sup]); ylim([0, max_d])
        grid on
        sgtitle(r_ind)
        pause
    end
end