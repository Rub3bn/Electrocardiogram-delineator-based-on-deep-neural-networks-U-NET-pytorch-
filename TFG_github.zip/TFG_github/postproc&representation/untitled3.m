
inicios1 = [10,  50, 130, 160];
inicios2 = [12,  48,  92, 128];
inicios3 = [11, 49, 129. 171];
wave_s = {inicios1, inicios2, inicios3}'
fin1 = [20,  60, 140, 170];
fin2 = [22,  58,  102, 138];
fin3 = [21, 59, 139, 171];
rango = 15;
wave_e = {fin1, fin2, fin3}'

    for i = 1:3:size(wave_s,1)
        for k=1:3
            wave_s_i{k} = (cell2mat(wave_s(k+i-1,:)));
            wave_e_i{k} = (cell2mat(wave_e(k+i-1,:)));
        end
         

        % Número de capas y número de inicios en cada capa
        [~, numCapas] = size(wave_s_i);
        
        % Recorrer cada capa
        for capa = 1:numCapas
            wave_capa_s = wave_s_i{capa};
            wave_capa_e = wave_e_i{capa};
            numInicios = length(wave_capa_s);
            % Recorrer cada inicio en la capa actual
            for idx = 1:numInicios
                cont = 0;
                cont2 = 0;
                ind_capa = [];
                wave_s_actual = wave_capa_s(idx);
                posicion_s = zeros(numCapas,1);
                posicion_e = zeros(numCapas,1);
                value_s = zeros(numCapas,1);
                value_e = zeros(numCapas,1);
                
                % Verificar en las demás capas
                for otraCapa = 1:numCapas

                    wave_capa_so = wave_s_i{otraCapa};
                    wave_capa_eo = wave_e_i{otraCapa};
                    
                    % Verificar si hay algún inicio en el rango de +/- 15 muestras
                    if ~any(abs(wave_capa_so - wave_s_actual) <= rango)
                        cont = cont + 1;
                        ind_capa(cont) = otraCapa;
                    else
                        cont2= cont2+1;
                        [~, posicion_s] = min(abs(wave_capa_so - wave_s_actual))
                        [~, posicion_e] = min(abs(wave_capa_eo - wave_s_actual))
                        value_s(cont2) = wave_capa_so(posicion_s)
                        value_e(cont2) = wave_capa_eo(posicion_e)
                    end
                    
                end
                
                if cont < 6
                    for j = 1:length(ind_capa)
                        capa_i = ind_capa(j);

                        w_start = wave_s_i{capa_i};
                        w_end = wave_e_i{capa_i};
                        
                        value_s = value_s(value_s ~= 0);
                        value_e = value_e(value_e ~= 0);

                        init = round(mean (value_s))
                        fin = round(mean(value_e))
                            
                        o = i + capa_i-1
                        wave(init:fin,i + capa_i-1) = 1
                        wave_s(capa_i+i,:) = mat2cell(num2str(sort([w_start, init])),1);
                        wave_e(capa_i+i-1,:) = mat2cell(num2str(sort([w_end, fin])),1);
                    end
                end

            end
        end
    end