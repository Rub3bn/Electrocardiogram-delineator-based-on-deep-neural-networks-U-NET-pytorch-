 % Ejemplo de datos
P_wave = [10, 50, 90];
QRS_wave = [15, 55, 95];
T_wave = [20, 60, 100];

% Definir el umbral de distancia mínima permitida entre dos ondas distintas
threshold = 6;

% Crear una estructura para almacenar las ondas y sus tipos
waves = [P_wave, QRS_wave,T_wave];


% Inicializar una celda para almacenar las ondas demasiado juntas
too_close_waves = {};

% Recorrer la lista ordenada de todos los inicios de ondas
for i = 1:length(waves) - 1
    for j = i+1:length(waves)
        % Calcular la distancia entre dos ondas consecutivas distintas
        dist = abs(waves(i) - waves(j));

        if i <= length(P_wave)
            ind1 = 1;
        else if i <= length(P_wave) && i >= length(P_wave)*2
            ind1 = 2;
        else
            ind1 = 3;
        end
        end

         if j <= length(P_wave)
            ind2 = 1;
        else if  j <= length(P_wave) && j >= length(P_wave)*2
            ind2 = 2;
        else 
            ind2 = 3;
        end
        end

        if dist < threshold
            too_close_waves = [too_close_waves; waves(i), ind1, waves(j), ind2, dist];
        end
    end
end
for i = 1:length(too_close_waves)
    for j = 1:2
        a = too_close_waves{i}(j);
        pos = find(waves == a);
        if pos <= length(P_wave)
            pos2 = find(P_wave == a);
            onda_ant = waves_o(pos-1)
        else if pos <= length(P_wave) && pos >= length(P_wave)*2
            pos2 = find(QRS_wave == a);
       
        else
            pos2 = find(T_wave == a);
        end
        end
    end
end
