function [ini, fin] = armon_lob(Pwave,QRSwave,Twave,Pwave_ind, rPwave, rQRSwave, rTwave)

    for i = 2:length(Pwave_ind)
        Pwave_i=Pwave(:,i);
        QRSwave_i=QRSwave(:,i);
        Twave_i=Twave(:,i);

        % Detectar los cambios en la señal
        changes_P = diff([0;Pwave_i(:); 0]);
        changes_QRS = diff([0; QRSwave_i(:); 0]);
        changes_T = diff([0; Twave_i(:); 0]);

        % Encontrar el inicio y el fin de cada secuencia de 1s
        P_wave_s = find(changes_P == 1);
        P_wave_e = find(changes_P == -1) - 1;
    
        QRS_wave_s = find(changes_QRS == 1);
        QRS_wave_e = find(changes_QRS == -1) - 1;

        T_wave_s = find(changes_T == 1);
        T_wave_e= find(changes_T == 1)-1;

        total_s = [P_wave_s QRS_wave_s T_wave_s];
        total_e = [P_wave_e QRS_wave_e T_wave_e];

        ini(i-1) = min(total_s)+10;
        fin(i-1) = max(total_e)-10;

    end