function [wave_global, dataset_global, wave_ind_g, dataset_ind_g] = union_truth(wave, wave_ind, dataset, dataset_ind )
    
    % Iteramos sobre cada derivación y realizamos la unión de las máscaras
    ind=1;
    wave_global = zeros(size(dataset, 1), (size(wave, 2)-1)/12);
    dataset_global = zeros(size(dataset, 1), (size(dataset, 2)-1)/12);
    wave_ind_g = {};
    dataset_ind_g = {};

    for i = 2:12:size(wave,2)
        for k = 1:12
            wave_derivacion = wave(:, k+i-1); % Obtenemos la máscara de la derivación actual
            wave_global(:,ind) = wave_global(ind) | wave_derivacion; % Realizamos la unión de máscaras
            ind_w = wave_ind(:, k+i-1);
            posicion_data = buscar_ind(ind_w,dataset_ind);
           
            dataset_global(:,ind) = dataset_global(:,ind) + dataset(:,posicion_data);

            if k == 1
                wave_ind_g{ind} = str2double(regexprep(cell2mat(wave_ind(:, k+i-1)), '_\d', ''));
                dataset_ind_g{ind} = str2double(regexprep(cell2mat(dataset_ind(:,posicion_data)), '_\d', ''));
                
            end
        end
        dataset_global(:,ind) = dataset_global(:,ind)./12;
        ind = ind+1;
    end
end