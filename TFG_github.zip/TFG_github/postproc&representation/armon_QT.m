function[ind_last,max_length] = armon_QT(Pwave, QRSwave, Twave, Pwave_ind, QRSwave_ind, Twave_ind)
    
    max_length = zeros(1,length(Pwave_ind));
    ind_last = zeros(1,length(Pwave_ind));
    for i = 2:length(Pwave_ind)
        Pwave_i=Pwave(:,i);
        QRSwave_i=QRSwave(:,i);
        Twave_i=Twave(:,i);

        cont = 0;
        cont_0_P = 0;
        cont_0_QRS = 0;
        cont_0_T = 0;
        
        for j = 2:length(Pwave_i)
            
            if Pwave_i(j) == 1
                cont_0_P = 0;
                cont_0_QRS = 0;
                cont_0_T = 0;
            end
            if QRSwave_i(j) == 1
                cont_0_P = 0;
                cont_0_QRS = 0;
                cont_0_T = 0;
            end
            if Twave_i(j) == 1
                cont_0_P = 0;
                cont_0_QRS = 0;
                cont_0_T = 0;
            end

            if Pwave_i(j) == 0
                cont_0_P = cont_0_P+1;
            end
            if QRSwave_i(j) == 0
                cont_0_QRS = cont_0_QRS+1;
            end
            if Twave_i(j) == 0
                cont_0_T = cont_0_T+1;
            end

            cont = cont+1;
            

            if  cont_0_P >= 1000 || cont_0_QRS >= 1000 || cont_0_T >= 1000
                cont = 0;
                cont_0_P = 0;
                cont_0_QRS = 0;
                cont_0_T = 0;
            end
            if cont > max_length(i-1)
              max_length(i-1) = cont;
              ind_last(i-1) = j;
            end

        end
    end
end