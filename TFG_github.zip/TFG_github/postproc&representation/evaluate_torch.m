   %%
clear all
close all
%% Automatic
%Wave
indi=0;
r_rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPwave.csv';
r_rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\EECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSwave.csv';
r_rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rTwave.csv';

rPwave = readtable(r_rutaPwave, 'VariableNamingRule', 'preserve');
rQRSwave = readtable(r_rutaQRSwave, 'VariableNamingRule', 'preserve');
rTwave = readtable(r_rutaTwave, 'VariableNamingRule', 'preserve');

rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\qt-database-1.0.0\qt-database-1.0.0\automatic\Pwave.csv';
rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\qt-database-1.0.0\qt-database-1.0.0\automatic\QRSwave.csv';
rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\qt-database-1.0.0\qt-database-1.0.0\automatic\Twave.csv';

Pwave = readtable(rutaPwave, 'VariableNamingRule', 'preserve');
QRSwave = readtable(rutaQRSwave, 'VariableNamingRule', 'preserve');
Twave = readtable(rutaTwave, 'VariableNamingRule', 'preserve');

rutaDataset = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia\qt-database-1.0.0\qt-database-1.0.0\automatic\Dataset.csv';

dataset = readtable(rutaDataset, 'VariableNamingRule', 'preserve');

%% Manual_Lobac
%Wave
indi=1;
r_rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPwave.csv';
r_rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSwave.csv';
r_rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rTwave.csv';


rPwave = readtable(r_rutaPwave, 'VariableNamingRule', 'preserve');
rQRSwave = readtable(r_rutaQRSwave, 'VariableNamingRule', 'preserve');
rTwave = readtable(r_rutaTwave, 'VariableNamingRule', 'preserve');

rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Pwave.csv';
rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSwave.csv';
rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Twave.csv';

Pwave = readtable(rutaPwave, 'VariableNamingRule', 'preserve');
QRSwave = readtable(rutaQRSwave, 'VariableNamingRule', 'preserve');
Twave = readtable(rutaTwave, 'VariableNamingRule', 'preserve');

rutaDataset = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Dataset.csv';

dataset = readtable(rutaDataset, 'VariableNamingRule', 'preserve');


r_rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPon.csv';
r_rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSon.csv';
r_rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rTon.csv';

rPon= readtable(r_rutaPon, 'VariableNamingRule', 'preserve');
rQRSon = readtable(r_rutaQRSon, 'VariableNamingRule', 'preserve');
rTon = readtable(r_rutaTon, 'VariableNamingRule', 'preserve');

rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Pon.csv';
rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSon.csv';
rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Ton.csv';

Pon = readtable(rutaPon, 'VariableNamingRule', 'preserve');
QRSon = readtable(rutaQRSon, 'VariableNamingRule', 'preserve');
Ton = readtable(rutaTon, 'VariableNamingRule', 'preserve');

%Off
r_rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPoff.csv';
r_rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSoff.csv';
r_rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rToff.csv';

rPoff = readtable(r_rutaPoff, 'VariableNamingRule', 'preserve');
rQRSoff = readtable(r_rutaQRSoff, 'VariableNamingRule', 'preserve');
rToff = readtable(r_rutaToff, 'VariableNamingRule', 'preserve');

rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Poff.csv';
rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSoff.csv';
rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Toff.csv';

Poff = readtable(rutaPoff, 'VariableNamingRule', 'preserve');
QRSoff = readtable(rutaQRSoff, 'VariableNamingRule', 'preserve');
Toff = readtable(rutaToff, 'VariableNamingRule', 'preserve');

%% Manual_QT
%Wave
indi=2;
r_rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPwave.csv';
r_rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSwave.csv';
r_rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rTwave.csv';

rPwave = readtable(r_rutaPwave, 'VariableNamingRule', 'preserve');
rQRSwave = readtable(r_rutaQRSwave, 'VariableNamingRule', 'preserve');
rTwave = readtable(r_rutaTwave, 'VariableNamingRule', 'preserve');

rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\qt-database-1.0.0\qt-database-1.0.0\manual0\Pwave.csv';
rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\qt-database-1.0.0\qt-database-1.0.0\manual0\QRSwave.csv';
rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\qt-database-1.0.0\qt-database-1.0.0\manual0\Twave.csv';

Pwave = readtable(rutaPwave, 'VariableNamingRule', 'preserve');
QRSwave = readtable(rutaQRSwave, 'VariableNamingRule', 'preserve');
Twave = readtable(rutaTwave, 'VariableNamingRule', 'preserve');

rutaDataset = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\qt-database-1.0.0\qt-database-1.0.0\manual0\Dataset.csv';

dataset = readtable(rutaDataset, 'VariableNamingRule', 'preserve');
%%
rPwave_ind =rPwave.Properties.VariableNames;
rQRSwave_ind =rQRSwave.Properties.VariableNames;
rTwave_ind =rTwave.Properties.VariableNames;

Pwave_ind =Pwave.Properties.VariableNames;
QRSwave_ind =QRSwave.Properties.VariableNames;
Twave_ind =Twave.Properties.VariableNames;

dataset_ind = dataset.Properties.VariableNames;

rPwave = table2array(rPwave);
rQRSwave = table2array(rQRSwave);
rTwave = table2array(rTwave);

Pwave = table2array(Pwave);
QRSwave = table2array(QRSwave);
Twave = table2array(Twave);

dataset = table2array(dataset);


% % Busca índices que comiencen con '15_'
% pattern = '15_';
% pos_P = find(startsWith(rPwave_ind, pattern));
% pos_QRS = find(startsWith(rQRSwave_ind, pattern));
% pos_T = find(startsWith(rTwave_ind, pattern));
% rPwave_ind(pos_P) = [];
% rQRSwave_ind(pos_QRS) = [];
% rTwave_ind(pos_T) = [];
% 
% rPwave(pos_P) = [];
% rQRSwave(pos_QRS) = [];
% rTwave(pos_T) = [];
% 
% pos_P = find(startsWith(Pwave_ind, pattern));
% pos_QRS = find(startsWith(QRSwave_ind, pattern));
% pos_T = find(startsWith(Twave_ind, pattern));
% Pwave_ind(pos_P) = [];
% QRSwave_ind(pos_QRS) = [];
% Twave_ind(pos_T) = [];
% 
% Pwave(pos_P) = [];
% QRSwave(pos_QRS) = [];
% Twave(pos_T) = [];

%% gold_standard
[P_g, dataset_global, Pwave_ind_g, dataset_ind_g] = union_truth(Pwave, Pwave_ind, dataset, dataset_ind );
[QRS_g, ~, QRSwave_ind_g, ~] = union_truth(QRSwave, QRSwave_ind, dataset, dataset_ind );
[T_g, ~, Twave_ind_g, ~] = union_truth(Twave, Twave_ind, dataset, dataset_ind );

%%
Pwave = P_g;
Pwave_ind = Pwave_ind_g;
QRSwave = QRS_g;
QRSwave_ind = QRSwave_ind_g;
Twave = T_g;
Twave_ind = Twave_ind_g;
dataset = dataset_global;
dataset_ind = dataset_ind_g;


%%
[rP_g, rPwave_ind_g, Pwave_s_g, Pwave_e_g] = gold_standard(rPwave, rPon, rPoff, rPwave_ind, 15);
[rQRS_g, rQRSwave_ind_g, QRSwave_s_g, QRSwave_e_g] = gold_standard(rQRSwave, rQRSon, rQRSoff, rQRSwave_ind, 8);
[rT_g, rTwave_ind_g, Twave_s_g, Twave_e_g] = gold_standard(rTwave, rTon, rToff, rTwave_ind, 15);

%%
rPwave = rP_g;
rPwave_ind = rPwave_ind_g;
rQRSwave = rQRS_g;
rQRSwave_ind = rQRSwave_ind_g;
rTwave = rT_g;
rTwave_ind = rTwave_ind_g;

%% plot gold_standard
x_inf = 1;
x_sup = length(dataset);
plot_ECG_g(dataset_global, dataset_ind_g, P_g, QRS_g, T_g, rP_g, rQRS_g, rT_g, Pwave_ind_g, QRSwave_ind_g, Twave_ind_g, rPwave_ind_g, rQRSwave_ind_g, rTwave_ind_g,x_inf,x_sup, Pwave_s_g, Pwave_e_g, QRSwave_s_g, QRSwave_e_g, Twave_s_g,Twave_e_g)

%% plot single-lead
x_inf = 1500;
x_sup = 3500;
plot_ECG(dataset, dataset_ind, Pwave, QRSwave, Twave, rPwave, rQRSwave, rTwave, Pwave_ind, QRSwave_ind, Twave_ind, rPwave_ind, rQRSwave_ind, rTwave_ind,x_inf,x_sup)

%% plot mascara
x_inf = 3;
x_sup = 7;
plot_mascara(dataset, dataset_ind, Pwave, QRSwave, Twave, rPwave, rQRSwave, rTwave, Pwave_ind, QRSwave_ind, Twave_ind, rPwave_ind, rQRSwave_ind, rTwave_ind,x_inf,x_sup)
%% plot multi-lead
x_inf = 0;
x_sup = 5000;
plot_multi(dataset, dataset_ind, Pwave, QRSwave, Twave, rPwave, rQRSwave, rTwave, Pwave_ind, QRSwave_ind, Twave_ind, rPwave_ind, rQRSwave_ind, rTwave_ind,x_inf,x_sup)

%% Post-Procesado

cadena_inicios1 = rPon.Var2; % Suponiendo que la primera fila contiene los inicios
cadena_fin1 = rPoff.Var2;
cadena_inicios2 = rQRSon.Var2; % Suponiendo que la primera fila contiene los inicios
cadena_fin2 = rQRSoff.Var2;
cadena_inicios3 = rTon.Var2; % Suponiendo que la primera fila contiene los inicios
cadena_fin3 = rToff.Var2;
% 
% %Eliminamos artefactos de pequeña longitud en la evaluación de la señal ECG
% min_length = 15;
% [rPwave,cadena_inicios0,cadena_fin0]  = zero_short_ones(rPwave, min_length,cadena_inicios1, cadena_fin1);
% [rQRSwave,rQRSon0, rQRSoff0] = zero_short_ones(rQRSwave, min_length,cadena_inicios2, cadena_fin2);
% [rTwave,rTon0 ,rToff0] = zero_short_ones(rTwave, min_length,cadena_inicios3, cadena_fin3);

% %Eliminamos o cambiamos zonas que se han detectado como dos tipos de onda distintas en
% %una misma
% threshold = 16;
[rPwave1,rQRSwave1,rTwave1] = pre_overlap2(rPwave,rQRSwave,rTwave);

%Eliminamos ondas repetidas separadas mucha distancia (no detectadas por la
%función aanterior), eliminando aquella que tenga un tamaño despreciable
%frente a la otra

%% Procesado multicapa

cadena_inicios1 = rPon.Var2; % Suponiendo que la primera fila contiene los inicios
cadena_fin1 = rPoff.Var2;
cadena_inicios2 = rQRSon.Var2; % Suponiendo que la primera fila contiene los inicios
cadena_fin2 = rQRSoff.Var2;
cadena_inicios3 = rTon.Var2; % Suponiendo que la primera fila contiene los inicios
cadena_fin3 = rToff.Var2;

% Extraer el vector de inicios en formato de cadena
cadena_inicios = rPon.Var2; % Suponiendo que la primera fila contiene los inicios
cadena_fin = rPoff.Var2;

rango = 160;
[cadena_inicios0, cadena_fin0, rPwave] = proces_multi(cadena_inicios1, cadena_fin1, rPwave, rango);
[cadena_inicios0, cadena_fin0, rQRSwave] = proces_multi(cadena_inicios2, cadena_fin2, rQRSwave, rango);
[cadena_inicios0, cadena_fin0, rTwave] = proces_multi(cadena_inicios3, cadena_fin3, rTwave, rango);
% 
% 


%%
%Si usamos la libreria lobachevsky las primeras y ultimas muestras no se
%contabilizan
if indi == 1 
    rPwave = rPwave(750:4000,:);
    rQRSwave = rQRSwave(750:4000,:);
    rTwave = rTwave(750:4000,:);
    Pwave = Pwave(750:4000,:);
    QRSwave = QRSwave(750:4000,:);
    Twave = Twave(750:4000,:);
    dataset = dataset(750:4000,:);
end
if indi == 2
    [ind_last,max_length] = armon_QT(Pwave, QRSwave, Twave, Pwave_ind, QRSwave_ind, Twave_ind);
end

%% Dice coefficient gold
clc
if indi ~= 2
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=cell2mat(rPwave_ind(1,i+1));
        posicion = find(cellfun(@(x) isequal(x, ind), Pwave_ind));
        
        fiducials_data=Pwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanP=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=cell2mat(rPwave_ind(1,i+1));
        posicion = find(cellfun(@(x) isequal(x, ind), Pwave_ind));
        
        fiducials_data=QRSwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanQRS=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rTwave_ind)-1
        ind=cell2mat(rPwave_ind(1,i+1));
        posicion = find(cellfun(@(x) isequal(x, ind), Pwave_ind));
        
        fiducials_data=Twave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanT=nanmean(dice)
end

%% Precisión y recall gold
clc
% Calcular True Positives (TP), False Positives (FP) y False Negatives (FN)
TP = 0;
FP = 0;
FN = 0;

if indi ~= 2
    for i = 1:length(rPwave_ind)-1
        ind=cell2mat(rPwave_ind(1,i+1));
        posicion = find(cellfun(@(x) isequal(x, ind), Pwave_ind));
        
        fiducials_data=Pwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        %El programa no detecta bien cuando no hay onda P
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end 
    precisionP = TP/(TP+FP)
    recallP    = TP/(TP+FN)
        
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rQRSwave_ind)-1
        ind=cell2mat(rQRSwave_ind(1,i+1));
        posicion = find(cellfun(@(x) isequal(x, ind), QRSwave_ind));
        
        fiducials_data=QRSwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
    precisionQRS = TP/(TP+FP)
    recallQRS    = TP/(TP+FN)
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rTwave_ind)-1
        ind=cell2mat(rTwave_ind(1,i+1));
        posicion = find(cellfun(@(x) isequal(x, ind), Twave_ind));
        
        fiducials_data=Twave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
            
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionT = TP/(TP+FP)
    recallT    = TP/(TP+FN)
end

%% Dice coefficient
clc
if indi ~= 2
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Pwave_ind, ind));
        
        fiducials_data=Pwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanP=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=rQRSwave_ind(1,i+1);
        posicion = find(strcmp(QRSwave_ind, ind));
        
        fiducials_data=QRSwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanQRS=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rTwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Twave_ind, ind));
        
        fiducials_data=Twave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanT=nanmean(dice)
end
if indi == 2
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Pwave_ind, ind));
        
        fiducials_data=Pwave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanP=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rPwave_ind)-1
        ind=rQRSwave_ind(1,i+1);
        posicion = find(strcmp(QRSwave_ind, ind));
        
        fiducials_data=QRSwave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanQRS=nanmean(dice)
    
    dice=zeros(length(rPwave_ind),1);
    for i = 1:length(rTwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Twave_ind, ind));
        
        fiducials_data=Twave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
        intersection = sum((fiducials_data .* fiducials_result));
        union = sum(fiducials_data) + sum(fiducials_result);
        dice(i) = 2.*intersection/union;
    end
    dice_meanT=nanmean(dice)
end

%% Precisión y recall
clc
% Calcular True Positives (TP), False Positives (FP) y False Negatives (FN)
TP = 0;
FP = 0;
FN = 0;

if indi ~= 2
    for i = 1:length(rPwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Pwave_ind, ind));
        
        fiducials_data=Pwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        %El programa no detecta bien cuando no hay onda P
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end 
    precisionP = TP/(TP+FP)
    recallP    = TP/(TP+FN)
        
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rQRSwave_ind)-1
        ind=rQRSwave_ind(1,i+1);
        posicion = find(strcmp(QRSwave_ind, ind));
        
        fiducials_data=QRSwave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionQRS = TP/(TP+FP)
    recallQRS    = TP/(TP+FN)
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rTwave_ind)-1
        ind=rTwave_ind(1,i+1);
        posicion = find(strcmp(Twave_ind, ind));
        
        fiducials_data=Twave(:,posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
            
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionT = TP/(TP+FP)
    recallT    = TP/(TP+FN)
end

if indi == 2
    for i = 1:length(rPwave_ind)-1
        ind=rPwave_ind(1,i+1);
        posicion = find(strcmp(Pwave_ind, ind));
        
        fiducials_data=Pwave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last');+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=Pwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rPwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        %El programa no detecta bien cuando no hay onda P
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end 
    precisionP = TP/(TP+FP)
    recallP    = TP/(TP+FN)
        
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rQRSwave_ind)-1
        ind=rQRSwave_ind(1,i+1);
        posicion = find(strcmp(QRSwave_ind, ind));
        
        fiducials_data=QRSwave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=QRSwave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rQRSwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
       
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionQRS = TP/(TP+FP)
    recallQRS    = TP/(TP+FN)
    
    TP = 0;
    FP = 0;
    FN = 0;
    for i = 1:length(rTwave_ind)-1
        ind=rTwave_ind(1,i+1);
        posicion = find(strcmp(Twave_ind, ind));
        
        fiducials_data=Twave(ind_last(posicion-1)-max_length(posicion-1):ind_last(posicion-1),posicion);
        
        posicion_primero_uno = find(fiducials_data == 1, 1)+ind_last(posicion-1)-max_length(posicion-1);
        posicion_ultimo_uno = find(fiducials_data == 1, 1, 'last')+ind_last(posicion-1)-max_length(posicion-1);
        fiducials_data=Twave(posicion_primero_uno:posicion_ultimo_uno,posicion);
        fiducials_result=rTwave(posicion_primero_uno:posicion_ultimo_uno,i+1);
            
        TP = TP + sum(fiducials_data & fiducials_result);
        FP = FP + sum(~fiducials_data & fiducials_result); 
        FN = FN + sum(fiducials_data & ~fiducials_result); 
    end
        
    precisionT = TP/(TP+FP)
    recallT    = TP/(TP+FN)
end

%% Save
% Abre el archivo para escritura

fid = fopen('C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\Evaluacion\dice_precision.txt', 'w');

% Escribe los datos de las variables en el archivo
fprintf(fid, 'dice_meanP: %.5f\n', dice_meanP);
fprintf(fid, 'dice_meanQRS: %.5f\n', dice_meanQRS);
fprintf(fid, 'dice_meanT: %.5f\n', dice_meanT);

fprintf(fid, 'Precicion_P: %.5f\n', precisionP);
fprintf(fid, 'Precision_QRS: %.5f\n', precisionQRS);
fprintf(fid, 'Precision_T: %.5f\n', precisionT);

fprintf(fid, 'Recall_P: %.5f\n', recallP);
fprintf(fid, 'Recall_QRS: %.5f\n', recallQRS);
fprintf(fid, 'Recall_T: %.5f\n', recallT);

F1_score_P = 2*(precisionP*recallP)/(precisionP+recallP)
F1_score_QRS = 2*(precisionQRS*recallQRS)/(precisionQRS+recallQRS)
F1_score_T = 2*(precisionT*recallT)/(precisionT+recallT)

fprintf(fid, 'F1_P: %.5f\n', F1_score_P);
fprintf(fid, 'F1_QRS: %.5f\n', F1_score_QRS);
fprintf(fid, 'F1_T: %.5f\n', F1_score_T);
% Cierra el archivo
fclose(fid);


%%
% Guarda la variable en un archivo .mat
save('maxmin.mat','ind_last','max_length');

% Luego, si ejecutas clear all, todas las variables se eliminarán
clear all;
%%
% Puedes cargar la variable guardada nuevamente
load('maxmin.mat');

%% Onset, offset Lobachevsky
clear all
%On
ind=1;
r_rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPon.csv';
r_rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSon.csv';
r_rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rTon.csv';

rPon= readtable(r_rutaPon, 'VariableNamingRule', 'preserve');
rQRSon = readtable(r_rutaQRSon, 'VariableNamingRule', 'preserve');
rTon = readtable(r_rutaTon, 'VariableNamingRule', 'preserve');

rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Pon.csv';
rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSon.csv';
rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Ton.csv';

Pon = readtable(rutaPon, 'VariableNamingRule', 'preserve');
QRSon = readtable(rutaQRSon, 'VariableNamingRule', 'preserve');
Ton = readtable(rutaTon, 'VariableNamingRule', 'preserve');

%Off
r_rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPoff.csv';
r_rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSoff.csv';
r_rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rToff.csv';

rPoff = readtable(r_rutaPoff, 'VariableNamingRule', 'preserve');
rQRSoff = readtable(r_rutaQRSoff, 'VariableNamingRule', 'preserve');
rToff = readtable(r_rutaToff, 'VariableNamingRule', 'preserve');

rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Poff.csv';
rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSoff.csv';
rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Toff.csv';

Poff = readtable(rutaPoff, 'VariableNamingRule', 'preserve');
QRSoff = readtable(rutaQRSoff, 'VariableNamingRule', 'preserve');
Toff = readtable(rutaToff, 'VariableNamingRule', 'preserve');

%% Onset, offset QT automatic
%On
ind=2;
r_rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPon.csv';
r_rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSon.csv';
r_rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rTon.csv';

rPon= readtable(r_rutaPon, 'VariableNamingRule', 'preserve');
rQRSon = readtable(r_rutaQRSon, 'VariableNamingRule', 'preserve');
rTon = readtable(r_rutaTon,'Range','A1:B21', 'VariableNamingRule', 'preserve');

rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Pon.csv';
rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\QRSon.csv';
rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Ton.csv';

Pon = readtable(rutaPon, 'VariableNamingRule', 'preserve');
QRSon = readtable(rutaQRSon, 'VariableNamingRule', 'preserve');
Ton = readtable(rutaTon, 'VariableNamingRule', 'preserve');

%Off
r_rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPoff.csv';
r_rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSoff.csv';
r_rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rToff.csv';

rPoff = readtable(r_rutaPoff, 'VariableNamingRule', 'preserve');
rQRSoff = readtable(r_rutaQRSoff, 'VariableNamingRule', 'preserve');
rToff = readtable(r_rutaToff,'Range','A1:B21', 'VariableNamingRule', 'preserve'); %Cuidado con 'A1:B21'

rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Poff.csv';
rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\QRSoff.csv';
rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\automatic\Toff.csv';

Poff = readtable(rutaPoff, 'VariableNamingRule', 'preserve');
QRSoff = readtable(rutaQRSoff, 'VariableNamingRule', 'preserve');
Toff = readtable(rutaToff, 'VariableNamingRule', 'preserve');

%% Onset, offset QT Manual
%On
ind=2;
r_rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPon.csv';
r_rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSon.csv';
r_rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rTon.csv';

rPon= readtable(r_rutaPon, 'VariableNamingRule', 'preserve');
rQRSon = readtable(r_rutaQRSon, 'VariableNamingRule', 'preserve');
rTon = readtable(r_rutaTon,'Range','A1:B21', 'VariableNamingRule', 'preserve');

rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Pon.csv';
rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\QRSon.csv';
rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Ton.csv';

Pon = readtable(rutaPon, 'VariableNamingRule', 'preserve');
QRSon = readtable(rutaQRSon, 'VariableNamingRule', 'preserve');
Ton = readtable(rutaTon, 'VariableNamingRule', 'preserve');

%Off
r_rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rPoff.csv';
r_rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rQRSoff.csv';
r_rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\Results_net\rToff.csv';

rPoff = readtable(r_rutaPoff, 'VariableNamingRule', 'preserve');
rQRSoff = readtable(r_rutaQRSoff, 'VariableNamingRule', 'preserve');
rToff = readtable(r_rutaToff,'Range','A1:B21', 'VariableNamingRule', 'preserve'); %Cuidado con 'A1:B21'

rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Poff.csv';
rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\QRSoff.csv';
rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia\qt-database-1.0.0\qt-database-1.0.0\manual0\Toff.csv';

Poff = readtable(rutaPoff, 'VariableNamingRule', 'preserve');
QRSoff = readtable(rutaQRSoff, 'VariableNamingRule', 'preserve');
Toff = readtable(rutaToff, 'VariableNamingRule', 'preserve');
%%

% Cast a cell
rPon = table2cell(rPon);
rQRSon = table2cell(rQRSon);
rTon = table2cell(rTon);

rPoff = table2cell(rPoff);
rQRSoff = table2cell(rQRSoff);
rToff = table2cell(rToff);

Pon = table2cell(Pon);
QRSon = table2cell(QRSon);
Ton = table2cell(Ton);

Poff = table2cell(Poff);
QRSoff = table2cell(QRSoff);
Toff = table2cell(Toff);

% % %Cast a array lobachevsky
if ind == 1
    
    rPon_ind = cell2mat(rPon(:,1));
    rQRSon_ind = cell2mat(rQRSon(:,1));
    rTon_ind = cell2mat(rTon(:,1));
    
    rPoff_ind = cell2mat(rPoff(:,1));
    rQRSoff_ind = cell2mat(rPoff(:,1));
    rToff_ind = cell2mat(rPoff(:,1));
    
    Pon_ind = cell2mat(Pon(:,1));
    QRSon_ind = cell2mat(QRSon(:,1));
    Ton_ind = cell2mat(Ton(:,1));
    
    Poff_ind = cell2mat(Poff(:,1));
    QRSoff_ind = cell2mat(QRSoff(:,1));
    Toff_ind = cell2mat(Toff(:,1));

%Cast a array QT
else
    rPon_ind = cellstr((rPon(:,1)));
    rQRSon_ind = cellstr(rQRSon(:,1));
    rTon_ind = cellstr(rTon(:,1));
    
    rPoff_ind = cellstr(rPoff(:,1));
    rQRSoff_ind = cellstr(rQRSoff(:,1));
    rToff_ind = cellstr(rToff(:,1));
    
    Pon_ind = cellstr(Pon(:,1));
    QRSon_ind = cellstr(QRSon(:,1));
    Ton_ind = cellstr(Ton(:,1));
    
    Poff_ind = cellstr(Poff(:,1));
    QRSoff_ind = cellstr(QRSoff(:,1));
    Toff_ind = cellstr(Toff(:,1));
end

% %%
% if ind == 1 
%     rPwave = rPwave(750:4000,:);
%     rQRSwave = rQRSwave(750:4000,:);
%     rTwave = rTwave(750:4000,:);
%     Pwave = Pwave(750:4000,:);
%     QRSwave = QRSwave(750:4000,:);
%     Twave = Twave(750:4000,:);
%     dataset = dataset(750:4000,:);
% end
%% Onset,offset, desviación tipica QT automatic
clc
tol=100;
sampling_freq=500;
for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rPon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rPoff_ind);
    posicion_on = buscar_ind(ind_ron,Pon_ind);
    posicion_off = buscar_ind(ind_ron,Poff_ind);
    
    res_on = rPon(i,2);
    res_off = rPoff(posicion_roff(1),2);
    data_on = Pon(posicion_on(1),2);
    data_off = Poff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);
   
    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);
  
    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end
    %Los valores en los que se obtienen NaN se deben a que no hay onda
    err_on_P_n(i) = nanmean(abs(data_on - res_on));
    err_off_P_n(i) = nanmean(abs(data_off - res_off));

end
err_on_P = nanmean(abs(err_on_P_n))/sampling_freq*1000
err_off_P = nanmean(abs(err_off_P_n))/sampling_freq*1000
std_on_P = nanstd(abs(err_on_P_n))/sampling_freq*1000
std_off_P = nanstd(abs(err_off_P_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rQRSon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rQRSoff_ind);
    posicion_on = buscar_ind(ind_ron,QRSon_ind);
    posicion_off = buscar_ind(ind_ron, QRSoff_ind);
    
    res_on = rQRSon(i,2);
    res_off = rQRSoff(posicion_roff(1),2);
    data_on = QRSon(posicion_on(1),2);
    data_off = QRSoff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));
    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_QRS_n(i) = nanmean(abs(data_on - res_on));
    err_off_QRS_n(i) = nanmean(abs(data_off - res_off));

end
err_on_QRS = nanmean(abs(err_on_QRS_n))/sampling_freq*1000
err_off_QRS = nanmean(abs(err_off_QRS_n))/sampling_freq*1000
std_on_QRS = nanstd(abs(err_on_QRS_n))
std_off_QRS = nanstd(abs(err_off_QRS_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rTon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rToff_ind);
    posicion_on = buscar_ind(ind_ron,Ton_ind);
    posicion_off = buscar_ind(ind_ron,Toff_ind);
    
    res_on = rTon(i,2);
    res_off = rToff(posicion_roff(1),2);
    data_on = Ton(posicion_on(1),2);
    data_off = Toff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));
    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_T_n(i) = nanmean(abs(data_on - res_on));
    err_off_T_n(i) = nanmean(abs(data_off - res_off));

end
err_on_T = nanmean(abs(err_on_T_n))/sampling_freq*1000
err_off_T = nanmean(abs(err_off_T_n))/sampling_freq*1000
std_on_T = nanstd(abs(err_on_T_n))
std_off_T = nanstd(abs(err_off_T_n))/sampling_freq*1000

%% Onset,offset, desviación tipica QT manual
clc
tol=100;
sampling_freq=500;
for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rPon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rPoff_ind);
    posicion_on = buscar_ind(ind_ron,Pon_ind);
    posicion_off = buscar_ind(ind_ron,Poff_ind);
    
    res_on_old = rPon(i,2);
    res_off_old = rPoff(posicion_roff(1),2);
    data_on_old = Pon(posicion_on(1),2);
    data_off_old = Poff(posicion_off(1),2);

    res_on_old = cell2mat(res_on_old);
    res_off_old = cell2mat(res_off_old);
    data_on_old = cell2mat(data_on_old);
    data_off_old = cell2mat(data_off_old);

    res_on_old = str2double(strsplit(res_on_old));
    res_off_old = str2double(strsplit(res_off_old));
    data_on_old = str2double(strsplit(data_on_old));
    data_off_old = str2double(strsplit(data_off_old));

    count_ron=1;
    count_roff=1;
    count_don=1;
    count_doff=1;
    for j=1:length(res_on_old)
        if res_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_on_old(j) < ind_last(posicion_on)
            res_on(count_ron) = res_on_old(j);
            count_ron = count_ron+1;
        end
    end
    for j=1:length(res_off_old)
        if res_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_off_old(j) < ind_last(posicion_on)
            res_off(count_roff) = res_off_old(j);
            count_roff = count_roff+1;
        end
    end
    for j=1:length(data_on_old)
        if data_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_on_old(j) < ind_last(posicion_on)
            data_on(count_don) = data_on_old(j);
            count_don = count_don+1;
        end
    end
    for j=1:length(data_off_old)
        if data_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_off_old(j) < ind_last(posicion_on)
            data_off(count_doff) = data_off_old(j);
            count_doff = count_doff+1;
        end
    end

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);
   
    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);
  
    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end
    %Los valores en los que se obtienen NaN se deben a que no hay onda
    err_on_P_n(i) = nanmean(abs(data_on - res_on));
    err_off_P_n(i) = nanmean(abs(data_off - res_off));

end
err_on_P = nanmean(abs(err_on_P_n))/sampling_freq*1000
err_off_P = nanmean(abs(err_off_P_n))/sampling_freq*1000
std_on_P = nanstd(abs(err_on_P_n))/sampling_freq*1000
std_off_P = nanstd(abs(err_off_P_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rQRSon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rQRSoff_ind);
    posicion_on = buscar_ind(ind_ron,QRSon_ind);
    posicion_off = buscar_ind(ind_ron, QRSoff_ind);
    
    res_on_old = rQRSon(i,2);
    res_off_old = rQRSoff(posicion_roff(1),2);
    data_on_old = QRSon(posicion_on(1),2);
    data_off_old = QRSoff(posicion_off(1),2);

    res_on_old = cell2mat(res_on_old);
    res_off_old = cell2mat(res_off_old);
    data_on_old = cell2mat(data_on_old);
    data_off_old = cell2mat(data_off_old);

    res_on_old = str2double(strsplit(res_on_old));
    res_off_old = str2double(strsplit(res_off_old));
    data_on_old = str2double(strsplit(data_on_old));
    data_off_old = str2double(strsplit(data_off_old));

    count_ron=1;
    count_roff=1;
    count_don=1;
    count_doff=1;
    for j=1:length(res_on_old)
        if res_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_on_old(j) < ind_last(posicion_on)
            res_on(count_ron) = res_on_old(j);
            count_ron = count_ron+1;
        end
    end
    for j=1:length(res_off_old)
        if res_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_off_old(j) < ind_last(posicion_on)
            res_off(count_roff) = res_off_old(j);
            count_roff = count_roff+1;
        end
    end
    for j=1:length(data_on_old)
        if data_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_on_old(j) < ind_last(posicion_on)
            data_on(count_don) = data_on_old(j);
            count_don = count_don+1;
        end
    end
    for j=1:length(data_off_old)
        if data_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_off_old(j) < ind_last(posicion_on)
            data_off(count_doff) = data_off_old(j);
            count_doff = count_doff+1;
        end
    end

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_QRS_n(i) = nanmean(abs(data_on - res_on));
    err_off_QRS_n(i) = nanmean(abs(data_off - res_off));

end
err_on_QRS = nanmean(abs(err_on_QRS_n))/sampling_freq*1000
err_off_QRS = nanmean(abs(err_off_QRS_n))/sampling_freq*1000
std_on_QRS = nanstd(abs(err_on_QRS_n))
std_off_QRS = nanstd(abs(err_off_QRS_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rTon_ind(i);
    posicion_roff = buscar_ind(ind_ron,rToff_ind);
    posicion_on = buscar_ind(ind_ron,Ton_ind);
    posicion_off = buscar_ind(ind_ron,Toff_ind);
    
    res_on_old = rTon(i,2);
    res_off_old = rToff(posicion_roff(1),2);
    data_on_old = Ton(posicion_on(1),2);
    data_off_old = Toff(posicion_off(1),2);

    res_on_old = cell2mat(res_on_old);
    res_off_old = cell2mat(res_off_old);
    data_on_old = cell2mat(data_on_old);
    data_off_old = cell2mat(data_off_old);

    res_on_old = str2double(strsplit(res_on_old));
    res_off_old = str2double(strsplit(res_off_old));
    data_on_old = str2double(strsplit(data_on_old));
    data_off_old = str2double(strsplit(data_off_old));

    count_ron=1;
    count_roff=1;
    count_don=1;
    count_doff=1;
    for j=1:length(res_on_old)
        if res_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_on_old(j) < ind_last(posicion_on)
            res_on(count_ron) = res_on_old(j);
            count_ron = count_ron+1;
        end
    end
    for j=1:length(res_off_old)
        if res_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && res_off_old(j) < ind_last(posicion_on)
            res_off(count_roff) = res_off_old(j);
            count_roff = count_roff+1;
        end
    end
    for j=1:length(data_on_old)
        if data_on_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_on_old(j) < ind_last(posicion_on)
            data_on(count_don) = data_on_old(j);
            count_don = count_don+1;
        end
    end
    for j=1:length(data_off_old)
        if data_off_old(j) > (ind_last(posicion_on)-max_length(posicion_on)) && data_off_old(j) < ind_last(posicion_on)
            data_off(count_doff) = data_off_old(j);
            count_doff = count_doff+1;
        end
    end

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_T_n(i) = nanmean(abs(data_on - res_on));
    err_off_T_n(i) = nanmean(abs(data_off - res_off));

end
err_on_T = nanmean(abs(err_on_T_n))/sampling_freq*1000
err_off_T = nanmean(abs(err_off_T_n))/sampling_freq*1000
std_on_T = nanstd(abs(err_on_T_n))
std_off_T = nanstd(abs(err_off_T_n))/sampling_freq*1000

%% Onset,offset, desviación tipica Lobachevsky
clc
tol=100;
sampling_freq=500;
for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rPon_ind(i);

    posicion_roff = find(rPoff_ind == ind_ron);
    posicion_on = find(Pon_ind == ind_ron);
    posicion_off = find(Poff_ind == ind_ron);
    
    res_on = rPon(i,2);
    res_off = rPoff(posicion_roff(1),2);
    data_on = Pon(posicion_on(1),2);
    data_off = Poff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));

    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);
   
    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);
  
    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end
    %Los valores en los que se obtienen NaN se deben a que no hay onda
    err_on_P_n(i) = nanmean(abs(data_on - res_on));
    err_off_P_n(i) = nanmean(abs(data_off - res_off));

end
err_on_P = nanmean(abs(err_on_P_n))/sampling_freq*1000
err_off_P = nanmean(abs(err_off_P_n))/sampling_freq*1000
std_on_P = nanstd(abs(err_on_P_n))/sampling_freq*1000
std_off_P = nanstd(abs(err_off_P_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rQRSon_ind(i);
    posicion_roff = find(rQRSoff_ind == ind_ron);
    posicion_on = find(QRSon_ind == ind_ron);
    posicion_off = find(QRSoff_ind == ind_ron);
    
    res_on = rQRSon(i,2);
    res_off = rQRSoff(posicion_roff(1),2);
    data_on = QRSon(posicion_on(1),2);
    data_off = QRSoff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));
    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_QRS_n(i) = nanmean(abs(data_on - res_on));
    err_off_QRS_n(i) = nanmean(abs(data_off - res_off));

end
err_on_QRS = nanmean(abs(err_on_QRS_n))/sampling_freq*1000
err_off_QRS = nanmean(abs(err_off_QRS_n))/sampling_freq*1000
std_on_QRS = nanstd(abs(err_on_QRS_n))
std_off_QRS = nanstd(abs(err_off_QRS_n))/sampling_freq*1000

for i = 1:length(rPon_ind) %No me acuerdo porqué el -1
    ind_ron=rTon_ind(i);
    posicion_roff = find(rToff_ind == ind_ron);
    posicion_on = find(Ton_ind == ind_ron);
    posicion_off = find(Toff_ind == ind_ron);
    
    res_on = rTon(i,2);
    res_off = rToff(posicion_roff(1),2);
    data_on = Ton(posicion_on(1),2);
    data_off = Toff(posicion_off(1),2);

    res_on = cell2mat(res_on);
    res_off = cell2mat(res_off);
    data_on = cell2mat(data_on);
    data_off = cell2mat(data_off);

    res_on = str2double(strsplit(res_on));
    res_off = str2double(strsplit(res_off));
    data_on = str2double(strsplit(data_on));
    data_off = str2double(strsplit(data_off));
    %Eliminamos los índices extras que tenemos debido a que no estan las
    %marcas de la ECG completa en los datos
    indices_mantener_on = res_on <= (data_on(end)+100) & res_on >= (data_on(1)-100);
    indices_mantener_off = res_off <= (data_off(end)+100) & res_off >= (data_off(1)-100);
   
    % Seleccionar solo los elementos que cumplen con ambas condiciones
    res_on = res_on(indices_mantener_on);
    res_off = res_off(indices_mantener_off);

    res_on = correspondencia_val(data_on,res_on,tol);
    res_off = correspondencia_val(data_off,res_off,tol);

    %Si hay valores que no corresponden con ninguna marca eliminarlos
    if ~isempty(find(abs(data_on - res_on) > tol))
        posicion = find(abs(data_on - res_on) > tol);
        res_on(posicion) = [];
        data_on(posicion) = [];
    end
    if ~isempty(find(abs(data_off - res_off) > tol ))
        posicion = find(abs(data_off - res_off) > tol);
        res_off(posicion) = [];
        data_off(posicion) = [];
    end

    err_on_T_n(i) = nanmean(abs(data_on - res_on));
    err_off_T_n(i) = nanmean(abs(data_off - res_off));

end
err_on_T = nanmean(abs(err_on_T_n))/sampling_freq*1000
err_off_T = nanmean(abs(err_off_T_n))/sampling_freq*1000
std_on_T = nanstd(abs(err_on_T_n))
std_off_T = nanstd(abs(err_off_T_n))/sampling_freq*1000

%% Save
fid = fopen('C:\Users\ruben\OneDrive\Escritorio\4º Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\Evaluacion\on_off.txt', 'w');

% Escribe los datos de las variables en el archivo
fprintf(fid, 'err_on_P: %.5f\n', err_on_P);
fprintf(fid, 'err_on_QRS: %.5f\n', err_on_QRS);
fprintf(fid, 'err_on_T: %.5f\n', err_on_T);

fprintf(fid, 'err_off_P: %.5f\n', err_off_P);
fprintf(fid, 'err_off_QRS: %.5f\n', err_off_QRS);
fprintf(fid, 'err_off_T: %.5f\n', err_off_T);

fprintf(fid, 'std_on_P: %.5f\n', std_on_P);
fprintf(fid, 'std_on_QRS: %.5f\n', std_on_QRS);
fprintf(fid, 'std_on_T: %.5f\n', std_on_T);

fprintf(fid, 'std_off_P: %.5f\n', std_off_P);
fprintf(fid, 'std_off_QRS: %.5f\n', std_off_QRS);
fprintf(fid, 'std_off_T: %.5f\n', std_off_T);

% Cierra el archivo
fclose(fid);
