import numpy as np
import pandas as pd
# Generar un vector con valores del 1 al 2000
valores = np.arange(1, 301)

# Barajar el vector de valores
np.random.shuffle(valores)

# Determinar el tamaño de cada parte
num_20_percent = int(0.20 * len(valores))
num_80_percent = len(valores) - num_20_percent

# Dividir el vector barajado en dos partes
test_keys = valores[:num_20_percent]
train_keys = valores[num_20_percent:]

# Convertir los vectores a DataFrames
df_vector_20 = pd.DataFrame(test_keys, columns=['Valores']).transpose()
df_vector_80 = pd.DataFrame(train_keys, columns=['Valores']).transpose()

# Especificar la ruta donde quieres guardar los archivos CSV
ruta_20 = '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/CommonDistribution/test_sintetic.csv'
ruta_80 = '/home/bio/rfernand/work/research/ECGDelNet-master_reducida_mia/CommonDistribution/train_sintetic.csv'

# Guardar los DataFrames en archivos CSV
df_vector_20.to_csv(ruta_20, index=False)
df_vector_80.to_csv(ruta_80, index=False)