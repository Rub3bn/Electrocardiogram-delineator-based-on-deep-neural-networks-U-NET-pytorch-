clear all
close all

%% Inicializacion parametros y path
%Hay que a�adir el path de los codigos del delineador
addpath(genpath("C:\Users\ruben\OneDrive\Escritorio\delin\"))

%% Manual_Lobac
%Wave
indi=1;
r_rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPwave.csv';
r_rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSwave.csv';
r_rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rTwave.csv';


rPwave = readtable(r_rutaPwave, 'VariableNamingRule', 'preserve');
rQRSwave = readtable(r_rutaQRSwave, 'VariableNamingRule', 'preserve');
rTwave = readtable(r_rutaTwave, 'VariableNamingRule', 'preserve');

rutaPwave = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Pwave.csv';
rutaQRSwave = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSwave.csv';
rutaTwave = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Twave.csv';

Pwave = readtable(rutaPwave, 'VariableNamingRule', 'preserve');
QRSwave = readtable(rutaQRSwave, 'VariableNamingRule', 'preserve');
Twave = readtable(rutaTwave, 'VariableNamingRule', 'preserve');

rutaDataset = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Dataset.csv';

dataset = readtable(rutaDataset, 'VariableNamingRule', 'preserve');


r_rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPon.csv';
r_rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSon.csv';
r_rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rTon.csv';

rPon= readtable(r_rutaPon, 'VariableNamingRule', 'preserve');
rQRSon = readtable(r_rutaQRSon, 'VariableNamingRule', 'preserve');
rTon = readtable(r_rutaTon, 'VariableNamingRule', 'preserve');

rutaPon = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Pon.csv';
rutaQRSon = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSon.csv';
rutaTon = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Ton.csv';

Pon = readtable(rutaPon, 'VariableNamingRule', 'preserve');
QRSon = readtable(rutaQRSon, 'VariableNamingRule', 'preserve');
Ton = readtable(rutaTon, 'VariableNamingRule', 'preserve');

%Off
r_rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rPoff.csv';
r_rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rQRSoff.csv';
r_rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\Results_net_torch\rToff.csv';

rPoff = readtable(r_rutaPoff, 'VariableNamingRule', 'preserve');
rQRSoff = readtable(r_rutaQRSoff, 'VariableNamingRule', 'preserve');
rToff = readtable(r_rutaToff, 'VariableNamingRule', 'preserve');

rutaPoff = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Poff.csv';
rutaQRSoff = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\QRSoff.csv';
rutaToff = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\lobachevsky-university-electrocardiography-database-1.0.1\data\ToCSV\Toff.csv';

Poff = readtable(rutaPoff, 'VariableNamingRule', 'preserve');
QRSoff = readtable(rutaQRSoff, 'VariableNamingRule', 'preserve');
Toff = readtable(rutaToff, 'VariableNamingRule', 'preserve');
%%
rPwave_ind =rPwave.Properties.VariableNames;
rQRSwave_ind =rQRSwave.Properties.VariableNames;
rTwave_ind =rTwave.Properties.VariableNames;

Pwave_ind =Pwave.Properties.VariableNames;
QRSwave_ind =QRSwave.Properties.VariableNames;
Twave_ind =Twave.Properties.VariableNames;

dataset_ind = dataset.Properties.VariableNames;

rPwave = table2array(rPwave);
rQRSwave = table2array(rQRSwave);
rTwave = table2array(rTwave);

Pwave = table2array(Pwave);
QRSwave = table2array(QRSwave);
Twave = table2array(Twave);

dataset = table2array(dataset);

%%
dataset_u = dataset(:,1598:1609);
%% Solo representaci�n
for l = 1:12
    l
    signal = dataset_u(:,l);
    fa = 500;
    %Cambia el nombre si quieres para guardar el nuevo archivo
    save("C:\Users\ruben\OneDrive\Escritorio\delin\signal_delin.mat",'signal','fa') 
    % Par�metros y delineaci�n
    sigdir='C:\Users\ruben\OneDrive\Escritorio\delin\'; %Signal directSory
    leadr=1; %leads to be processed
    messages=[];
    headir=sigdir;
    matdir=[];
    ecgnr='signal_delin'; %signal name
    t=[]; %All signal
    ft=2; %Signal format .mat (chanse in case of different format)
    anot=[ecgnr '_wavannot']; %annot name
    flags=[0 0 0]; %Flag for wave delineation
    anot_fmt=[];
    aname=[];
    dirann=[];

    position{l} = wavedet_3D(sigdir,headir,matdir,ecgnr,ft,anot,leadr,t,flags,anot_fmt,aname,dirann,messages);
   
end
% Ruta de la carpeta donde se guardar�n los archivos
ruta_carpeta = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\data_aug\'; 

for j = 1:12
    signal = dataset_u(:,j);
    % Acceder al struct en la celda i de posici�n
    struct_actual = position{j};
    
    % Acceder a la variable Pon dentro del struct
    Pon_actual = struct_actual.Pon;
    Pon_actual = Pon_actual(~isnan(Pon_actual));
    

    Poff_actual = struct_actual.Poff;
    Poff_actual = Poff_actual(~isnan(Poff_actual));
    
    
    QRSon_actual = struct_actual.QRSon;
    QRSon_actual = QRSon_actual(~isnan(QRSon_actual));

    QRSoff_actual = struct_actual.QRSoff;
    QRSoff_actual = QRSoff_actual(~isnan(QRSoff_actual));

    Ton_actual = struct_actual.Ton;
    Ton_actual = Ton_actual(~isnan(Ton_actual));

    Toff_actual = struct_actual.Toff;
    Toff_actual = Toff_actual(~isnan(Toff_actual));
    
    fig1 = figure(1);
    fig1.Position(1:2) = [1 400];
    fig1.Position(3:4) = [2000 200];
    

    N=length(signal(:,1));
    mascara_binaria_P = zeros(1, N);
    
    for i = 1:length(Pon_actual)
        inicio = Pon_actual(i);
        final = Poff_actual(i);
        mascara_binaria_P(inicio:final) = 1;
    end

    N=length(signal(:,1));
    mascara_binaria_QRS = zeros(1, N);
    
    for i = 1:length(QRSon_actual)
        inicio = QRSon_actual(i);
        final = QRSoff_actual(i);
        mascara_binaria_QRS(inicio:final) = 1;
    end

    N=length(signal(:,1));
    mascara_binaria_T = zeros(1, N);
    
    for i = 1:length(Ton_actual)
        inicio = Ton_actual(i);
        final = Toff_actual(i);
        mascara_binaria_T(inicio:final) = 1;
    end

    plot(signal(:,1))
    hold on
    plot(mascara_binaria_P, 'Color', 'r')
    plot(mascara_binaria_QRS, 'Color', 'g')
    plot(mascara_binaria_T, 'Color', 'y')
%     plot(Pon_actual,zeros(1,length(Pon_actual)), '|','MarkerSize', 1000, 'Color', 'r','LineWidth', 1)
%     plot(Poff_actual,zeros(1,length(Poff_actual)), '|','MarkerSize', 1000, 'Color', 'r','LineWidth', 1)
%     plot(QRSon_actual,zeros(1,length(QRSon_actual)), '|','MarkerSize', 1000, 'Color', 'g','LineWidth', 1)
%     plot(QRSoff_actual,zeros(1,length(QRSoff_actual)), '|','MarkerSize', 1000, 'Color', 'g','LineWidth', 1)
%     plot(Ton_actual,zeros(1,length(Ton_actual)), '|','MarkerSize', 1000, 'Color', 'y', 'LineWidth', 1)
%     plot(Toff_actual,zeros(1,length(Toff_actual)), '|','MarkerSize', 1000, 'Color', 'y', 'LineWidth', 1)
%     xlim([1500,3500])
%     title(['39_' num2str(j-1)]);
%     hold off
    pause
end

disp(['Valores extraidos ' num2str(h)]);


%% La se�al tiene que ser un archivo con 2 variables: signal y fa
tic;

% Extraer la variable Pon de cada struct en posici�n y guardarla en Pon_values
Pon_values = cell(500, 12);
Poff_values = cell(500, 12);
QRSon_values = cell(500, 12);
QRSoff_values = cell(500, 12);
Ton_values = cell(500, 12);
Toff_values = cell(500, 12);

for h = 1:500
    for l = 1:1:12
        load(['C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\data_aug\bigeminy\\\\simECGdata_ds_' num2str(h) '.mat'],'multileadECG')
        signal = multileadECG(l,:);
% 
%         
%         % Par�metros del ruido
%         SNR_dB = 20;         % Relaci�n se�al-ruido en decibelios (dB)
%         SNR_linear = 10^(SNR_dB/10); % Convertir SNR de dB a lineal
%         
%         % Potencia de la se�al
%         signal_power = mean(signal.^2);
%         
%         % Potencia del ruido
%         noise_power = signal_power / SNR_linear;
%         
%         % Generar ruido blanco gaussiano
%         noise = sqrt(noise_power) * randn(size(signal));
%         
%         % Se�al con ruido
%         signal = signal + noise;



    %     figure
    
        fa = 500;
        %Cambia el nombre si quieres para guardar el nuevo archivo
        save("C:\Users\ruben\OneDrive\Escritorio\delin\signal_delin.mat",'signal','fa') 
        % Par�metros y delineaci�n
        sigdir='C:\Users\ruben\OneDrive\Escritorio\delin\'; %Signal directSory
        leadr=1; %leads to be processed
        messages=[];
        headir=sigdir;
        matdir=[];
        ecgnr='signal_delin'; %signal name
        t=[]; %All signal
        ft=2; %Signal format .mat (chanse in case of different format)
        anot=[ecgnr '_wavannot']; %annot name
        flags=[0 0 0]; %Flag for wave delineation
        anot_fmt=[];
        aname=[];
        dirann=[];
    
        position{l} = wavedet_3D(sigdir,headir,matdir,ecgnr,ft,anot,leadr,t,flags,anot_fmt,aname,dirann,messages);
        
        
    
    end
    disp(['file' num2str(h)]);
    % Ruta de la carpeta donde se guardar�n los archivos
    ruta_carpeta = 'C:\Users\ruben\OneDrive\Escritorio\4� Universidad\TFG\ECGDelNet-master_reducida_mia - copia - copia\data_aug\'; 

    for j = 1:12
        % Acceder al struct en la celda i de posici�n
        struct_actual = position{j};
        
        % Acceder a la variable Pon dentro del struct
        Pon_actual = struct_actual.Pon;
        Pon_actual = Pon_actual(~isnan(Pon_actual));
        

        Poff_actual = struct_actual.Poff;
        Poff_actual = Poff_actual(~isnan(Poff_actual));
        
        
        QRSon_actual = struct_actual.QRSon;
        QRSon_actual = QRSon_actual(~isnan(QRSon_actual));

        QRSoff_actual = struct_actual.QRSoff;
        QRSoff_actual = QRSoff_actual(~isnan(QRSoff_actual));

        Ton_actual = struct_actual.Ton;
        Ton_actual = Ton_actual(~isnan(Ton_actual));

        Toff_actual = struct_actual.Toff;
        Toff_actual = Toff_actual(~isnan(Toff_actual));
        
%         figure
%         plot(signal(1,:))
%         hold on
%         plot(Pon_actual,zeros(1,length(Pon_actual)), 'ro', 'MarkerFaceColor', 'r')
%         plot(Poff_actual,zeros(1,length(Poff_actual)), 'ro', 'MarkerFaceColor', 'r')
%         plot(QRSon_actual,zeros(1,length(QRSon_actual)), 'ro', 'MarkerFaceColor', 'g')
%         plot(QRSoff_actual,zeros(1,length(QRSoff_actual)), 'ro', 'MarkerFaceColor', 'g')
%         plot(Ton_actual,zeros(1,length(Ton_actual)), 'ro', 'MarkerFaceColor', 'y')
%         plot(Toff_actual,zeros(1,length(Toff_actual)), 'ro', 'MarkerFaceColor', 'y')
%         xlim([1500,3000])
%         pause(3)

        % Guardar el valor de Pon en la celda correspondiente de Pon_values
        Pon_values{h,j} = Pon_actual;
        Poff_values{h,j} = Poff_actual;
        QRSon_values{h,j} = QRSon_actual;
        QRSoff_values{h,j} = QRSoff_actual;
        Ton_values{h,j} = Ton_actual;
        Toff_values{h,j} = Toff_actual;
    end

    disp(['Valores extraidos ' num2str(h)]);
end
% Construir el nombre del archivo
nombre_archivo1 = fullfile(ruta_carpeta, 'Pon.mat');
nombre_archivo2 = fullfile(ruta_carpeta, 'Poff.mat');
nombre_archivo3 = fullfile(ruta_carpeta, 'QRSon.mat');
nombre_archivo4 = fullfile(ruta_carpeta, 'QRSoff.mat');
nombre_archivo5 = fullfile(ruta_carpeta, 'Ton.mat');
nombre_archivo6 = fullfile(ruta_carpeta, 'Toff.mat');

% Guardar el valor de Pon en el archivo
save(nombre_archivo1, 'Pon_values');
save(nombre_archivo2, 'Poff_values');
save(nombre_archivo3, 'QRSon_values');
save(nombre_archivo4, 'QRSoff_values');
save(nombre_archivo5, 'Ton_values');
save(nombre_archivo6, 'Toff_values');

time2=toc;
disp(toc)